from __future__ import annotations
import uuid
import copy
import os
import math
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any, Callable, Tuple
from abc import ABC, abstractmethod


# ============================================================================
# BASE INSTANCE CLASS - All objects inherit from this
# ============================================================================


class Instance(ABC):
    """
    Base class for all Roblox-style Instance objects.
    This is the foundation of the entire object hierarchy.
    """

    def __init__(self, name: str = "Instance"):
        self.name: str = name
        self.class_name: str = self.__class__.__name__
        self.object_id: str = str(uuid.uuid4())
        self.parent_id: Optional[str] = None
        self.children: List[Instance] = []
        self.properties: Dict[str, Any] = {}

        # Common properties
        self.visible: bool = True
        self.locked: bool = False

        # Legacy compatibility attributes
        self.scripts: List[str] = []  # Paths to attached script files

    def add_child(self, child: Instance):
        """Parent a child to this instance"""
        child.parent_id = self.object_id
        self.children.append(child)

    def remove_child(self, child: Instance):
        """Unparent a child from this instance"""
        if child in self.children:
            child.parent_id = None
            self.children.remove(child)

    def find_first_child(self, name: str) -> Optional[Instance]:
        """Find first child by name"""
        for child in self.children:
            if child.name == name:
                return child
        return None

    def find_first_child_of_class(self, class_name: str) -> Optional[Instance]:
        """Find first child by class name"""
        for child in self.children:
            if child.class_name == class_name:
                return child
        return None

    def get_descendants(self) -> List[Instance]:
        """Get all descendants recursively"""
        descendants = []
        for child in self.children:
            descendants.append(child)
            descendants.extend(child.get_descendants())
        return descendants

    def clone(self) -> Instance:
        """Deep clone this instance and all children"""
        cloned = copy.deepcopy(self)
        self._regenerate_ids(cloned)
        return cloned

    def _regenerate_ids(self, obj: Instance):
        """Recursively regenerate IDs for cloned objects"""
        obj.object_id = str(uuid.uuid4())
        for child in obj.children:
            child.parent_id = obj.object_id
            self._regenerate_ids(child)

    def to_dict(self) -> Dict:
        """Serialize to dictionary"""
        data = {
            "name": self.name,
            "class_name": self.class_name,
            "object_id": self.object_id,
            "visible": self.visible,
            "locked": self.locked,
            "properties": self.properties,
            "children": [child.to_dict() for child in self.children],
        }
        return data

    @staticmethod
    def from_dict(data: Dict) -> Instance:
        """Deserialize from dictionary - override in subclasses"""
        # This will be overridden by factory function
        pass


# ============================================================================
# BASEPART - Foundation for all 3D physical objects
# ============================================================================


class BasePart(Instance):
    """Base class for all physical 3D parts (Part, WedgePart, etc.)"""

    def __init__(self, name: str = "Part"):
        super().__init__(name)

        # Transform properties
        self.position: List[float] = [0.0, 0.0, 0.0]
        self.rotation: List[float] = [0.0, 0.0, 0.0]  # Euler angles in degrees
        self.scale: List[float] = [1.0, 1.0, 1.0]

        # Visual properties
        self.color: List[float] = [0.5, 0.5, 0.5]  # RGB 0-1
        self.transparency: float = 0.0  # 0 = opaque, 1 = invisible
        self.material: str = "Plastic"
        self.reflectance: float = 0.0

        # Physics properties
        self.anchored: bool = False
        self.can_collide: bool = True
        self.mass: float = 1.0
        self.density: float = 1.0

        # Mesh data (for custom shapes)
        self.shape_type: str = "cube"
        self.mesh_vertices: Optional[List[List[float]]] = None
        self.mesh_faces: Optional[List[List[int]]] = None
        self.mesh_file: Optional[str] = None

        # Legacy compatibility attributes
        self.animation_speed: List[float] = [0.0, 0.0, 0.0]  # Rotation speed per axis
        self.prefab_name: Optional[str] = None  # Name of prefab this was spawned from

    def set_position(self, x: float, y: float, z: float):
        """Set position"""
        self.position = [float(x), float(y), float(z)]

    def set_rotation(self, rx: float, ry: float, rz: float):
        """Set rotation in degrees"""
        self.rotation = [float(rx), float(ry), float(rz)]

    def get_center(self) -> Tuple[float, float, float]:
        """Get center position"""
        return tuple(self.position)

    def to_dict(self) -> Dict:
        data = super().to_dict()
        data.update(
            {
                "position": self.position,
                "rotation": self.rotation,
                "scale": self.scale,
                "color": self.color,
                "transparency": self.transparency,
                "material": self.material,
                "anchored": self.anchored,
                "can_collide": self.can_collide,
                "mass": self.mass,
                "shape_type": self.shape_type,
                "mesh_file": self.mesh_file,
                "animation_speed": self.animation_speed,
                "prefab_name": self.prefab_name,
            }
        )
        if not self.mesh_file and self.mesh_vertices:
            data["mesh_vertices"] = self.mesh_vertices
            data["mesh_faces"] = self.mesh_faces
        return data


# ============================================================================
# 3D & VISUAL OBJECTS
# ============================================================================


class Part(BasePart):
    """Standard rectangular brick - the most common building block"""

    def __init__(self, name: str = "Part"):
        super().__init__(name)
        self.shape_type = "cube"


class WedgePart(BasePart):
    """Triangular wedge shape"""

    def __init__(self, name: str = "WedgePart"):
        super().__init__(name)
        self.shape_type = "wedge"


class CornerWedgePart(BasePart):
    """Corner wedge for building roofs and angles"""

    def __init__(self, name: str = "CornerWedgePart"):
        super().__init__(name)
        self.shape_type = "corner_wedge"


class SpherePart(BasePart):
    """Spherical part"""

    def __init__(self, name: str = "Sphere"):
        super().__init__(name)
        self.shape_type = "sphere"


class CylinderPart(BasePart):
    """Cylindrical part"""

    def __init__(self, name: str = "Cylinder"):
        super().__init__(name)
        self.shape_type = "cylinder"


class MeshPart(BasePart):
    """Custom mesh loaded from file"""

    def __init__(self, name: str = "MeshPart"):
        super().__init__(name)
        self.shape_type = "custom"

    def load_mesh_from_file(self, filepath: str) -> bool:
        """Load OBJ mesh file"""
        if not os.path.exists(filepath):
            return False
        try:
            vertices = []
            faces = []
            with open(filepath, "r", encoding="utf-8", errors="ignore") as fh:
                for line in fh:
                    if line.startswith("v "):
                        parts = line.strip().split()
                        if len(parts) >= 4:
                            vertices.append(
                                [float(parts[1]), float(parts[2]), float(parts[3])]
                            )
                    elif line.startswith("f "):
                        parts = line.strip().split()[1:]
                        face = []
                        for part in parts:
                            try:
                                idx = int(part.split("/")[0]) - 1
                                face.append(idx)
                            except ValueError:
                                pass
                        if len(face) >= 3:
                            faces.append(face[:3])
            self.mesh_vertices = vertices
            self.mesh_faces = faces
            self.mesh_file = filepath
            return True
        except Exception:
            return False


class Decal(Instance):
    """2D image applied to a surface of a Part"""

    def __init__(self, name: str = "Decal"):
        super().__init__(name)
        self.texture: str = ""  # Path to image file
        self.face: str = "Front"  # Which face: Front, Back, Left, Right, Top, Bottom
        self.transparency: float = 0.0
        self.color3: List[float] = [1.0, 1.0, 1.0]  # Tint color

    def to_dict(self) -> Dict:
        data = super().to_dict()
        data.update(
            {
                "texture": self.texture,
                "face": self.face,
                "transparency": self.transparency,
                "color3": self.color3,
            }
        )
        return data


class Texture(Decal):
    """Same as Decal but repeats/tiles"""

    def __init__(self, name: str = "Texture"):
        super().__init__(name)
        self.studs_per_tile_u: float = 2.0
        self.studs_per_tile_v: float = 2.0


class Camera(Instance):
    """Camera object for rendering viewpoint"""

    def __init__(self, name: str = "Camera"):
        super().__init__(name)
        self.position: List[float] = [0.0, 5.0, 10.0]
        self.look_at: List[float] = [0.0, 0.0, 0.0]
        self.field_of_view: float = 70.0  # Degrees
        self.camera_type: str = "Custom"  # Custom, Scriptable, Fixed

    def to_dict(self) -> Dict:
        data = super().to_dict()
        data.update(
            {
                "position": self.position,
                "look_at": self.look_at,
                "field_of_view": self.field_of_view,
                "camera_type": self.camera_type,
            }
        )
        return data


# ============================================================================
# GAMEPLAY & LIFE OBJECTS
# ============================================================================


class Humanoid(Instance):
    """Character controller - manages health, movement, and character state"""

    def __init__(self, name: str = "Humanoid"):
        super().__init__(name)

        # Health
        self.health: float = 100.0
        self.max_health: float = 100.0

        # Movement
        self.walk_speed: float = 16.0
        self.jump_power: float = 50.0
        self.auto_rotate: bool = True

        # State
        self.state: str = "Idle"  # Idle, Running, Jumping, Falling, Dead
        self.died: bool = False

        # Events (callbacks)
        self.on_died: Optional[Callable] = None
        self.on_health_changed: Optional[Callable[[float], None]] = None

    def take_damage(self, amount: float):
        """Apply damage to humanoid"""
        old_health = self.health
        self.health = max(0, self.health - amount)

        if self.on_health_changed:
            self.on_health_changed(self.health)

        if self.health <= 0 and not self.died:
            self.died = True
            self.state = "Dead"
            if self.on_died:
                self.on_died()

    def heal(self, amount: float):
        """Heal humanoid"""
        self.health = min(self.max_health, self.health + amount)
        if self.on_health_changed:
            self.on_health_changed(self.health)

    def to_dict(self) -> Dict:
        data = super().to_dict()
        data.update(
            {
                "health": self.health,
                "max_health": self.max_health,
                "walk_speed": self.walk_speed,
                "jump_power": self.jump_power,
                "state": self.state,
            }
        )
        return data


class Tool(Instance):
    """Equippable item (Sword, Gun, etc.)"""

    def __init__(self, name: str = "Tool"):
        super().__init__(name)
        self.equipped: bool = False
        self.can_be_dropped: bool = True
        self.requires_handle: bool = True

        # Events
        self.on_equipped: Optional[Callable] = None
        self.on_unequipped: Optional[Callable] = None
        self.on_activated: Optional[Callable] = None  # When clicked/used

    def equip(self):
        """Equip the tool"""
        if not self.equipped:
            self.equipped = True
            if self.on_equipped:
                self.on_equipped()

    def unequip(self):
        """Unequip the tool"""
        if self.equipped:
            self.equipped = False
            if self.on_unequipped:
                self.on_unequipped()

    def activate(self):
        """Use the tool (called when clicked)"""
        if self.equipped and self.on_activated:
            self.on_activated()


class Accessory(Instance):
    """Cosmetic item (Hat, Hair, etc.)"""

    def __init__(self, name: str = "Accessory"):
        super().__init__(name)
        self.attachment_point: str = "HairAttachment"  # Where to attach on character

    def to_dict(self) -> Dict:
        data = super().to_dict()
        data["attachment_point"] = self.attachment_point
        return data


# ============================================================================
# PHYSICS & MOVEMENT OBJECTS
# ============================================================================


class BodyVelocity(Instance):
    """Applies constant velocity to a part, overriding gravity"""

    def __init__(self, name: str = "BodyVelocity"):
        super().__init__(name)
        self.velocity: List[float] = [0.0, 0.0, 0.0]
        self.max_force: List[float] = [4000.0, 4000.0, 4000.0]

    def to_dict(self) -> Dict:
        data = super().to_dict()
        data.update(
            {
                "velocity": self.velocity,
                "max_force": self.max_force,
            }
        )
        return data


class BodyGyro(Instance):
    """Maintains a part's orientation (prevents tipping)"""

    def __init__(self, name: str = "BodyGyro"):
        super().__init__(name)
        self.cframe: List[float] = [0.0, 0.0, 0.0]  # Target rotation
        self.max_torque: List[float] = [4000.0, 4000.0, 4000.0]
        self.d: float = 500.0  # Dampening
        self.p: float = 3000.0  # Power

    def to_dict(self) -> Dict:
        data = super().to_dict()
        data.update(
            {
                "cframe": self.cframe,
                "max_torque": self.max_torque,
                "d": self.d,
                "p": self.p,
            }
        )
        return data


class BodyPosition(Instance):
    """Moves a part toward a target position"""

    def __init__(self, name: str = "BodyPosition"):
        super().__init__(name)
        self.position: List[float] = [0.0, 0.0, 0.0]
        self.max_force: List[float] = [4000.0, 4000.0, 4000.0]
        self.d: float = 1250.0
        self.p: float = 10000.0

    def to_dict(self) -> Dict:
        data = super().to_dict()
        data.update(
            {
                "position": self.position,
                "max_force": self.max_force,
                "d": self.d,
                "p": self.p,
            }
        )
        return data


class Explosion(Instance):
    """Creates an explosion that pushes parts and damages humanoids"""

    def __init__(self, name: str = "Explosion"):
        super().__init__(name)
        self.position: List[float] = [0.0, 0.0, 0.0]
        self.blast_radius: float = 12.0
        self.blast_pressure: float = 500000.0
        self.destroy_joint_radius_percent: float = 1.0

        # When created, explosion triggers immediately
        self.triggered: bool = False

    def trigger(self, parts: List[BasePart], humanoids: List[Humanoid]):
        """Execute explosion effects"""
        if self.triggered:
            return
        self.triggered = True

        # Apply forces to nearby parts
        for part in parts:
            if isinstance(part, BasePart):
                distance = self._distance_to(part.position)
                if distance < self.blast_radius:
                    # Calculate impulse force (inverse square)
                    force_magnitude = self.blast_pressure / max(1, distance**2)
                    direction = self._normalize(
                        [
                            part.position[0] - self.position[0],
                            part.position[1] - self.position[1],
                            part.position[2] - self.position[2],
                        ]
                    )
                    # Apply impulse (would connect to physics engine)
                    part.properties["explosion_force"] = [
                        d * force_magnitude for d in direction
                    ]

        # Damage humanoids in range
        for humanoid in humanoids:
            # Find humanoid's root part to get position
            # In real implementation, we'd traverse parent to find position
            # For now, store damage in properties
            distance = self.blast_radius / 2  # Placeholder
            if distance < self.blast_radius:
                damage = 100 * (1 - distance / self.blast_radius)
                humanoid.take_damage(damage)

    def _distance_to(self, other_pos: List[float]) -> float:
        """Calculate distance to position"""
        dx = other_pos[0] - self.position[0]
        dy = other_pos[1] - self.position[1]
        dz = other_pos[2] - self.position[2]
        return math.sqrt(dx * dx + dy * dy + dz * dz)

    def _normalize(self, vec: List[float]) -> List[float]:
        """Normalize vector"""
        length = math.sqrt(sum(v * v for v in vec))
        if length == 0:
            return [0, 0, 0]
        return [v / length for v in vec]

    def to_dict(self) -> Dict:
        data = super().to_dict()
        data.update(
            {
                "position": self.position,
                "blast_radius": self.blast_radius,
                "blast_pressure": self.blast_pressure,
            }
        )
        return data


# ============================================================================
# INTERACTION OBJECTS
# ============================================================================


class ClickDetector(Instance):
    """Detects when a part is clicked"""

    def __init__(self, name: str = "ClickDetector"):
        super().__init__(name)
        self.max_activation_distance: float = 32.0
        self.cursor_icon: str = ""

        # Events
        self.on_mouse_click: Optional[Callable] = None
        self.on_mouse_hover_enter: Optional[Callable] = None
        self.on_mouse_hover_leave: Optional[Callable] = None

    def check_click(
        self, player_position: List[float], click_position: List[float]
    ) -> bool:
        """Check if click is within range"""
        distance = math.sqrt(
            sum((a - b) ** 2 for a, b in zip(player_position, click_position))
        )
        if distance <= self.max_activation_distance:
            if self.on_mouse_click:
                self.on_mouse_click()
            return True
        return False

    def to_dict(self) -> Dict:
        data = super().to_dict()
        data["max_activation_distance"] = self.max_activation_distance
        return data


class ProximityPrompt(Instance):
    """Shows 'Press E to interact' UI when player is near"""

    def __init__(self, name: str = "ProximityPrompt"):
        super().__init__(name)
        self.action_text: str = "Interact"
        self.object_text: str = ""
        self.key_code: str = "E"
        self.max_activation_distance: float = 10.0
        self.hold_duration: float = 0.0  # 0 = instant, >0 = hold key
        self.enabled: bool = True

        # Events
        self.on_triggered: Optional[Callable] = None
        self.on_prompt_shown: Optional[Callable] = None
        self.on_prompt_hidden: Optional[Callable] = None

    def check_distance(
        self, player_position: List[float], prompt_position: List[float]
    ) -> bool:
        """Check if player is in range"""
        distance = math.sqrt(
            sum((a - b) ** 2 for a, b in zip(player_position, prompt_position))
        )
        return distance <= self.max_activation_distance

    def to_dict(self) -> Dict:
        data = super().to_dict()
        data.update(
            {
                "action_text": self.action_text,
                "object_text": self.object_text,
                "key_code": self.key_code,
                "max_activation_distance": self.max_activation_distance,
                "hold_duration": self.hold_duration,
            }
        )
        return data


# ============================================================================
# SCRIPTING & LOGIC OBJECTS
# ============================================================================


class Script(Instance):
    """Server-side script that runs game logic"""

    def __init__(self, name: str = "Script"):
        super().__init__(name)
        self.source: str = "-- Server Script\nprint('Hello from server')"
        self.disabled: bool = False
        self.script_path: Optional[str] = None  # Path to .lua file

    def run(self, lua_runtime):
        """Execute script in Lua runtime"""
        if not self.disabled and self.source:
            lua_runtime.load_script(self.name, self.source)

    def to_dict(self) -> Dict:
        data = super().to_dict()
        data.update(
            {
                "source": self.source,
                "disabled": self.disabled,
                "script_path": self.script_path,
            }
        )
        return data


class LocalScript(Script):
    """Client-side script (runs only for the player)"""

    def __init__(self, name: str = "LocalScript"):
        super().__init__(name)
        self.source = "-- Local Script\nprint('Hello from client')"


class ModuleScript(Script):
    """Reusable script module that can be required by other scripts"""

    def __init__(self, name: str = "ModuleScript"):
        super().__init__(name)
        self.source = "-- Module Script\nlocal module = {}\nreturn module"


class BindableEvent(Instance):
    """Event that scripts can connect to for inter-script communication"""

    def __init__(self, name: str = "BindableEvent"):
        super().__init__(name)
        self.connections: List[Callable] = []

    def connect(self, callback: Callable):
        """Connect a callback to this event"""
        self.connections.append(callback)

    def fire(self, *args):
        """Fire the event, calling all connected callbacks"""
        for callback in self.connections:
            try:
                callback(*args)
            except Exception as e:
                print(f"BindableEvent error: {e}")


class BindableFunction(Instance):
    """Function that can be invoked from other scripts"""

    def __init__(self, name: str = "BindableFunction"):
        super().__init__(name)
        self.callback: Optional[Callable] = None

    def invoke(self, *args) -> Any:
        """Invoke the bound function"""
        if self.callback:
            return self.callback(*args)
        return None


# ============================================================================
# DATA VALUE OBJECTS
# ============================================================================


class ValueBase(Instance):
    """Base class for all value containers"""

    def __init__(self, name: str = "Value"):
        super().__init__(name)
        self.changed_callbacks: List[Callable] = []

    def connect_changed(self, callback: Callable):
        """Connect to value changed event"""
        self.changed_callbacks.append(callback)

    def _notify_changed(self, new_value):
        """Notify all listeners of value change"""
        for callback in self.changed_callbacks:
            try:
                callback(new_value)
            except Exception:
                pass


class BoolValue(ValueBase):
    """Boolean value container"""

    def __init__(self, name: str = "BoolValue"):
        super().__init__(name)
        self._value: bool = False

    @property
    def value(self) -> bool:
        return self._value

    @value.setter
    def value(self, new_value: bool):
        old = self._value
        self._value = bool(new_value)
        if old != self._value:
            self._notify_changed(self._value)

    def to_dict(self) -> Dict:
        data = super().to_dict()
        data["value"] = self._value
        return data


class IntValue(ValueBase):
    """Integer value container"""

    def __init__(self, name: str = "IntValue"):
        super().__init__(name)
        self._value: int = 0

    @property
    def value(self) -> int:
        return self._value

    @value.setter
    def value(self, new_value: int):
        old = self._value
        self._value = int(new_value)
        if old != self._value:
            self._notify_changed(self._value)

    def to_dict(self) -> Dict:
        data = super().to_dict()
        data["value"] = self._value
        return data


class NumberValue(ValueBase):
    """Float/Number value container"""

    def __init__(self, name: str = "NumberValue"):
        super().__init__(name)
        self._value: float = 0.0

    @property
    def value(self) -> float:
        return self._value

    @value.setter
    def value(self, new_value: float):
        old = self._value
        self._value = float(new_value)
        if abs(old - self._value) > 1e-9:  # Float comparison tolerance
            self._notify_changed(self._value)

    def to_dict(self) -> Dict:
        data = super().to_dict()
        data["value"] = self._value
        return data


class StringValue(ValueBase):
    """String value container"""

    def __init__(self, name: str = "StringValue"):
        super().__init__(name)
        self._value: str = ""

    @property
    def value(self) -> str:
        return self._value

    @value.setter
    def value(self, new_value: str):
        old = self._value
        self._value = str(new_value)
        if old != self._value:
            self._notify_changed(self._value)

    def to_dict(self) -> Dict:
        data = super().to_dict()
        data["value"] = self._value
        return data


class Vector3Value(ValueBase):
    """3D vector value container"""

    def __init__(self, name: str = "Vector3Value"):
        super().__init__(name)
        self._value: List[float] = [0.0, 0.0, 0.0]

    @property
    def value(self) -> List[float]:
        return self._value

    @value.setter
    def value(self, new_value: List[float]):
        old = self._value[:]
        self._value = [float(v) for v in new_value[:3]]
        if old != self._value:
            self._notify_changed(self._value)

    def to_dict(self) -> Dict:
        data = super().to_dict()
        data["value"] = self._value
        return data


class CFrameValue(ValueBase):
    """CFrame (position + rotation) value container"""

    def __init__(self, name: str = "CFrameValue"):
        super().__init__(name)
        # Store as [x, y, z, rx, ry, rz]
        self._value: List[float] = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]

    @property
    def value(self) -> List[float]:
        return self._value

    @value.setter
    def value(self, new_value: List[float]):
        old = self._value[:]
        self._value = [float(v) for v in new_value[:6]]
        if old != self._value:
            self._notify_changed(self._value)

    def to_dict(self) -> Dict:
        data = super().to_dict()
        data["value"] = self._value
        return data


# ============================================================================
# ADVANCED OBJECTS - Full Roblox-Style Implementation
# ============================================================================


class SpawnLocation(BasePart):
    """Player spawn point - players respawn here when they die"""

    _instance = None  # Singleton tracking

    def __init__(self, name: str = "SpawnLocation"):
        super().__init__(name)
        self.shape_type = "spawn"
        self.color = [0.2, 0.8, 0.4]  # Green spawn plate
        self.scale = [6.0, 0.5, 6.0]  # Flat platform
        self.team_color = ""  # For team-based spawning
        self.neutral = True  # Anyone can spawn here
        self.allow_team_change_on_touch = False
        self.duration = 0.0  # Spawn protection duration
        self.enabled = True

    def to_dict(self) -> Dict:
        data = super().to_dict()
        data.update(
            {
                "team_color": self.team_color,
                "neutral": self.neutral,
                "allow_team_change_on_touch": self.allow_team_change_on_touch,
                "duration": self.duration,
                "enabled": self.enabled,
            }
        )
        return data


class Sound(Instance):
    """Audio playback object"""

    def __init__(self, name: str = "Sound"):
        super().__init__(name)
        self.sound_id: str = ""  # Path to audio file
        self.volume: float = 0.5
        self.pitch: float = 1.0
        self.looped: bool = False
        self.playing: bool = False
        self.time_position: float = 0.0
        self.time_length: float = 0.0
        self.playback_speed: float = 1.0
        self.rolloff_mode: str = "Inverse"  # Inverse, Linear, InverseTapered
        self.rolloff_min_distance: float = 10.0
        self.rolloff_max_distance: float = 10000.0

        # Events
        self.on_ended: Optional[Callable] = None
        self.on_played: Optional[Callable] = None

    def play(self):
        """Start audio playback"""
        self.playing = True
        self.time_position = 0.0
        if self.on_played:
            self.on_played()

    def stop(self):
        """Stop audio playback"""
        self.playing = False
        self.time_position = 0.0

    def pause(self):
        """Pause audio playback"""
        self.playing = False

    def resume(self):
        """Resume audio playback"""
        self.playing = True

    def to_dict(self) -> Dict:
        data = super().to_dict()
        data.update(
            {
                "sound_id": self.sound_id,
                "volume": self.volume,
                "pitch": self.pitch,
                "looped": self.looped,
                "playback_speed": self.playback_speed,
                "rolloff_mode": self.rolloff_mode,
                "rolloff_min_distance": self.rolloff_min_distance,
                "rolloff_max_distance": self.rolloff_max_distance,
            }
        )
        return data


class Animation(Instance):
    """Animation asset reference"""

    def __init__(self, name: str = "Animation"):
        super().__init__(name)
        self.animation_id: str = ""  # Path to .meplanim file
        self.priority: str = "Core"  # Idle, Movement, Action, Core

    def to_dict(self) -> Dict:
        data = super().to_dict()
        data.update(
            {
                "animation_id": self.animation_id,
                "priority": self.priority,
            }
        )
        return data


class AnimationController(Instance):
    """Controls animations on a model (for non-humanoid rigs)"""

    def __init__(self, name: str = "AnimationController"):
        super().__init__(name)
        self.current_animation: Optional[str] = None
        self.animations: Dict[str, "AnimationTrack"] = {}

    def load_animation(self, animation: Animation) -> "AnimationTrack":
        """Load an animation and return a track for it"""
        track = AnimationTrack(animation.name)
        track.animation = animation
        self.animations[animation.name] = track
        return track


class AnimationTrack:
    """Runtime animation playback controller"""

    def __init__(self, name: str = "AnimationTrack"):
        self.name = name
        self.animation: Optional[Animation] = None
        self.is_playing: bool = False
        self.looped: bool = False
        self.speed: float = 1.0
        self.weight: float = 1.0
        self.time_position: float = 0.0
        self.length: float = 0.0
        self.priority: str = "Core"

        # Events
        self.on_stopped: Optional[Callable] = None
        self.on_keyframe_reached: Optional[Callable[[str], None]] = None

    def play(self, fade_time: float = 0.1, weight: float = 1.0, speed: float = 1.0):
        """Start playing the animation"""
        self.is_playing = True
        self.time_position = 0.0
        self.weight = weight
        self.speed = speed

    def stop(self, fade_time: float = 0.1):
        """Stop the animation"""
        self.is_playing = False
        if self.on_stopped:
            self.on_stopped()

    def adjust_speed(self, speed: float):
        """Adjust playback speed"""
        self.speed = speed

    def adjust_weight(self, weight: float, fade_time: float = 0.1):
        """Adjust blend weight"""
        self.weight = max(0.0, min(1.0, weight))


class Animator(Instance):
    """Humanoid animation controller"""

    def __init__(self, name: str = "Animator"):
        super().__init__(name)
        self.tracks: Dict[str, AnimationTrack] = {}

    def load_animation(self, animation: Animation) -> AnimationTrack:
        """Load animation and return playable track"""
        track = AnimationTrack(animation.name)
        track.animation = animation
        self.tracks[animation.name] = track
        return track

    def get_playing_animation_tracks(self) -> List[AnimationTrack]:
        """Get list of currently playing tracks"""
        return [t for t in self.tracks.values() if t.is_playing]


class Motor6D(Instance):
    """
    Rigid joint connecting two parts for rigging/animation.
    The transform of Part1 is calculated as:
    Part1.CFrame = Part0.CFrame * C0 * Motor.Transform * C1:Inverse()
    """

    def __init__(self, name: str = "Motor6D"):
        super().__init__(name)
        self.part0: Optional[str] = None  # ID of first part
        self.part1: Optional[str] = None  # ID of second part
        # C0: Offset from Part0's center to joint
        self.c0_position: List[float] = [0.0, 0.0, 0.0]
        self.c0_rotation: List[float] = [0.0, 0.0, 0.0]
        # C1: Offset from Part1's center to joint
        self.c1_position: List[float] = [0.0, 0.0, 0.0]
        self.c1_rotation: List[float] = [0.0, 0.0, 0.0]
        # Current transform (set by animation)
        self.current_angle: float = 0.0
        self.desired_angle: float = 0.0
        self.max_velocity: float = 0.0
        self.enabled: bool = True

    def to_dict(self) -> Dict:
        data = super().to_dict()
        data.update(
            {
                "part0": self.part0,
                "part1": self.part1,
                "c0_position": self.c0_position,
                "c0_rotation": self.c0_rotation,
                "c1_position": self.c1_position,
                "c1_rotation": self.c1_rotation,
                "current_angle": self.current_angle,
                "enabled": self.enabled,
            }
        )
        return data


class Weld(Instance):
    """Rigid weld between two parts (no relative movement)"""

    def __init__(self, name: str = "Weld"):
        super().__init__(name)
        self.part0: Optional[str] = None
        self.part1: Optional[str] = None
        self.c0_position: List[float] = [0.0, 0.0, 0.0]
        self.c0_rotation: List[float] = [0.0, 0.0, 0.0]
        self.c1_position: List[float] = [0.0, 0.0, 0.0]
        self.c1_rotation: List[float] = [0.0, 0.0, 0.0]
        self.enabled: bool = True

    def to_dict(self) -> Dict:
        data = super().to_dict()
        data.update(
            {
                "part0": self.part0,
                "part1": self.part1,
                "c0_position": self.c0_position,
                "c0_rotation": self.c0_rotation,
                "c1_position": self.c1_position,
                "c1_rotation": self.c1_rotation,
                "enabled": self.enabled,
            }
        )
        return data


# ============================================================================
# CONSTRAINT OBJECTS
# ============================================================================


class Constraint(Instance):
    """Base class for physics constraints"""

    def __init__(self, name: str = "Constraint"):
        super().__init__(name)
        self.attachment0: Optional[str] = None  # First attachment point ID
        self.attachment1: Optional[str] = None  # Second attachment point ID
        self.enabled: bool = True
        self.visible: bool = True
        self.color: List[float] = [0.2, 0.4, 1.0]  # Blue

    def to_dict(self) -> Dict:
        data = super().to_dict()
        data.update(
            {
                "attachment0": self.attachment0,
                "attachment1": self.attachment1,
                "enabled": self.enabled,
                "color": self.color,
            }
        )
        return data


class Attachment(Instance):
    """Attachment point on a part for constraints"""

    def __init__(self, name: str = "Attachment"):
        super().__init__(name)
        self.position: List[float] = [0.0, 0.0, 0.0]  # Local offset
        self.rotation: List[float] = [0.0, 0.0, 0.0]  # Local rotation
        self.axis: List[float] = [1.0, 0.0, 0.0]  # Primary axis
        self.secondary_axis: List[float] = [0.0, 1.0, 0.0]

    def to_dict(self) -> Dict:
        data = super().to_dict()
        data.update(
            {
                "position": self.position,
                "rotation": self.rotation,
                "axis": self.axis,
                "secondary_axis": self.secondary_axis,
            }
        )
        return data


class BallSocketConstraint(Constraint):
    """Ball and socket joint allowing rotation in all directions"""

    def __init__(self, name: str = "BallSocketConstraint"):
        super().__init__(name)
        self.limits_enabled: bool = False
        self.upper_angle: float = 45.0
        self.twist_limits_enabled: bool = False
        self.twist_lower_angle: float = -45.0
        self.twist_upper_angle: float = 45.0
        self.restitution: float = 0.0


class HingeConstraint(Constraint):
    """Hinge joint allowing rotation around one axis (like a door)"""

    def __init__(self, name: str = "HingeConstraint"):
        super().__init__(name)
        self.limits_enabled: bool = False
        self.lower_angle: float = -45.0
        self.upper_angle: float = 45.0
        self.angular_velocity: float = 0.0
        self.motor_max_torque: float = 0.0
        self.servo_max_torque: float = 0.0
        self.target_angle: float = 0.0
        self.actuator_type: str = "None"  # None, Motor, Servo


class PrismaticConstraint(Constraint):
    """Sliding joint allowing movement along one axis"""

    def __init__(self, name: str = "PrismaticConstraint"):
        super().__init__(name)
        self.limits_enabled: bool = False
        self.lower_limit: float = 0.0
        self.upper_limit: float = 5.0
        self.velocity: float = 0.0
        self.motor_max_force: float = 0.0
        self.servo_max_force: float = 0.0
        self.target_position: float = 0.0
        self.actuator_type: str = "None"  # None, Motor, Servo


class SpringConstraint(Constraint):
    """Spring between two attachments"""

    def __init__(self, name: str = "SpringConstraint"):
        super().__init__(name)
        self.free_length: float = 1.0
        self.stiffness: float = 100.0
        self.damping: float = 0.0
        self.min_length: float = 0.0
        self.max_length: float = 5.0
        self.limits_enabled: bool = False
        self.coils: int = 8


class RopeConstraint(Constraint):
    """Rope connecting two points"""

    def __init__(self, name: str = "RopeConstraint"):
        super().__init__(name)
        self.length: float = 5.0
        self.restitution: float = 0.5
        self.thickness: float = 0.1


class RodConstraint(Constraint):
    """Rigid rod keeping two points at fixed distance"""

    def __init__(self, name: str = "RodConstraint"):
        super().__init__(name)
        self.length: float = 3.0
        self.thickness: float = 0.2


class VelocityMotor(Instance):
    """Motor that applies constant velocity"""

    def __init__(self, name: str = "VelocityMotor"):
        super().__init__(name)
        self.current_angle: float = 0.0
        self.desired_angle: float = 0.0
        self.max_velocity: float = 1.0


# ============================================================================
# GUI OBJECTS
# ============================================================================


class ScreenGui(Instance):
    """Container for 2D UI elements on screen"""

    def __init__(self, name: str = "ScreenGui"):
        super().__init__(name)
        self.enabled: bool = True
        self.display_order: int = 0
        self.ignore_gui_inset: bool = False
        self.reset_on_spawn: bool = True

    def to_dict(self) -> Dict:
        data = super().to_dict()
        data.update(
            {
                "enabled": self.enabled,
                "display_order": self.display_order,
                "ignore_gui_inset": self.ignore_gui_inset,
                "reset_on_spawn": self.reset_on_spawn,
            }
        )
        return data


class SurfaceGui(Instance):
    """UI that displays on a part's surface"""

    def __init__(self, name: str = "SurfaceGui"):
        super().__init__(name)
        self.face: str = "Front"  # Front, Back, Left, Right, Top, Bottom
        self.enabled: bool = True
        self.always_on_top: bool = False
        self.light_influence: float = 0.0
        self.pixels_per_stud: float = 50.0
        self.adornee: Optional[str] = None  # Part ID to attach to

    def to_dict(self) -> Dict:
        data = super().to_dict()
        data.update(
            {
                "face": self.face,
                "enabled": self.enabled,
                "always_on_top": self.always_on_top,
                "light_influence": self.light_influence,
                "pixels_per_stud": self.pixels_per_stud,
                "adornee": self.adornee,
            }
        )
        return data


class BillboardGui(Instance):
    """UI that always faces the camera (like name tags)"""

    def __init__(self, name: str = "BillboardGui"):
        super().__init__(name)
        self.enabled: bool = True
        self.always_on_top: bool = False
        self.size_offset: List[int] = [0, 0]
        self.stud_offset: List[float] = [0.0, 2.0, 0.0]  # Offset from part
        self.max_distance: float = 50.0
        self.light_influence: float = 0.0
        self.adornee: Optional[str] = None

    def to_dict(self) -> Dict:
        data = super().to_dict()
        data.update(
            {
                "enabled": self.enabled,
                "always_on_top": self.always_on_top,
                "stud_offset": self.stud_offset,
                "max_distance": self.max_distance,
                "adornee": self.adornee,
            }
        )
        return data


class GuiObject(Instance):
    """Base class for GUI elements"""

    def __init__(self, name: str = "GuiObject"):
        super().__init__(name)
        self.position: List[float] = [0.0, 0.0]  # UDim2 simplified
        self.size: List[float] = [100.0, 100.0]
        self.anchor_point: List[float] = [0.0, 0.0]
        self.background_color3: List[float] = [1.0, 1.0, 1.0]
        self.background_transparency: float = 0.0
        self.border_color3: List[float] = [0.0, 0.0, 0.0]
        self.border_size_pixel: int = 1
        self.rotation: float = 0.0
        self.z_index: int = 1
        self.layout_order: int = 0


class Frame(GuiObject):
    """Container frame for other GUI elements"""

    def __init__(self, name: str = "Frame"):
        super().__init__(name)


class TextLabel(GuiObject):
    """Text display element"""

    def __init__(self, name: str = "TextLabel"):
        super().__init__(name)
        self.text: str = "Label"
        self.text_color3: List[float] = [0.0, 0.0, 0.0]
        self.text_size: int = 14
        self.font: str = "SourceSans"
        self.text_x_alignment: str = "Center"
        self.text_y_alignment: str = "Center"
        self.text_wrapped: bool = False
        self.text_scaled: bool = False


class TextButton(TextLabel):
    """Clickable button with text"""

    def __init__(self, name: str = "TextButton"):
        super().__init__(name)
        self.text = "Button"
        self.auto_button_color: bool = True
        # Events
        self.on_click: Optional[Callable] = None

    def click(self):
        if self.on_click:
            self.on_click()


class TextBox(TextLabel):
    """Text input field"""

    def __init__(self, name: str = "TextBox"):
        super().__init__(name)
        self.text = ""
        self.placeholder_text: str = "Enter text..."
        self.placeholder_color3: List[float] = [0.5, 0.5, 0.5]
        self.clear_text_on_focus: bool = False
        self.multi_line: bool = False
        # Events
        self.on_focus_lost: Optional[Callable[[str, bool], None]] = None


class ImageLabel(GuiObject):
    """Image display element"""

    def __init__(self, name: str = "ImageLabel"):
        super().__init__(name)
        self.image: str = ""  # Path to image
        self.image_color3: List[float] = [1.0, 1.0, 1.0]
        self.image_transparency: float = 0.0
        self.scale_type: str = "Stretch"  # Stretch, Slice, Tile, Fit, Crop


class ImageButton(ImageLabel):
    """Clickable button with image"""

    def __init__(self, name: str = "ImageButton"):
        super().__init__(name)
        self.hover_image: str = ""
        self.pressed_image: str = ""
        # Events
        self.on_click: Optional[Callable] = None


# ============================================================================
# SELECTION & DEBUG OBJECTS
# ============================================================================


class SelectionBox(Instance):
    """Visual selection indicator around a part"""

    def __init__(self, name: str = "SelectionBox"):
        super().__init__(name)
        self.adornee: Optional[str] = None  # Part ID to highlight
        self.color3: List[float] = [0.0, 0.5, 1.0]
        self.line_thickness: float = 0.05
        self.surface_color3: List[float] = [0.0, 0.5, 1.0]
        self.surface_transparency: float = 0.9


class SelectionSphere(Instance):
    """Spherical selection indicator"""

    def __init__(self, name: str = "SelectionSphere"):
        super().__init__(name)
        self.adornee: Optional[str] = None
        self.color3: List[float] = [0.0, 0.5, 1.0]
        self.surface_color3: List[float] = [0.0, 0.5, 1.0]
        self.surface_transparency: float = 0.9


class ForceField(Instance):
    """Protective barrier around a character"""

    def __init__(self, name: str = "ForceField"):
        super().__init__(name)
        self.color: List[float] = [0.0, 0.5, 1.0]

    def to_dict(self) -> Dict:
        data = super().to_dict()
        data["color"] = self.color
        return data


# ============================================================================
# PLAYER & CHARACTER OBJECTS
# ============================================================================


class Backpack(Instance):
    """Container for player's tools"""

    def __init__(self, name: str = "Backpack"):
        super().__init__(name)


class PlayerGui(Instance):
    """Container for player's GUI"""

    def __init__(self, name: str = "PlayerGui"):
        super().__init__(name)


class HumanoidRootPart(BasePart):
    """
    The root part of a character model.
    All other body parts are connected to this via Motor6Ds.
    """

    def __init__(self, name: str = "HumanoidRootPart"):
        super().__init__(name)
        self.shape_type = "cube"
        self.color = [0.8, 0.7, 0.6]  # Skin tone
        self.scale = [2.0, 2.0, 1.0]
        self.can_collide = False  # Root part doesn't collide
        self.transparency = 1.0  # Usually invisible


class BodyPart(BasePart):
    """Base for character body parts"""

    def __init__(self, name: str = "BodyPart"):
        super().__init__(name)
        self.shape_type = "cube"
        self.color = [0.8, 0.7, 0.6]  # Skin tone


class Head(BodyPart):
    """Character head"""

    def __init__(self, name: str = "Head"):
        super().__init__(name)
        self.scale = [1.2, 1.2, 1.2]
        self.mesh_type = "Head"  # Special head mesh


class Torso(BodyPart):
    """Character torso"""

    def __init__(self, name: str = "Torso"):
        super().__init__(name)
        self.scale = [2.0, 2.0, 1.0]


class LeftArm(BodyPart):
    """Character left arm"""

    def __init__(self, name: str = "Left Arm"):
        super().__init__(name)
        self.scale = [1.0, 2.0, 1.0]


class RightArm(BodyPart):
    """Character right arm"""

    def __init__(self, name: str = "Right Arm"):
        super().__init__(name)
        self.scale = [1.0, 2.0, 1.0]


class LeftLeg(BodyPart):
    """Character left leg"""

    def __init__(self, name: str = "Left Leg"):
        super().__init__(name)
        self.scale = [1.0, 2.0, 1.0]


class RightLeg(BodyPart):
    """Character right leg"""

    def __init__(self, name: str = "Right Leg"):
        super().__init__(name)
        self.scale = [1.0, 2.0, 1.0]


# ============================================================================
# TERRAIN & ENVIRONMENT
# ============================================================================


class TerrainRegion(Instance):
    """Voxel-based terrain chunk"""

    def __init__(self, name: str = "TerrainRegion"):
        super().__init__(name)
        self.position: List[float] = [0.0, 0.0, 0.0]
        self.size: List[int] = [64, 64, 64]  # Voxels
        self.material: str = "Grass"


# ============================================================================
# REMOTE EVENTS (Client-Server Communication)
# ============================================================================


class RemoteEvent(Instance):
    """Event for client-server communication"""

    def __init__(self, name: str = "RemoteEvent"):
        super().__init__(name)
        self.server_connections: List[Callable] = []
        self.client_connections: List[Callable] = []

    def fire_server(self, *args):
        """Client fires to server"""
        for callback in self.server_connections:
            try:
                callback(*args)
            except Exception as e:
                print(f"RemoteEvent server error: {e}")

    def fire_client(self, *args):
        """Server fires to client"""
        for callback in self.client_connections:
            try:
                callback(*args)
            except Exception as e:
                print(f"RemoteEvent client error: {e}")

    def on_server_event(self, callback: Callable):
        """Connect server-side handler"""
        self.server_connections.append(callback)

    def on_client_event(self, callback: Callable):
        """Connect client-side handler"""
        self.client_connections.append(callback)


class RemoteFunction(Instance):
    """Function call between client and server"""

    def __init__(self, name: str = "RemoteFunction"):
        super().__init__(name)
        self.on_server_invoke: Optional[Callable] = None
        self.on_client_invoke: Optional[Callable] = None

    def invoke_server(self, *args) -> Any:
        """Client calls server"""
        if self.on_server_invoke:
            return self.on_server_invoke(*args)
        return None

    def invoke_client(self, *args) -> Any:
        """Server calls client"""
        if self.on_client_invoke:
            return self.on_client_invoke(*args)
        return None


# ============================================================================
# ADDITIONAL VALUE TYPES
# ============================================================================


class ObjectValue(ValueBase):
    """Reference to another Instance"""

    def __init__(self, name: str = "ObjectValue"):
        super().__init__(name)
        self._value: Optional[str] = None  # Object ID

    @property
    def value(self) -> Optional[str]:
        return self._value

    @value.setter
    def value(self, new_value: Optional[str]):
        old = self._value
        self._value = new_value
        if old != self._value:
            self._notify_changed(self._value)


class BrickColorValue(ValueBase):
    """BrickColor value (Roblox color palette)"""

    def __init__(self, name: str = "BrickColorValue"):
        super().__init__(name)
        self._value: str = "Medium stone grey"  # BrickColor name

    @property
    def value(self) -> str:
        return self._value

    @value.setter
    def value(self, new_value: str):
        old = self._value
        self._value = str(new_value)
        if old != self._value:
            self._notify_changed(self._value)


class Color3Value(ValueBase):
    """RGB color value"""

    def __init__(self, name: str = "Color3Value"):
        super().__init__(name)
        self._value: List[float] = [1.0, 1.0, 1.0]

    @property
    def value(self) -> List[float]:
        return self._value

    @value.setter
    def value(self, new_value: List[float]):
        old = self._value[:]
        self._value = [float(v) for v in new_value[:3]]
        if old != self._value:
            self._notify_changed(self._value)


class RayValue(ValueBase):
    """Ray value (origin + direction)"""

    def __init__(self, name: str = "RayValue"):
        super().__init__(name)
        self._origin: List[float] = [0.0, 0.0, 0.0]
        self._direction: List[float] = [0.0, 0.0, 1.0]

    @property
    def origin(self) -> List[float]:
        return self._origin

    @property
    def direction(self) -> List[float]:
        return self._direction


class Accoutrement(Instance):
    """Wearable item (old name for Accessory)"""

    def __init__(self, name: str = "Accoutrement"):
        super().__init__(name)
        self.attachment_point: str = "HatAttachment"


# ============================================================================
# FOLDER & ORGANIZATIONAL OBJECTS
# ============================================================================


class Folder(Instance):
    """Container for organizing objects in hierarchy"""

    def __init__(self, name: str = "Folder"):
        super().__init__(name)


class Model(Instance):
    """Group of parts that form a single object"""

    def __init__(self, name: str = "Model"):
        super().__init__(name)
        self.primary_part: Optional[str] = None  # ID of the "root" part
        # Model has a virtual position (calculated from children center)
        self._position: List[float] = [0.0, 0.0, 0.0]

    @property
    def position(self) -> List[float]:
        """Get center position of all children parts"""
        parts = [
            child for child in self.get_descendants() if isinstance(child, BasePart)
        ]
        if not parts:
            return self._position
        center = [0.0, 0.0, 0.0]
        for part in parts:
            for i in range(3):
                center[i] += part.position[i]
        for i in range(3):
            center[i] /= len(parts)
        return center

    @position.setter
    def position(self, value: List[float]):
        """Move all children parts by offset"""
        old_pos = self.position
        offset = [value[i] - old_pos[i] for i in range(3)]
        for child in self.get_descendants():
            if isinstance(child, BasePart):
                for i in range(3):
                    child.position[i] += offset[i]
        self._position = value

    def get_extents(self) -> Tuple[List[float], List[float]]:
        """Get bounding box of all parts in model"""
        parts = [
            child for child in self.get_descendants() if isinstance(child, BasePart)
        ]
        if not parts:
            return ([0, 0, 0], [0, 0, 0])

        min_pos = [float("inf")] * 3
        max_pos = [float("-inf")] * 3

        for part in parts:
            for i in range(3):
                min_pos[i] = min(min_pos[i], part.position[i] - part.scale[i] / 2)
                max_pos[i] = max(max_pos[i], part.position[i] + part.scale[i] / 2)

        return (min_pos, max_pos)

    def to_dict(self) -> Dict:
        data = super().to_dict()
        data["primary_part"] = self.primary_part
        return data


# ============================================================================
# BACKWARD COMPATIBILITY
# ============================================================================

# Keep GameObject3D as alias to BasePart for backward compatibility
GameObject3D = BasePart


# ============================================================================
# INSTANCE FACTORY
# ============================================================================


def create_instance(class_name: str, name: Optional[str] = None) -> Instance:
    """Factory function to create instances by class name"""
    class_map = {
        # 3D Objects
        "Part": Part,
        "WedgePart": WedgePart,
        "CornerWedgePart": CornerWedgePart,
        "Sphere": SpherePart,
        "Cylinder": CylinderPart,
        "MeshPart": MeshPart,
        "SpawnLocation": SpawnLocation,
        # Visual
        "Decal": Decal,
        "Texture": Texture,
        "Camera": Camera,
        # Gameplay
        "Humanoid": Humanoid,
        "Tool": Tool,
        "Accessory": Accessory,
        "Accoutrement": Accoutrement,
        "Backpack": Backpack,
        "ForceField": ForceField,
        # Physics
        "BodyVelocity": BodyVelocity,
        "BodyGyro": BodyGyro,
        "BodyPosition": BodyPosition,
        "Explosion": Explosion,
        # Interaction
        "ClickDetector": ClickDetector,
        "ProximityPrompt": ProximityPrompt,
        # Scripting
        "Script": Script,
        "LocalScript": LocalScript,
        "ModuleScript": ModuleScript,
        "BindableEvent": BindableEvent,
        "BindableFunction": BindableFunction,
        "RemoteEvent": RemoteEvent,
        "RemoteFunction": RemoteFunction,
        # Values
        "BoolValue": BoolValue,
        "IntValue": IntValue,
        "NumberValue": NumberValue,
        "StringValue": StringValue,
        "Vector3Value": Vector3Value,
        "CFrameValue": CFrameValue,
        "ObjectValue": ObjectValue,
        "BrickColorValue": BrickColorValue,
        "Color3Value": Color3Value,
        "RayValue": RayValue,
        # Organization
        "Folder": Folder,
        "Model": Model,
        # Sound & Animation
        "Sound": Sound,
        "Animation": Animation,
        "AnimationController": AnimationController,
        "Animator": Animator,
        # Rigging
        "Motor6D": Motor6D,
        "Weld": Weld,
        "Attachment": Attachment,
        "VelocityMotor": VelocityMotor,
        # Constraints
        "BallSocketConstraint": BallSocketConstraint,
        "HingeConstraint": HingeConstraint,
        "PrismaticConstraint": PrismaticConstraint,
        "SpringConstraint": SpringConstraint,
        "RopeConstraint": RopeConstraint,
        "RodConstraint": RodConstraint,
        # GUI
        "ScreenGui": ScreenGui,
        "SurfaceGui": SurfaceGui,
        "BillboardGui": BillboardGui,
        "Frame": Frame,
        "TextLabel": TextLabel,
        "TextButton": TextButton,
        "TextBox": TextBox,
        "ImageLabel": ImageLabel,
        "ImageButton": ImageButton,
        # Selection & Debug
        "SelectionBox": SelectionBox,
        "SelectionSphere": SelectionSphere,
        # Character Parts
        "HumanoidRootPart": HumanoidRootPart,
        "Head": Head,
        "Torso": Torso,
        "LeftArm": LeftArm,
        "RightArm": RightArm,
        "LeftLeg": LeftLeg,
        "RightLeg": RightLeg,
        # Terrain
        "TerrainRegion": TerrainRegion,
    }

    cls = class_map.get(class_name, Part)
    return cls(name or class_name)


def instance_from_dict(data: Dict) -> Instance:
    """Deserialize instance from dictionary"""
    class_name = data.get("class_name", "Part")
    name = data.get("name", class_name)

    obj = create_instance(class_name, name)
    obj.object_id = data.get("object_id", str(uuid.uuid4()))
    obj.visible = data.get("visible", True)
    obj.locked = data.get("locked", False)
    obj.properties = data.get("properties", {})
    obj.scripts = data.get("scripts", [])

    # Restore class-specific properties
    if isinstance(obj, BasePart):
        obj.position = data.get("position", [0, 0, 0])
        obj.rotation = data.get("rotation", [0, 0, 0])
        obj.scale = data.get("scale", [1, 1, 1])
        obj.color = data.get("color", [0.5, 0.5, 0.5])
        obj.transparency = data.get("transparency", 0.0)
        obj.material = data.get("material", "Plastic")
        obj.anchored = data.get("anchored", False)
        obj.can_collide = data.get("can_collide", True)
        obj.mass = data.get("mass", 1.0)
        obj.shape_type = data.get("shape_type", "cube")
        obj.mesh_file = data.get("mesh_file")
        obj.mesh_vertices = data.get("mesh_vertices")
        obj.mesh_faces = data.get("mesh_faces")
        obj.animation_speed = data.get("animation_speed", [0.0, 0.0, 0.0])
        obj.prefab_name = data.get("prefab_name")

        if obj.mesh_file and not obj.mesh_vertices and isinstance(obj, MeshPart):
            obj.load_mesh_from_file(obj.mesh_file)  # Restore children recursively
    for child_data in data.get("children", []):
        child = instance_from_dict(child_data)
        child.parent_id = obj.object_id
        obj.children.append(child)

    return obj
