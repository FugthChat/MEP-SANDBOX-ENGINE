"""
Mesh Module - 3D mesh handling and primitive shape generation
"""

import moderngl
import numpy as np
from typing import Optional, List, Tuple


class Mesh:
    """Represents a 3D mesh with vertices, normals, and colors"""

    def __init__(self, ctx: moderngl.Context):
        self.ctx = ctx
        self.vao: Optional[moderngl.VertexArray] = None
        self.vbo: Optional[moderngl.Buffer] = None
        self.ibo: Optional[moderngl.Buffer] = None
        self.vertex_count = 0
        self.index_count = 0
        self._vertices = None
        self._indices = None

    def set_data(self, vertices: np.ndarray, indices: np.ndarray = None):
        """Set mesh vertex and index data"""
        self._vertices = vertices.astype(np.float32)
        self.vertex_count = len(vertices) // 6  # 6 floats per vertex (pos3, normal3)

        # Create or update VBO
        if self.vbo:
            self.vbo.release()
        self.vbo = self.ctx.buffer(self._vertices.tobytes())

        if indices is not None:
            self._indices = indices.astype(np.uint32)
            self.index_count = len(indices)
            if self.ibo:
                self.ibo.release()
            self.ibo = self.ctx.buffer(self._indices.tobytes())

    def create_vao(self, program: moderngl.Program):
        """Create a VAO with the given shader program"""
        if self.vao:
            self.vao.release()

        # Vertex format: position(3f) + normal(3f) = 6 floats
        try:
            if self.ibo:
                self.vao = self.ctx.vertex_array(
                    program,
                    [(self.vbo, "3f 3f", "in_position", "in_normal")],
                    self.ibo,
                )
            else:
                self.vao = self.ctx.vertex_array(
                    program,
                    [(self.vbo, "3f 3f", "in_position", "in_normal")],
                )
        except Exception as e:
            print(f"[Mesh] VAO creation error: {e}")

    def render(self):
        """Render the mesh"""
        if self.vao:
            self.vao.render()
        else:
            if not hasattr(self, "_warn_printed"):
                print(f"[Mesh] Warning: No VAO to render (vbo={self.vbo is not None})")
                self._warn_printed = True

    def release(self):
        """Release GPU resources"""
        if self.vao:
            self.vao.release()
        if self.vbo:
            self.vbo.release()
        if self.ibo:
            self.ibo.release()


class MeshFactory:
    """Factory for creating primitive 3D shapes"""

    @staticmethod
    def _vertex(pos, normal):
        """Create vertex: position(3) + normal(3) = 6 floats"""
        return [pos[0], pos[1], pos[2], normal[0], normal[1], normal[2]]

    @staticmethod
    def create_cube(
        ctx: moderngl.Context,
        size: float = 1.0,
        color: Tuple[float, float, float] = (1.0, 1.0, 1.0),
    ) -> Mesh:
        """Create a cube mesh"""
        mesh = Mesh(ctx)
        s = size / 2.0
        v = MeshFactory._vertex

        vertices = []

        # Front face (+Z)
        n = (0, 0, 1)
        vertices.extend(v((-s, -s, s), n))
        vertices.extend(v((s, -s, s), n))
        vertices.extend(v((s, s, s), n))
        vertices.extend(v((-s, -s, s), n))
        vertices.extend(v((s, s, s), n))
        vertices.extend(v((-s, s, s), n))

        # Back face (-Z)
        n = (0, 0, -1)
        vertices.extend(v((s, -s, -s), n))
        vertices.extend(v((-s, -s, -s), n))
        vertices.extend(v((-s, s, -s), n))
        vertices.extend(v((s, -s, -s), n))
        vertices.extend(v((-s, s, -s), n))
        vertices.extend(v((s, s, -s), n))

        # Right face (+X)
        n = (1, 0, 0)
        vertices.extend(v((s, -s, s), n))
        vertices.extend(v((s, -s, -s), n))
        vertices.extend(v((s, s, -s), n))
        vertices.extend(v((s, -s, s), n))
        vertices.extend(v((s, s, -s), n))
        vertices.extend(v((s, s, s), n))

        # Left face (-X)
        n = (-1, 0, 0)
        vertices.extend(v((-s, -s, -s), n))
        vertices.extend(v((-s, -s, s), n))
        vertices.extend(v((-s, s, s), n))
        vertices.extend(v((-s, -s, -s), n))
        vertices.extend(v((-s, s, s), n))
        vertices.extend(v((-s, s, -s), n))

        # Top face (+Y)
        n = (0, 1, 0)
        vertices.extend(v((-s, s, s), n))
        vertices.extend(v((s, s, s), n))
        vertices.extend(v((s, s, -s), n))
        vertices.extend(v((-s, s, s), n))
        vertices.extend(v((s, s, -s), n))
        vertices.extend(v((-s, s, -s), n))

        # Bottom face (-Y)
        n = (0, -1, 0)
        vertices.extend(v((-s, -s, -s), n))
        vertices.extend(v((s, -s, -s), n))
        vertices.extend(v((s, -s, s), n))
        vertices.extend(v((-s, -s, -s), n))
        vertices.extend(v((s, -s, s), n))
        vertices.extend(v((-s, -s, s), n))

        mesh.set_data(np.array(vertices, dtype=np.float32))
        return mesh

    @staticmethod
    def create_sphere(
        ctx: moderngl.Context,
        radius: float = 0.5,
        segments: int = 24,
        rings: int = 12,
        color: Tuple[float, float, float] = (1.0, 1.0, 1.0),
    ) -> Mesh:
        """Create a sphere mesh"""
        mesh = Mesh(ctx)
        v = MeshFactory._vertex
        vertices = []

        for i in range(rings):
            phi1 = np.pi * i / rings
            phi2 = np.pi * (i + 1) / rings

            for j in range(segments):
                theta1 = 2 * np.pi * j / segments
                theta2 = 2 * np.pi * (j + 1) / segments

                # Four corners of quad
                def sphere_point(phi, theta):
                    x = radius * np.sin(phi) * np.cos(theta)
                    y = radius * np.cos(phi)
                    z = radius * np.sin(phi) * np.sin(theta)
                    nx = np.sin(phi) * np.cos(theta)
                    ny = np.cos(phi)
                    nz = np.sin(phi) * np.sin(theta)
                    return (x, y, z), (nx, ny, nz)

                p1, n1 = sphere_point(phi1, theta1)
                p2, n2 = sphere_point(phi1, theta2)
                p3, n3 = sphere_point(phi2, theta2)
                p4, n4 = sphere_point(phi2, theta1)

                if i != 0:
                    vertices.extend(v(p1, n1))
                    vertices.extend(v(p4, n4))
                    vertices.extend(v(p2, n2))

                if i != rings - 1:
                    vertices.extend(v(p2, n2))
                    vertices.extend(v(p4, n4))
                    vertices.extend(v(p3, n3))

        mesh.set_data(np.array(vertices, dtype=np.float32))
        return mesh

    @staticmethod
    def create_plane(
        ctx: moderngl.Context,
        width: float = 1.0,
        height: float = 1.0,
        color: Tuple[float, float, float] = (1.0, 1.0, 1.0),
    ) -> Mesh:
        """Create a plane mesh"""
        mesh = Mesh(ctx)
        v = MeshFactory._vertex
        w, h = width / 2.0, height / 2.0
        n = (0, 1, 0)

        vertices = []
        vertices.extend(v((-w, 0, -h), n))
        vertices.extend(v((w, 0, -h), n))
        vertices.extend(v((w, 0, h), n))
        vertices.extend(v((-w, 0, -h), n))
        vertices.extend(v((w, 0, h), n))
        vertices.extend(v((-w, 0, h), n))

        mesh.set_data(np.array(vertices, dtype=np.float32))
        return mesh

    @staticmethod
    def create_cylinder(
        ctx: moderngl.Context,
        radius: float = 0.5,
        height: float = 1.0,
        segments: int = 24,
        color: Tuple[float, float, float] = (1.0, 1.0, 1.0),
    ) -> Mesh:
        """Create a cylinder mesh"""
        mesh = Mesh(ctx)
        v = MeshFactory._vertex
        vertices = []
        h = height / 2.0

        for i in range(segments):
            theta1 = 2 * np.pi * i / segments
            theta2 = 2 * np.pi * (i + 1) / segments

            x1, z1 = radius * np.cos(theta1), radius * np.sin(theta1)
            x2, z2 = radius * np.cos(theta2), radius * np.sin(theta2)
            n1 = (np.cos(theta1), 0, np.sin(theta1))
            n2 = (np.cos(theta2), 0, np.sin(theta2))

            # Side faces
            vertices.extend(v((x1, -h, z1), n1))
            vertices.extend(v((x2, -h, z2), n2))
            vertices.extend(v((x2, h, z2), n2))
            vertices.extend(v((x1, -h, z1), n1))
            vertices.extend(v((x2, h, z2), n2))
            vertices.extend(v((x1, h, z1), n1))

            # Top cap
            n_top = (0, 1, 0)
            vertices.extend(v((0, h, 0), n_top))
            vertices.extend(v((x1, h, z1), n_top))
            vertices.extend(v((x2, h, z2), n_top))

            # Bottom cap
            n_bot = (0, -1, 0)
            vertices.extend(v((0, -h, 0), n_bot))
            vertices.extend(v((x2, -h, z2), n_bot))
            vertices.extend(v((x1, -h, z1), n_bot))

        mesh.set_data(np.array(vertices, dtype=np.float32))
        return mesh

    @staticmethod
    def create_pyramid(
        ctx: moderngl.Context,
        base_size: float = 1.0,
        height: float = 1.0,
        color: Tuple[float, float, float] = (1.0, 1.0, 1.0),
    ) -> Mesh:
        """Create a pyramid mesh"""
        mesh = Mesh(ctx)
        v = MeshFactory._vertex
        vertices = []
        s = base_size / 2.0

        apex = (0, height, 0)
        corners = [(-s, 0, -s), (s, 0, -s), (s, 0, s), (-s, 0, s)]

        for i in range(4):
            c1 = corners[i]
            c2 = corners[(i + 1) % 4]

            # Calculate face normal
            v1 = np.array([c2[0] - c1[0], c2[1] - c1[1], c2[2] - c1[2]])
            v2 = np.array([apex[0] - c1[0], apex[1] - c1[1], apex[2] - c1[2]])
            normal = np.cross(v1, v2)
            normal = normal / (np.linalg.norm(normal) + 0.0001)
            n = tuple(normal)

            vertices.extend(v(c1, n))
            vertices.extend(v(c2, n))
            vertices.extend(v(apex, n))

        # Base
        n = (0, -1, 0)
        vertices.extend(v(corners[0], n))
        vertices.extend(v(corners[2], n))
        vertices.extend(v(corners[1], n))
        vertices.extend(v(corners[0], n))
        vertices.extend(v(corners[3], n))
        vertices.extend(v(corners[2], n))

        mesh.set_data(np.array(vertices, dtype=np.float32))
        return mesh

    @staticmethod
    def create_torus(
        ctx: moderngl.Context,
        major_radius: float = 0.5,
        minor_radius: float = 0.2,
        major_segments: int = 24,
        minor_segments: int = 12,
        color: Tuple[float, float, float] = (1.0, 1.0, 1.0),
    ) -> Mesh:
        """Create a torus mesh"""
        mesh = Mesh(ctx)
        v = MeshFactory._vertex
        vertices = []

        for i in range(major_segments):
            theta1 = 2 * np.pi * i / major_segments
            theta2 = 2 * np.pi * (i + 1) / major_segments

            for j in range(minor_segments):
                phi1 = 2 * np.pi * j / minor_segments
                phi2 = 2 * np.pi * (j + 1) / minor_segments

                def torus_point(theta, phi):
                    x = (major_radius + minor_radius * np.cos(phi)) * np.cos(theta)
                    y = minor_radius * np.sin(phi)
                    z = (major_radius + minor_radius * np.cos(phi)) * np.sin(theta)
                    nx = np.cos(phi) * np.cos(theta)
                    ny = np.sin(phi)
                    nz = np.cos(phi) * np.sin(theta)
                    return (x, y, z), (nx, ny, nz)

                p1, n1 = torus_point(theta1, phi1)
                p2, n2 = torus_point(theta2, phi1)
                p3, n3 = torus_point(theta2, phi2)
                p4, n4 = torus_point(theta1, phi2)

                vertices.extend(v(p1, n1))
                vertices.extend(v(p2, n2))
                vertices.extend(v(p3, n3))
                vertices.extend(v(p1, n1))
                vertices.extend(v(p3, n3))
                vertices.extend(v(p4, n4))

        mesh.set_data(np.array(vertices, dtype=np.float32))
        return mesh


class GridHelper:
    """Creates a grid for visual reference"""

    def __init__(self, ctx: moderngl.Context, size: float = 10.0, divisions: int = 10):
        self.ctx = ctx
        self.vao = None
        self.vbo = None
        self._create_grid(size, divisions)

    def _create_grid(self, size: float, divisions: int):
        """Create grid lines"""
        vertices = []
        half = size / 2.0
        step = size / divisions

        # Grid color
        grid_color = (0.4, 0.4, 0.4)
        axis_x_color = (0.8, 0.2, 0.2)  # Red for X
        axis_z_color = (0.2, 0.2, 0.8)  # Blue for Z

        for i in range(divisions + 1):
            pos = -half + i * step

            # Lines parallel to Z axis
            if abs(pos) < 0.001:
                color = axis_x_color
            else:
                color = grid_color
            vertices.extend([pos, 0, -half, color[0], color[1], color[2]])
            vertices.extend([pos, 0, half, color[0], color[1], color[2]])

            # Lines parallel to X axis
            if abs(pos) < 0.001:
                color = axis_z_color
            else:
                color = grid_color
            vertices.extend([-half, 0, pos, color[0], color[1], color[2]])
            vertices.extend([half, 0, pos, color[0], color[1], color[2]])

        # Y axis (green)
        vertices.extend([0, 0, 0, 0.2, 0.8, 0.2])
        vertices.extend([0, 2, 0, 0.2, 0.8, 0.2])

        self.vbo = self.ctx.buffer(np.array(vertices, dtype=np.float32).tobytes())

    def create_vao(self, program):
        """Create VAO for grid"""
        self.vao = self.ctx.vertex_array(
            program, [(self.vbo, "3f 3f", "in_position", "in_color")]
        )

    def render(self):
        """Render the grid"""
        if self.vao:
            self.vao.render(moderngl.LINES)

    def release(self):
        if self.vao:
            self.vao.release()
        if self.vbo:
            self.vbo.release()


class AxisGizmo:
    """Creates axis gizmo for orientation reference"""

    def __init__(self, ctx: moderngl.Context, size: float = 1.0):
        self.ctx = ctx
        self.vao = None
        self.vbo = None
        self._create_axes(size)

    def _create_axes(self, size: float):
        """Create axis lines"""
        vertices = [
            # X axis - Red
            0,
            0,
            0,
            1,
            0,
            0,
            size,
            0,
            0,
            1,
            0,
            0,
            # Y axis - Green
            0,
            0,
            0,
            0,
            1,
            0,
            0,
            size,
            0,
            0,
            1,
            0,
            # Z axis - Blue
            0,
            0,
            0,
            0,
            0,
            1,
            0,
            0,
            size,
            0,
            0,
            1,
        ]
        self.vbo = self.ctx.buffer(np.array(vertices, dtype=np.float32).tobytes())

    def create_vao(self, program):
        """Create VAO for axes"""
        self.vao = self.ctx.vertex_array(
            program, [(self.vbo, "3f 3f", "in_position", "in_color")]
        )

    def render(self):
        """Render the axes"""
        if self.vao:
            self.vao.render(moderngl.LINES)

    def release(self):
        if self.vao:
            self.vao.release()
        if self.vbo:
            self.vbo.release()
