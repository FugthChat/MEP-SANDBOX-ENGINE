# 🎮 Micah Engine Studio v1.1 - Installation Guide

**Thank you for downloading Micah Engine Studio!**

---

## 📦 What's Included

This package contains everything you need to start creating 3D games:

✅ **Micah Engine Studio** - Complete game development environment  
✅ **MEPLua Scripting** - Full Lua runtime with game API  
✅ **All Dependencies** - No additional software needed  
✅ **Complete Documentation** - Manuals, tutorials, API reference  

---

## 🚀 Installation (Simple!)

1. **Extract the ZIP** to any folder you like (e.g., `C:\Games\MicahEngine\`)
2. **Run `MicahEngineStudio.exe`**
3. **Start creating!**

That's it! No Python, no pip, no setup required.

---

## ✨ Quick Start

### Create Your First Part
1. Launch the engine
2. Right-click **Workspace** in the Explorer panel
3. Select **Insert Object → Parts → Part**
4. Click the part in the viewport or Explorer to select it
5. Use the colorful gizmos to move, rotate, or scale

### Write Your First Script
1. Right-click your Part → **Insert Object → Scripting → Script**
2. **Double-click** the Script in Explorer to open it
3. Write this code:

```lua
function on_start()
    print("Hello from Micah Engine!")
    script.Parent.Color = Color3.fromRGB(255, 0, 0)
end

local rotation = 0
function on_update(dt)
    rotation = rotation + (45 * dt)
    script.Parent.Rotation = Vector3.new(0, rotation, 0)
end
```

4. Click **Play ▶️** and watch your part spin!

---

## 📚 Documentation

Included in this package:

- **README.md** - Overview and feature list
- **MEPLua_Complete_Library_v1.1.md** - Complete scripting reference (600+ lines!)
- **MEPLUA_DUMMY_MANUAL.md** - Beginner tutorials
- **BUILD_INSTRUCTIONS.md** - For developers who want to build from source
- **RELEASE_NOTES.txt** - What's new in v1.1

### Open the docs
Just open any `.md` file with a text editor or Markdown viewer!

---

## 🎮 Core Features

### Roblox-Style Interface
- **Explorer** - Hierarchy tree of all objects
- **Properties** - Edit position, rotation, size, color, and 50+ properties
- **3D Viewport** - Interactive world view with gizmos
- **MEPIDE** - Built-in script editor with syntax highlighting

### Object System
- **50+ Object Types**: Parts, Models, Humanoids, Scripts, Motors, Values, etc.
- **Multi-Selection**: Ctrl+Click or Shift+Click to select multiple
- **Grouping**: Right-click → Group as Model or Group as Rig
- **Advanced Properties**: All Roblox-like properties exposed

### Transform Tools
- **Move Gizmo** (Red/Green/Blue arrows)
- **Rotate Gizmo** (RGB rings)
- **Scale Gizmo** (RGB squares)
- Live property updates while dragging

### Scripting (MEPLua)
- Lua-based gameplay scripting
- `on_start()` and `on_update(dt)` callbacks
- Events: `Touched`, `Died`, `HealthChanged`, etc.
- Full Instance API: create parts, models, characters at runtime
- See **MEPLua_Complete_Library_v1.1.md** for complete reference

---

## 🎯 Example Projects

### Kill Brick
```lua
local killBrick = script.Parent

function on_start()
    killBrick.Touched:Connect(function(hit)
        local humanoid = hit.Parent:FindFirstChild("Humanoid")
        if humanoid then
            humanoid.Health = 0
            print("Player eliminated!")
        end
    end)
end
```

### Tycoon Dropper
```lua
local timer = 0

function on_update(dt)
    timer = timer + dt
    if timer >= 2 then
        timer = 0
        local part = Instance.new("Part")
        part.Position = script.Parent.Position + Vector3.new(0, -2, 0)
        part.Color = Color3.fromRGB(255, 215, 0)
        part.Parent = workspace
    end
end
```

### Spinning Part
```lua
local rotation = 0

function on_update(dt)
    rotation = rotation + (90 * dt)
    script.Parent.Rotation = Vector3.new(0, rotation, 0)
end
```

More examples in the documentation!

---

## ⌨️ Keyboard Shortcuts

| Action | Shortcut |
|--------|----------|
| Move camera | `W` `A` `S` `D` |
| Up/Down | `E` / `Q` |
| Orbit view | Right-click + drag |
| Pan view | Middle-click + drag |
| Zoom | Mouse wheel |
| Frame selection | `F` |
| Duplicate | `Ctrl+D` |
| Delete | `Delete` |
| Save project | `Ctrl+S` |

---

## 🐛 Troubleshooting

### "The application failed to start"
- **Solution**: Make sure you extracted ALL files from the ZIP, not just the EXE

### Gizmos won't grab
- Make sure you're in Move/Rotate/Scale mode (not Select)
- Hover directly over a colored axis/ring/square
- Check the object isn't locked (unlock in Properties)

### Color picker doesn't work
- v1.1 fixed this! Update if you're on older version

### Can't add scripts to objects
- Right-click the object → Insert Object → Scripting → Script

### Script won't open
- Double-click the Script in the Explorer tree
- Should open in the MEPIDE tab next to "3D Viewport"

### Performance is slow
- Reduce number of objects in scene
- Disable unused scripts
- Lower viewport quality settings (future feature)

---

## 💬 Community & Support

### Share Your Creations!
Post screenshots, videos, and projects on Discord!

### Found a Bug?
Report it with:
- Steps to reproduce
- What you expected vs what happened
- Any error messages

### Feature Requests
Let us know what features you'd like to see!

---

## 📋 System Requirements

**Minimum:**
- Windows 10 or later
- 4 GB RAM
- GPU with OpenGL 3.3+ support
- 500 MB disk space

**Recommended:**
- Windows 11
- 8 GB RAM
- Dedicated GPU
- 1 GB disk space

---

## 🔄 Updates

### What's New in v1.1
- ✅ Multi-selection (Ctrl+Click)
- ✅ Group as Model / Group as Rig
- ✅ 50+ properties exposed
- ✅ Color picker fixed
- ✅ MEPIDE script editor
- ✅ Transform gizmos
- ✅ Script double-click to open

### Upcoming Features
- Advanced animation editor
- Visual scripting (nodes)
- Asset browser with search
- Multiplayer networking
- Physics simulation improvements
- Terrain tools

---

## 🛠️ Building from Source

Want to modify the engine or contribute?

1. Install Python 3.10+
2. Clone/download source: `git clone <repo>`
3. Create venv: `python -m venv .venv`
4. Activate: `.venv\Scripts\activate`
5. Install deps: `pip install -r requirements.txt`
6. Run: `python MICAHESANDBOXLAUNCHER.py`

See **BUILD_INSTRUCTIONS.md** for building your own EXE.

---

## 📜 License

**Micah Engine Studio v1.1**  
© 2025 Micah  

Free for personal and educational use.  
Commercial use requires permission.

---

## 🎉 Thank You!

Thank you for being an early adopter of Micah Engine Studio!

Your feedback shapes the future of this engine.

**Happy creating!** 🚀✨

---

**Version:** 1.1.0  
**Release Date:** December 2025  
**Platform:** Windows (Mac/Linux coming soon)

For questions, support, or to share your projects, find us on Discord!
