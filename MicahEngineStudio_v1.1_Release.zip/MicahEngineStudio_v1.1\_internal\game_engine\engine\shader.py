"""
Shader Module - GLSL shader management
"""

import moderngl
from typing import Optional, Dict
import numpy as np


# Default vertex shader for 3D rendering
DEFAULT_VERTEX_SHADER = """
#version 330 core

in vec3 in_position;
in vec3 in_normal;

out vec3 v_position;
out vec3 v_normal;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main() {
    vec4 world_pos = model * vec4(in_position, 1.0);
    v_position = world_pos.xyz;
    v_normal = mat3(transpose(inverse(model))) * in_normal;
    gl_Position = projection * view * world_pos;
}
"""

# Default fragment shader with basic lighting
DEFAULT_FRAGMENT_SHADER = """
#version 330 core

in vec3 v_position;
in vec3 v_normal;

out vec4 fragColor;

uniform vec3 light_position;
uniform vec3 light_color;
uniform vec3 object_color;
uniform vec3 view_position;
uniform float ambient_strength;
uniform float specular_strength;

void main() {
    // Ambient - ensure minimum visibility
    float amb = max(ambient_strength, 0.25);
    vec3 ambient = amb * light_color;
    
    // Diffuse
    vec3 norm = normalize(v_normal);
    vec3 light_dir = normalize(light_position - v_position);
    float diff = max(dot(norm, light_dir), 0.0);
    vec3 diffuse = diff * light_color * 0.6;
    
    // Specular
    vec3 view_dir = normalize(view_position - v_position);
    vec3 reflect_dir = reflect(-light_dir, norm);
    float spec = pow(max(dot(view_dir, reflect_dir), 0.0), 32.0);
    vec3 specular = specular_strength * spec * light_color;
    
    // Final color
    vec3 result = (ambient + diffuse + specular) * object_color;
    fragColor = vec4(result, 1.0);
}
"""

# Simple colored shader (no lighting)
SIMPLE_VERTEX_SHADER = """
#version 330

in vec3 in_position;
in vec3 in_color;

out vec3 v_color;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main() {
    v_color = in_color;
    gl_Position = projection * view * model * vec4(in_position, 1.0);
}
"""

SIMPLE_FRAGMENT_SHADER = """
#version 330

in vec3 v_color;
out vec4 fragColor;

uniform vec3 object_color;

void main() {
    fragColor = vec4(object_color * v_color, 1.0);
}
"""


class ShaderProgram:
    """Manages GLSL shader programs"""

    def __init__(
        self,
        ctx: moderngl.Context,
        vertex_shader: str = None,
        fragment_shader: str = None,
    ):
        self.ctx = ctx
        self._vertex_source = vertex_shader or DEFAULT_VERTEX_SHADER
        self._fragment_source = fragment_shader or DEFAULT_FRAGMENT_SHADER
        self._program: Optional[moderngl.Program] = None
        self._uniforms: Dict[str, any] = {}

    def compile(self):
        """Compile the shader program"""
        try:
            self._program = self.ctx.program(
                vertex_shader=self._vertex_source, fragment_shader=self._fragment_source
            )
            print(f"[Shader] Compiled successfully. Uniforms: {list(self._program)}")
            return True
        except Exception as e:
            print(f"[Shader] Compilation error: {e}")
            return False

    @property
    def program(self) -> moderngl.Program:
        return self._program

    def use(self):
        """Use this shader program (implicit in ModernGL)"""
        pass  # ModernGL handles this when rendering

    def set_uniform(self, name: str, value):
        """Set a uniform value"""
        if self._program and name in self._program:
            try:
                if isinstance(value, np.ndarray):
                    if value.ndim == 2:  # Matrix
                        self._program[name].write(value.tobytes())
                    else:  # Vector
                        self._program[name].value = tuple(value.flatten())
                elif isinstance(value, (list, tuple)):
                    self._program[name].value = tuple(value)
                else:
                    self._program[name].value = value
                self._uniforms[name] = value
            except Exception as e:
                pass  # Silently ignore uniforms that don't exist

    def set_mat4(self, name: str, matrix: np.ndarray):
        """Set a 4x4 matrix uniform"""
        if self._program and name in self._program:
            self._program[name].write(matrix.astype(np.float32).tobytes())

    def set_vec3(self, name: str, x: float, y: float, z: float):
        """Set a vec3 uniform"""
        if self._program and name in self._program:
            self._program[name].value = (x, y, z)

    def set_float(self, name: str, value: float):
        """Set a float uniform"""
        if self._program and name in self._program:
            self._program[name].value = value

    def set_int(self, name: str, value: int):
        """Set an int uniform"""
        if self._program and name in self._program:
            self._program[name].value = value


# Grid/Line shader for visual helpers
GRID_VERTEX_SHADER = """
#version 330 core

in vec3 in_position;
in vec3 in_color;

out vec3 v_color;

uniform mat4 view;
uniform mat4 projection;

void main() {
    v_color = in_color;
    gl_Position = projection * view * vec4(in_position, 1.0);
}
"""

GRID_FRAGMENT_SHADER = """
#version 330 core

in vec3 v_color;
out vec4 fragColor;

void main() {
    fragColor = vec4(v_color, 1.0);
}
"""


class ShaderLibrary:
    """Pre-defined shader collection"""

    @staticmethod
    def create_default_shader(ctx: moderngl.Context) -> ShaderProgram:
        """Create the default lit shader"""
        shader = ShaderProgram(ctx, DEFAULT_VERTEX_SHADER, DEFAULT_FRAGMENT_SHADER)
        shader.compile()
        return shader

    @staticmethod
    def create_simple_shader(ctx: moderngl.Context) -> ShaderProgram:
        """Create a simple unlit colored shader"""
        shader = ShaderProgram(ctx, SIMPLE_VERTEX_SHADER, SIMPLE_FRAGMENT_SHADER)
        shader.compile()
        return shader

    @staticmethod
    def create_grid_shader(ctx: moderngl.Context) -> ShaderProgram:
        """Create shader for grid and gizmos"""
        shader = ShaderProgram(ctx, GRID_VERTEX_SHADER, GRID_FRAGMENT_SHADER)
        shader.compile()
        return shader
