"""
Lua Scripting Module - Lua integration using lupa
"""

import os
from typing import Dict, Any, Optional, Callable, TYPE_CHECKING
from lupa import LuaRuntime, LuaError
import math

if TYPE_CHECKING:
    from .scene import Scene
    from .game_object import GameObject


class LuaScriptEngine:
    """Manages Lua scripts and provides Python-Lua bindings"""

    def __init__(self, scene: "Scene"):
        self.scene = scene
        self.lua = LuaRuntime(unpack_returned_tuples=True)
        self.scripts: Dict[str, "LuaScript"] = {}
        self.global_state: Dict[str, Any] = {}

        # Setup Lua environment
        self._setup_globals()
        self._setup_api()

    def _setup_globals(self):
        """Setup global Lua variables"""
        g = self.lua.globals()

        # Math constants
        g.PI = math.pi
        g.TAU = math.tau
        g.E = math.e

        # Time tracking
        g.time = 0.0
        g.delta_time = 0.0

    def _setup_api(self):
        """Setup the engine API accessible from Lua"""
        g = self.lua.globals()

        # Create Engine API table
        engine_api = self.lua.table()

        # Object management
        engine_api.get_object = self._lua_get_object
        engine_api.create_cube = self._lua_create_cube
        engine_api.create_sphere = self._lua_create_sphere
        engine_api.create_cylinder = self._lua_create_cylinder
        engine_api.create_pyramid = self._lua_create_pyramid
        engine_api.create_torus = self._lua_create_torus
        engine_api.create_plane = self._lua_create_plane
        engine_api.destroy_object = self._lua_destroy_object
        engine_api.get_all_objects = self._lua_get_all_objects

        # Transform functions
        engine_api.set_position = self._lua_set_position
        engine_api.set_rotation = self._lua_set_rotation
        engine_api.set_scale = self._lua_set_scale
        engine_api.get_position = self._lua_get_position
        engine_api.get_rotation = self._lua_get_rotation
        engine_api.get_scale = self._lua_get_scale
        engine_api.move = self._lua_move
        engine_api.rotate = self._lua_rotate
        engine_api.scale_by = self._lua_scale_by
        engine_api.look_at = self._lua_look_at

        # Appearance
        engine_api.set_color = self._lua_set_color
        engine_api.set_visible = self._lua_set_visible

        # Camera control
        engine_api.set_camera_position = self._lua_set_camera_position
        engine_api.set_camera_target = self._lua_set_camera_target
        engine_api.orbit_camera = self._lua_orbit_camera
        engine_api.zoom_camera = self._lua_zoom_camera

        # Lighting
        engine_api.set_light_position = self._lua_set_light_position
        engine_api.set_light_color = self._lua_set_light_color

        # Utility functions
        engine_api.print = self._lua_print
        engine_api.sin = math.sin
        engine_api.cos = math.cos
        engine_api.tan = math.tan
        engine_api.sqrt = math.sqrt
        engine_api.abs = abs
        engine_api.min = min
        engine_api.max = max
        engine_api.clamp = lambda x, lo, hi: max(lo, min(hi, x))
        engine_api.lerp = lambda a, b, t: a + (b - a) * t
        engine_api.rad = math.radians
        engine_api.deg = math.degrees

        g.Engine = engine_api

        # Also expose as global functions for convenience
        g.get_object = engine_api.get_object
        g.set_position = engine_api.set_position
        g.set_rotation = engine_api.set_rotation
        g.set_scale = engine_api.set_scale
        g.get_position = engine_api.get_position
        g.get_rotation = engine_api.get_rotation
        g.get_scale = engine_api.get_scale
        g.move = engine_api.move
        g.rotate = engine_api.rotate
        g.set_color = engine_api.set_color
        g.create_cube = engine_api.create_cube
        g.create_sphere = engine_api.create_sphere
        g.print = engine_api.print

    # =============== Lua API Implementation ===============

    def _lua_print(self, *args):
        """Print from Lua"""
        print("[Lua]", *[str(a) for a in args])

    def _lua_get_object(self, name: str) -> Optional["LuaObjectProxy"]:
        """Get an object by name, returns a proxy for Lua"""
        obj = self.scene.get_object(name)
        if obj:
            return LuaObjectProxy(obj, self)
        return None

    def _lua_get_all_objects(self):
        """Get all object names"""
        return list(self.scene.objects_by_name.keys())

    def _lua_create_cube(
        self,
        name: str,
        size: float = 1.0,
        r: float = 1.0,
        g: float = 1.0,
        b: float = 1.0,
    ) -> "LuaObjectProxy":
        """Create a cube from Lua"""
        obj = self.scene.create_cube(name, size, (r, g, b))
        return LuaObjectProxy(obj, self)

    def _lua_create_sphere(
        self,
        name: str,
        radius: float = 0.5,
        r: float = 1.0,
        g: float = 1.0,
        b: float = 1.0,
    ) -> "LuaObjectProxy":
        """Create a sphere from Lua"""
        obj = self.scene.create_sphere(name, radius, (r, g, b))
        return LuaObjectProxy(obj, self)

    def _lua_create_cylinder(
        self,
        name: str,
        radius: float = 0.5,
        height: float = 1.0,
        r: float = 1.0,
        g: float = 1.0,
        b: float = 1.0,
    ) -> "LuaObjectProxy":
        """Create a cylinder from Lua"""
        obj = self.scene.create_cylinder(name, radius, height, (r, g, b))
        return LuaObjectProxy(obj, self)

    def _lua_create_pyramid(
        self,
        name: str,
        base: float = 1.0,
        height: float = 1.0,
        r: float = 1.0,
        g: float = 1.0,
        b: float = 1.0,
    ) -> "LuaObjectProxy":
        """Create a pyramid from Lua"""
        obj = self.scene.create_pyramid(name, base, height, (r, g, b))
        return LuaObjectProxy(obj, self)

    def _lua_create_torus(
        self,
        name: str,
        major_r: float = 0.5,
        minor_r: float = 0.2,
        r: float = 1.0,
        g: float = 1.0,
        b: float = 1.0,
    ) -> "LuaObjectProxy":
        """Create a torus from Lua"""
        obj = self.scene.create_torus(name, major_r, minor_r, (r, g, b))
        return LuaObjectProxy(obj, self)

    def _lua_create_plane(
        self,
        name: str,
        width: float = 10.0,
        height: float = 10.0,
        r: float = 0.5,
        g: float = 0.5,
        b: float = 0.5,
    ) -> "LuaObjectProxy":
        """Create a plane from Lua"""
        obj = self.scene.create_plane(name, width, height, (r, g, b))
        return LuaObjectProxy(obj, self)

    def _lua_destroy_object(self, name: str):
        """Destroy an object by name"""
        obj = self.scene.get_object(name)
        if obj:
            self.scene.remove_object(obj)

    def _lua_set_position(self, name: str, x: float, y: float, z: float):
        """Set object position"""
        obj = self.scene.get_object(name)
        if obj:
            obj.set_position(x, y, z)

    def _lua_set_rotation(self, name: str, pitch: float, yaw: float, roll: float):
        """Set object rotation"""
        obj = self.scene.get_object(name)
        if obj:
            obj.set_rotation(pitch, yaw, roll)

    def _lua_set_scale(self, name: str, x: float, y: float, z: float):
        """Set object scale"""
        obj = self.scene.get_object(name)
        if obj:
            obj.set_scale(x, y, z)

    def _lua_get_position(self, name: str):
        """Get object position"""
        obj = self.scene.get_object(name)
        if obj:
            return obj.get_position()
        return (0, 0, 0)

    def _lua_get_rotation(self, name: str):
        """Get object rotation"""
        obj = self.scene.get_object(name)
        if obj:
            return obj.get_rotation()
        return (0, 0, 0)

    def _lua_get_scale(self, name: str):
        """Get object scale"""
        obj = self.scene.get_object(name)
        if obj:
            return obj.get_scale()
        return (1, 1, 1)

    def _lua_move(self, name: str, dx: float, dy: float, dz: float):
        """Move object by offset"""
        obj = self.scene.get_object(name)
        if obj:
            obj.move(dx, dy, dz)

    def _lua_rotate(self, name: str, dpitch: float, dyaw: float, droll: float):
        """Rotate object by offset"""
        obj = self.scene.get_object(name)
        if obj:
            obj.rotate(dpitch, dyaw, droll)

    def _lua_scale_by(self, name: str, sx: float, sy: float, sz: float):
        """Scale object by factor"""
        obj = self.scene.get_object(name)
        if obj:
            obj.scale_by(sx, sy, sz)

    def _lua_look_at(self, name: str, tx: float, ty: float, tz: float):
        """Make object look at target"""
        obj = self.scene.get_object(name)
        if obj:
            obj.transform.look_at(tx, ty, tz)

    def _lua_set_color(self, name: str, r: float, g: float, b: float):
        """Set object color"""
        obj = self.scene.get_object(name)
        if obj:
            obj.set_color(r, g, b)

    def _lua_set_visible(self, name: str, visible: bool):
        """Set object visibility"""
        obj = self.scene.get_object(name)
        if obj:
            obj.visible = visible

    def _lua_set_camera_position(self, x: float, y: float, z: float):
        """Set camera position"""
        if self.scene.camera:
            self.scene.camera.set_position(x, y, z)

    def _lua_set_camera_target(self, x: float, y: float, z: float):
        """Set camera target (for orbit camera)"""
        from .camera import OrbitCamera

        if isinstance(self.scene.camera, OrbitCamera):
            self.scene.camera.set_target(x, y, z)

    def _lua_orbit_camera(self, dyaw: float, dpitch: float):
        """Orbit the camera"""
        from .camera import OrbitCamera

        if isinstance(self.scene.camera, OrbitCamera):
            self.scene.camera.orbit(dyaw, dpitch)

    def _lua_zoom_camera(self, delta: float):
        """Zoom the camera"""
        from .camera import OrbitCamera

        if isinstance(self.scene.camera, OrbitCamera):
            self.scene.camera.zoom(delta)

    def _lua_set_light_position(self, x: float, y: float, z: float):
        """Set light position"""
        self.scene.set_light_position(x, y, z)

    def _lua_set_light_color(self, r: float, g: float, b: float):
        """Set light color"""
        self.scene.set_light_color(r, g, b)

    # =============== Script Management ===============

    def load_script(self, filepath: str, script_name: str = None) -> "LuaScript":
        """Load a Lua script from file"""
        if not script_name:
            script_name = os.path.basename(filepath)

        with open(filepath, "r") as f:
            code = f.read()

        script = LuaScript(script_name, code, self)
        self.scripts[script_name] = script
        script.initialize()
        return script

    def load_script_string(self, code: str, script_name: str) -> "LuaScript":
        """Load a Lua script from string"""
        script = LuaScript(script_name, code, self)
        self.scripts[script_name] = script
        script.initialize()
        return script

    def remove_script(self, script_name: str):
        """Remove a script"""
        if script_name in self.scripts:
            self.scripts[script_name].cleanup()
            del self.scripts[script_name]

    def update(self, dt: float):
        """Update all scripts"""
        # Update time globals
        g = self.lua.globals()
        g.delta_time = dt
        g.time = g.time + dt

        # Call update on all scripts
        for script in self.scripts.values():
            script.update(dt)

    def call_function(self, func_name: str, *args):
        """Call a global Lua function"""
        g = self.lua.globals()
        if func_name in g:
            try:
                return g[func_name](*args)
            except LuaError as e:
                print(f"Lua error in {func_name}: {e}")
        return None


class LuaScript:
    """Represents a single Lua script"""

    def __init__(self, name: str, code: str, engine: LuaScriptEngine):
        self.name = name
        self.code = code
        self.engine = engine
        self.initialized = False
        self._start_func = None
        self._update_func = None
        self._on_key_func = None

    def initialize(self):
        """Initialize the script (run code and call on_start if exists)"""
        try:
            # Execute the script code
            self.engine.lua.execute(self.code)

            g = self.engine.lua.globals()

            # Store references to lifecycle functions
            if "on_start" in g:
                self._start_func = g["on_start"]
            if "on_update" in g:
                self._update_func = g["on_update"]
            if "on_key" in g:
                self._on_key_func = g["on_key"]

            # Call on_start
            if self._start_func:
                self._start_func()

            self.initialized = True
            print(f"[LuaScript] Loaded: {self.name}")

        except LuaError as e:
            print(f"[LuaScript] Error loading {self.name}: {e}")

    def update(self, dt: float):
        """Call the script's update function"""
        if self._update_func:
            try:
                self._update_func(dt)
            except LuaError as e:
                print(f"[LuaScript] Error in {self.name} update: {e}")

    def on_key(self, key: int, action: str):
        """Call the script's key handler"""
        if self._on_key_func:
            try:
                self._on_key_func(key, action)
            except LuaError as e:
                print(f"[LuaScript] Error in {self.name} on_key: {e}")

    def cleanup(self):
        """Cleanup the script"""
        self._start_func = None
        self._update_func = None
        self._on_key_func = None


class LuaObjectProxy:
    """Proxy object for accessing GameObjects from Lua"""

    def __init__(self, obj: "GameObject", engine: LuaScriptEngine):
        self._obj = obj
        self._engine = engine

    @property
    def name(self):
        return self._obj.name

    @property
    def x(self):
        return self._obj.get_position()[0]

    @property
    def y(self):
        return self._obj.get_position()[1]

    @property
    def z(self):
        return self._obj.get_position()[2]

    def set_position(self, x: float, y: float, z: float):
        self._obj.set_position(x, y, z)

    def set_rotation(self, pitch: float, yaw: float, roll: float):
        self._obj.set_rotation(pitch, yaw, roll)

    def set_scale(self, x: float, y: float, z: float):
        self._obj.set_scale(x, y, z)

    def move(self, dx: float, dy: float, dz: float):
        self._obj.move(dx, dy, dz)

    def rotate(self, dpitch: float, dyaw: float, droll: float):
        self._obj.rotate(dpitch, dyaw, droll)

    def set_color(self, r: float, g: float, b: float):
        self._obj.set_color(r, g, b)

    def get_position(self):
        return self._obj.get_position()

    def get_rotation(self):
        return self._obj.get_rotation()

    def get_scale(self):
        return self._obj.get_scale()
