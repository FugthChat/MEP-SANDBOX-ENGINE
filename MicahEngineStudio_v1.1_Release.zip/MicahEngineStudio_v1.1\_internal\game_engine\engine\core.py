"""
Core Engine Module - Main game engine class with ModernGL context
"""

import moderngl
import moderngl_window as mglw
from moderngl_window import geometry
import numpy as np
from typing import Dict, List, Optional
import time


class Engine:
    """Main 3D Game Engine using ModernGL"""

    def __init__(
        self, width: int = 1280, height: int = 720, title: str = "3D Game Engine"
    ):
        self.width = width
        self.height = height
        self.title = title
        self.ctx: Optional[moderngl.Context] = None
        self.window = None
        self.running = False
        self.delta_time = 0.0
        self.last_time = 0.0
        self.total_time = 0.0

        # Scene management
        self.active_scene = None
        self.scenes: Dict[str, "Scene"] = {}

        # Input state
        self.keys_pressed = set()
        self.mouse_position = (0, 0)
        self.mouse_buttons = set()

    def initialize(self, ctx: moderngl.Context):
        """Initialize the engine with a ModernGL context"""
        self.ctx = ctx
        self.ctx.enable(moderngl.DEPTH_TEST)
        # Disable face culling for debugging - some meshes may have wrong winding
        # self.ctx.enable(moderngl.CULL_FACE)

    def add_scene(self, name: str, scene: "Scene"):
        """Add a scene to the engine"""
        self.scenes[name] = scene
        scene.engine = self

    def set_active_scene(self, name: str):
        """Set the active scene by name"""
        if name in self.scenes:
            self.active_scene = self.scenes[name]
            self.active_scene.on_load()

    def update(self, dt: float):
        """Update the engine state"""
        self.delta_time = dt
        self.total_time += dt

        if self.active_scene:
            self.active_scene.update(dt)

    def render(self):
        """Render the current scene"""
        if self.active_scene:
            self.active_scene.render()

    def get_input_state(self) -> dict:
        """Get current input state for scripts"""
        return {
            "keys": list(self.keys_pressed),
            "mouse_pos": self.mouse_position,
            "mouse_buttons": list(self.mouse_buttons),
            "delta_time": self.delta_time,
            "total_time": self.total_time,
        }


class EngineWindow(mglw.WindowConfig):
    """ModernGL Window Configuration"""

    gl_version = (3, 3)
    title = "3D Game Engine - Lua Scripted"
    window_size = (1280, 720)
    aspect_ratio = 16 / 9
    resizable = True
    samples = 4  # Anti-aliasing
    setup_callback = None  # Class-level callback

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.engine = Engine(self.window_size[0], self.window_size[1], self.title)
        self.engine.initialize(self.ctx)
        self.engine.window = self

        # Mouse drag state
        self.dragging = False
        self.last_mouse_x = 0
        self.last_mouse_y = 0

        # Object creation counter
        self.created_count = 0

        # Setup callback
        if EngineWindow.setup_callback is not None:
            EngineWindow.setup_callback(self.engine)

    @classmethod
    def set_setup_callback(cls, callback):
        """Set a callback for engine setup"""
        cls.setup_callback = staticmethod(callback) if callback else None

    def on_render(self, time: float, frame_time: float):
        """Main render loop"""
        self.ctx.clear(0.1, 0.1, 0.15)
        self.engine.update(frame_time)
        self.engine.render()

    def key_event(self, key, action, modifiers):
        """Handle keyboard input"""
        keys = self.wnd.keys

        if action == keys.ACTION_PRESS:
            self.engine.keys_pressed.add(key)

            # Keyboard shortcuts for creating objects
            scene = self.engine.active_scene
            if scene:
                import random

                r, g, b = random.random(), random.random(), random.random()
                x = random.uniform(-3, 3)
                z = random.uniform(-3, 3)

                if key == keys.NUMBER_1:  # Press 1 to create cube
                    self.created_count += 1
                    obj = scene.create_cube(
                        f"NewCube_{self.created_count}", 0.8, (r, g, b)
                    )
                    obj.set_position(x, 0.5, z)
                    print(f"[UI] Created Cube at ({x:.1f}, 0.5, {z:.1f})")

                elif key == keys.NUMBER_2:  # Press 2 to create sphere
                    self.created_count += 1
                    obj = scene.create_sphere(
                        f"NewSphere_{self.created_count}", 0.5, (r, g, b)
                    )
                    obj.set_position(x, 0.5, z)
                    print(f"[UI] Created Sphere at ({x:.1f}, 0.5, {z:.1f})")

                elif key == keys.NUMBER_3:  # Press 3 to create plane/flat
                    self.created_count += 1
                    obj = scene.create_plane(
                        f"NewPlane_{self.created_count}", 2.0, 2.0, (r, g, b)
                    )
                    obj.set_position(x, 0.1, z)
                    print(f"[UI] Created Plane at ({x:.1f}, 0.1, {z:.1f})")

                elif key == keys.NUMBER_4:  # Press 4 to create cylinder
                    self.created_count += 1
                    obj = scene.create_cylinder(
                        f"NewCylinder_{self.created_count}", 0.4, 1.0, (r, g, b)
                    )
                    obj.set_position(x, 0.5, z)
                    print(f"[UI] Created Cylinder at ({x:.1f}, 0.5, {z:.1f})")

                elif key == keys.NUMBER_5:  # Press 5 to create pyramid
                    self.created_count += 1
                    obj = scene.create_pyramid(
                        f"NewPyramid_{self.created_count}", 1.0, 1.0, (r, g, b)
                    )
                    obj.set_position(x, 0, z)
                    print(f"[UI] Created Pyramid at ({x:.1f}, 0, {z:.1f})")

                elif key == keys.G:  # Toggle grid
                    scene.show_grid = not scene.show_grid
                    print(f"[UI] Grid: {'ON' if scene.show_grid else 'OFF'}")

                elif key == keys.H:  # Toggle gizmo
                    scene.show_gizmo = not scene.show_gizmo
                    print(f"[UI] Gizmo: {'ON' if scene.show_gizmo else 'OFF'}")

        elif action == keys.ACTION_RELEASE:
            self.engine.keys_pressed.discard(key)

    def mouse_position_event(self, x: int, y: int, dx: int, dy: int):
        """Handle mouse movement"""
        self.engine.mouse_position = (x, y)

        # Orbit camera when dragging
        if self.dragging and self.engine.active_scene:
            camera = self.engine.active_scene.camera
            if hasattr(camera, "orbit"):
                camera.orbit(-dx * 0.5, -dy * 0.5)

        self.last_mouse_x = x
        self.last_mouse_y = y

    def mouse_press_event(self, x: int, y: int, button: int):
        """Handle mouse button press"""
        self.engine.mouse_buttons.add(button)
        if button == 1:  # Left mouse button
            self.dragging = True
            self.last_mouse_x = x
            self.last_mouse_y = y

    def mouse_release_event(self, x: int, y: int, button: int):
        """Handle mouse button release"""
        self.engine.mouse_buttons.discard(button)
        if button == 1:
            self.dragging = False

    def mouse_scroll_event(self, x_offset: float, y_offset: float):
        """Handle mouse scroll for zoom"""
        if self.engine.active_scene:
            camera = self.engine.active_scene.camera
            if hasattr(camera, "zoom"):
                camera.zoom(-y_offset * 0.5)


def run_engine(setup_callback=None, **kwargs):
    """Run the game engine"""
    if setup_callback:
        EngineWindow.set_setup_callback(setup_callback)

    # Apply any custom settings
    if "width" in kwargs and "height" in kwargs:
        EngineWindow.window_size = (kwargs["width"], kwargs["height"])
    if "title" in kwargs:
        EngineWindow.title = kwargs["title"]

    mglw.run_window_config(EngineWindow)
