# MEPLUA DUMMY MANUAL
## Micah Engine Programming Language User Guide

---

# CHAPTER 1: Your First Script

## Hello World

Every MEPLua script starts with basic functions. Here's how to create your first script:

1. In the engine, right-click on a Part and select **Insert > Scripting > Script**
2. Double-click the Script to open it in the MEPIDE
3. Replace the code with:

```lua
-- My first MEPLua script!
function on_start()
    print("Hello, Micah Engine!")
end
```

4. Click **Play** to run your game
5. Look in the Output panel - you should see "Hello, Micah Engine!"

## Understanding the Script Lifecycle

MEPLua scripts have two main functions:

- `on_start()` - Called once when Play is pressed
- `on_update(dt)` - Called every frame (60 times per second)

```lua
local counter = 0

function on_start()
    print("Game started!")
end

function on_update(dt)
    counter = counter + dt
    if counter > 1 then
        print("One second passed!")
        counter = 0
    end
end
```

---

# CHAPTER 2: The Tycoon Tutorial

## Creating a Simple Dropper

A tycoon game needs droppers that create parts. Here's how:

### Step 1: Create the Dropper Part

1. Insert a Part and name it "Dropper"
2. Position it above where you want parts to drop
3. Set its color to yellow

### Step 2: Add the Dropper Script

Create a Script inside the Dropper with this code:

```lua
-- Tycoon Dropper Script
local dropper = script.Parent
local dropRate = 2  -- seconds between drops
local timer = 0

function on_start()
    print("Dropper initialized!")
end

function on_update(dt)
    timer = timer + dt
    
    if timer >= dropRate then
        timer = 0
        spawnPart()
    end
end

function spawnPart()
    -- Create a new part
    local newPart = Instance.new("Part")
    
    -- Set properties
    newPart.Name = "DroppedPart"
    newPart.Color = Color3.fromRGB(255, 215, 0)  -- Gold color
    newPart.Size = Vector3.new(1, 1, 1)
    newPart.Position = Vector3.new(
        dropper.Position.X,
        dropper.Position.Y - 2,
        dropper.Position.Z
    )
    
    print("Dropped a part!")
end
```

## Creating a Conveyor Belt

Make parts move along a path:

```lua
-- Conveyor Belt Script
local conveyor = script.Parent
local speed = 5

function on_start()
    -- Connect to Touched event
    conveyor.Touched:Connect(function(hit)
        if hit.Name == "DroppedPart" then
            movePart(hit)
        end
    end)
end

function movePart(part)
    -- Move the part along the conveyor
    local newX = part.Position.X + speed * 0.1
    part.Position = Vector3.new(newX, part.Position.Y, part.Position.Z)
end
```

## Using wait() for Timing

The `wait()` function pauses script execution:

```lua
function on_start()
    print("Starting...")
    wait(1)  -- Wait 1 second
    print("1 second passed!")
    wait(2)  -- Wait 2 more seconds
    print("Now 3 seconds total!")
end
```

**Important:** Use `delay()` for non-blocking waits:

```lua
function on_start()
    delay(5, function()
        print("This runs after 5 seconds!")
    end)
    print("This runs immediately!")
end
```

---

# CHAPTER 3: The Kill Brick

## Creating a Kill Brick

Kill bricks damage players when touched. Here's how to make one:

### Step 1: Create the Brick

1. Insert a Part
2. Name it "KillBrick"
3. Set its color to red (danger!)

### Step 2: Add the Kill Script

```lua
-- Kill Brick Script
local killBrick = script.Parent

function on_start()
    -- Connect to Touched event
    killBrick.Touched:Connect(function(hit)
        onTouched(hit)
    end)
    print("Kill brick ready!")
end

function onTouched(hit)
    -- Check if the hit object is a player part
    local humanoid = findHumanoid(hit)
    
    if humanoid then
        -- Deal damage!
        humanoid:TakeDamage(100)
        print("Player hit the kill brick!")
    end
end

function findHumanoid(part)
    -- Look for a Humanoid in the parent
    if part.Parent then
        local humanoid = part.Parent:FindFirstChild("Humanoid")
        if humanoid then
            return humanoid
        end
    end
    return nil
end
```

## Creating a Damage Zone

Instead of instant kill, deal damage over time:

```lua
-- Damage Zone Script
local damageZone = script.Parent
local damagePerSecond = 25
local playersInZone = {}

function on_start()
    damageZone.Touched:Connect(function(hit)
        local humanoid = hit.Parent:FindFirstChild("Humanoid")
        if humanoid then
            playersInZone[humanoid] = true
        end
    end)
end

function on_update(dt)
    for humanoid, _ in pairs(playersInZone) do
        if humanoid.Health > 0 then
            humanoid:TakeDamage(damagePerSecond * dt)
        else
            playersInZone[humanoid] = nil
        end
    end
end
```

## Health Regeneration

Create a healing zone:

```lua
-- Healing Zone Script
local healZone = script.Parent
local healPerSecond = 20

function on_start()
    healZone.Touched:Connect(function(hit)
        local humanoid = hit.Parent:FindFirstChild("Humanoid")
        if humanoid then
            healPlayer(humanoid)
        end
    end)
end

function healPlayer(humanoid)
    if humanoid.Health < humanoid.MaxHealth then
        humanoid.Health = humanoid.Health + healPerSecond
        if humanoid.Health > humanoid.MaxHealth then
            humanoid.Health = humanoid.MaxHealth
        end
    end
end
```

---

# CHAPTER 4: Rigging 101

## Understanding Rigs

A rig is a character model with joints. In Micah Engine, rigs use:

- **HumanoidRootPart** - The invisible root all parts connect to
- **Torso** - The main body
- **Head** - The character's head
- **Left Arm, Right Arm** - The arms
- **Left Leg, Right Leg** - The legs
- **Motor6D** - Joints connecting parts

## Creating a Simple Rig

### Step 1: Create the Model Structure

1. Insert > Model (name it "Character")
2. Inside the Model, add:
   - HumanoidRootPart
   - Torso
   - Head
   - Left Arm
   - Right Arm
   - Left Leg
   - Right Leg
   - Humanoid

### Step 2: Position the Parts

```
        [Head]
          |
    [LA][Torso][RA]
          |
       [HRP]
          |
      [LL] [RL]
```

Position each part relative to the torso:
- Head: Y + 1.5
- Arms: X ± 1.5
- Legs: Y - 2

### Step 3: Add Motor6D Joints

For each limb, create a Motor6D:

1. Insert > Rigging > Motor6D
2. Set Part0 to the parent (e.g., Torso)
3. Set Part1 to the limb (e.g., Left Arm)
4. Set C0 and C1 offsets

Example Motor6D settings for Left Arm:
- Part0: Torso
- Part1: Left Arm
- C0 Position: [-1.5, 0.5, 0]
- C1 Position: [0.5, 0.5, 0]

## Animating the Rig

Animations control Motor6D transforms over time.

### Creating an Animation File (.meplanim)

```json
{
    "name": "WalkCycle",
    "duration": 1.0,
    "looped": true,
    "keyframes": [
        {
            "time": 0.0,
            "poses": {
                "Left Arm": { "rotation": [30, 0, 0] },
                "Right Arm": { "rotation": [-30, 0, 0] },
                "Left Leg": { "rotation": [-30, 0, 0] },
                "Right Leg": { "rotation": [30, 0, 0] }
            }
        },
        {
            "time": 0.5,
            "poses": {
                "Left Arm": { "rotation": [-30, 0, 0] },
                "Right Arm": { "rotation": [30, 0, 0] },
                "Left Leg": { "rotation": [30, 0, 0] },
                "Right Leg": { "rotation": [-30, 0, 0] }
            }
        },
        {
            "time": 1.0,
            "poses": {
                "Left Arm": { "rotation": [30, 0, 0] },
                "Right Arm": { "rotation": [-30, 0, 0] },
                "Left Leg": { "rotation": [-30, 0, 0] },
                "Right Leg": { "rotation": [30, 0, 0] }
            }
        }
    ]
}
```

### Playing Animations via Script

```lua
-- Animation Player Script
local humanoid = script.Parent:FindFirstChild("Humanoid")
local animator = humanoid:FindFirstChild("Animator")

function on_start()
    -- Load the walk animation
    local walkAnim = Instance.new("Animation")
    walkAnim.AnimationId = "animations/walk.meplanim"
    
    local track = animator:LoadAnimation(walkAnim)
    track.Looped = true
    
    -- Play it!
    track:Play()
end
```

---

# QUICK REFERENCE

## Global Functions

| Function | Description |
|----------|-------------|
| `print(...)` | Output to console |
| `wait(seconds)` | Pause execution |
| `delay(time, func)` | Call function after delay |
| `spawn(func)` | Run function in new thread |
| `tick()` | Get current time |

## Instance.new Classes

- Part, Sphere, Cylinder, WedgePart
- Humanoid, Tool, Accessory
- Script, LocalScript, ModuleScript
- BodyVelocity, BodyPosition, Explosion
- Sound, Animation
- BoolValue, IntValue, NumberValue, StringValue

## Common Properties

### Part Properties
- `Position` (Vector3)
- `Rotation` (Vector3)
- `Size` (Vector3)
- `Color` (Color3)
- `Transparency` (number 0-1)
- `Anchored` (boolean)
- `CanCollide` (boolean)

### Humanoid Properties
- `Health` (number)
- `MaxHealth` (number)
- `WalkSpeed` (number)
- `JumpPower` (number)

## Events

| Event | Fires When |
|-------|------------|
| `Part.Touched` | Another part touches this one |
| `Humanoid.Died` | Health reaches 0 |
| `ClickDetector.MouseClick` | Part is clicked |

## Vector3 Operations

```lua
-- Create vectors
local v1 = Vector3.new(1, 2, 3)
local v2 = Vector3.new(4, 5, 6)

-- Access components
print(v1.X, v1.Y, v1.Z)  -- 1, 2, 3

-- Get magnitude
print(v1.Magnitude)  -- ~3.74
```

## Color3 Operations

```lua
-- From RGB (0-1)
local red = Color3.new(1, 0, 0)

-- From RGB (0-255)
local blue = Color3.fromRGB(0, 0, 255)

-- From HSV
local rainbow = Color3.fromHSV(0.5, 1, 1)
```

---

# EXAMPLE PROJECTS

## Complete Tycoon Dropper System

```lua
-- Full Tycoon System
local droppers = {}
local conveyors = {}
local collectors = {}

local playerMoney = 0

function on_start()
    setupDropper("Dropper1", 2, 10)  -- Drop every 2s, worth $10
    setupCollector("Collector1")
    print("Tycoon system initialized!")
end

function setupDropper(name, rate, value)
    local dropper = workspace:FindFirstChild(name)
    if dropper then
        droppers[name] = {
            part = dropper,
            rate = rate,
            value = value,
            timer = 0
        }
    end
end

function setupCollector(name)
    local collector = workspace:FindFirstChild(name)
    if collector then
        collector.Touched:Connect(function(hit)
            if hit.Name == "DroppedPart" then
                collectPart(hit)
            end
        end)
    end
end

function on_update(dt)
    for name, dropper in pairs(droppers) do
        dropper.timer = dropper.timer + dt
        if dropper.timer >= dropper.rate then
            dropper.timer = 0
            spawnDroppedPart(dropper)
        end
    end
end

function spawnDroppedPart(dropper)
    local part = Instance.new("Part")
    part.Name = "DroppedPart"
    part.Size = Vector3.new(1, 1, 1)
    part.Position = dropper.part.Position
    part.Color = Color3.fromRGB(255, 215, 0)
    -- Store value in the part
    local valueObj = Instance.new("NumberValue")
    valueObj.Name = "Value"
    valueObj.Value = dropper.value
    valueObj.Parent = part
end

function collectPart(part)
    local valueObj = part:FindFirstChild("Value")
    if valueObj then
        playerMoney = playerMoney + valueObj.Value
        print("Collected! Total: $" .. playerMoney)
    end
    part:Destroy()
end
```

---

**Happy Coding!**

For more examples and tutorials, visit the Micah Engine Studio documentation.
