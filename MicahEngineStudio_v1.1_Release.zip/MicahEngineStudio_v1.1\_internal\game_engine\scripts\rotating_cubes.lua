--[[
    Script 1: Rotating Cubes Demo
    
    This script demonstrates:
    - Creating multiple objects
    - Continuous rotation animation
    - Different rotation speeds and axes
    - Color variation
    - Position offsetting in a grid pattern
]]

-- Configuration
local NUM_CUBES = 9
local GRID_SIZE = 3
local SPACING = 2.0
local cubes = {}

-- Color palette for the cubes
local colors = {
    {1.0, 0.3, 0.3},  -- Red
    {0.3, 1.0, 0.3},  -- Green
    {0.3, 0.3, 1.0},  -- Blue
    {1.0, 1.0, 0.3},  -- Yellow
    {1.0, 0.3, 1.0},  -- Magenta
    {0.3, 1.0, 1.0},  -- Cyan
    {1.0, 0.6, 0.2},  -- Orange
    {0.6, 0.2, 1.0},  -- Purple
    {0.2, 0.8, 0.6},  -- Teal
}

-- Rotation speeds for each cube (degrees per second)
local rotation_speeds = {
    {45, 0, 0},    -- Pitch only
    {0, 60, 0},    -- Yaw only
    {0, 0, 30},    -- Roll only
    {30, 45, 0},   -- Pitch + Yaw
    {0, 30, 60},   -- Yaw + Roll
    {45, 0, 30},   -- Pitch + Roll
    {30, 30, 30},  -- All axes slow
    {60, 60, 60},  -- All axes fast
    {90, 45, 22},  -- Mixed speeds
}

-- Called when script starts
function on_start()
    print("=== Rotating Cubes Demo Started ===")
    
    -- Create a ground plane
    local ground = Engine.create_plane("Ground", 15.0, 15.0, 0.2, 0.25, 0.3)
    Engine.set_position("Ground", 0, -1.5, 0)
    
    -- Create cubes in a grid pattern
    local index = 1
    for row = 0, GRID_SIZE - 1 do
        for col = 0, GRID_SIZE - 1 do
            local name = "Cube_" .. index
            local color = colors[index]
            
            -- Create the cube
            local cube = Engine.create_cube(name, 0.8, color[1], color[2], color[3])
            
            -- Position in grid (centered)
            local x = (col - (GRID_SIZE - 1) / 2) * SPACING
            local z = (row - (GRID_SIZE - 1) / 2) * SPACING
            Engine.set_position(name, x, 0, z)
            
            -- Store cube info
            cubes[index] = {
                name = name,
                speed = rotation_speeds[index],
                base_y = 0,
                phase = index * 0.5  -- Phase offset for bobbing
            }
            
            index = index + 1
        end
    end
    
    -- Set up camera
    Engine.set_camera_target(0, 0, 0)
    Engine.zoom_camera(-3)
    
    -- Set up lighting
    Engine.set_light_position(5, 10, 5)
    Engine.set_light_color(1.0, 0.95, 0.9)
    
    print("Created " .. #cubes .. " rotating cubes")
end

-- Called every frame
function on_update(dt)
    -- Rotate each cube
    for i, cube in ipairs(cubes) do
        local speed = cube.speed
        
        -- Apply rotation (degrees per second * delta time)
        Engine.rotate(cube.name, 
            speed[1] * dt, 
            speed[2] * dt, 
            speed[3] * dt)
        
        -- Add a gentle bobbing motion
        local bob_height = math.sin(time * 2 + cube.phase) * 0.15
        local pos = {Engine.get_position(cube.name)}
        Engine.set_position(cube.name, pos[1], cube.base_y + bob_height, pos[3])
    end
    
    -- Slowly orbit the camera
    Engine.orbit_camera(10 * dt, 0)
end

print("Rotating Cubes script loaded!")
