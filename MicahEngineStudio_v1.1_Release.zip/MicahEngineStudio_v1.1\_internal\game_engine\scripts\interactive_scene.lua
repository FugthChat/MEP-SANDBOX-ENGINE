--[[
    Script 3: Interactive Scene Controller
    
    This script demonstrates:
    - Creating a complex scene with multiple objects
    - Dynamic object creation and destruction
    - Position tracking and movement patterns
    - Advanced animation techniques
    - Physics-like behaviors (bouncing, acceleration)
    - Complex transformations
]]

-- Scene objects
local objects = {}
local particle_count = 0
local MAX_PARTICLES = 20

-- Animation parameters
local wave_offset = 0
local spawn_timer = 0
local SPAWN_INTERVAL = 0.5

-- Tower configuration
local tower_blocks = {}
local TOWER_HEIGHT = 8
local TOWER_TWIST_SPEED = 15  -- degrees per second

-- Bouncing ball state
local ball = {
    name = "BouncingBall",
    y = 3,
    velocity = 0,
    gravity = -15,
    bounce_factor = 0.75,
    ground_level = -1.5
}

-- Helper: Create a random color
local function random_color()
    return math.random() * 0.5 + 0.5, 
           math.random() * 0.5 + 0.5, 
           math.random() * 0.5 + 0.5
end

-- Called when script starts
function on_start()
    print("=== Interactive Scene Controller Started ===")
    
    -- Create ground plane
    Engine.create_plane("InteractiveGround", 20.0, 20.0, 0.18, 0.22, 0.28)
    Engine.set_position("InteractiveGround", 0, -2, 0)
    
    -- Create a twisted tower of cubes
    print("Building twisted tower...")
    for i = 1, TOWER_HEIGHT do
        local name = "TowerBlock_" .. i
        local hue = (i - 1) / TOWER_HEIGHT
        local r, g, b = 0.3 + hue * 0.7, 0.5 - hue * 0.3, 0.9 - hue * 0.5
        
        Engine.create_cube(name, 0.8, r, g, b)
        
        -- Stack vertically with slight offset
        local height = -1.5 + (i - 1) * 0.85
        Engine.set_position(name, -4, height, 0)
        
        -- Initial rotation based on position
        Engine.set_rotation(name, 0, i * 15, 0)
        
        tower_blocks[i] = {
            name = name,
            base_height = height,
            index = i
        }
    end
    
    -- Create bouncing ball
    Engine.create_sphere(ball.name, 0.4, 1.0, 0.4, 0.2)
    Engine.set_position(ball.name, 0, ball.y, 0)
    
    -- Create wave of spheres
    print("Creating wave of spheres...")
    local wave_count = 12
    for i = 1, wave_count do
        local name = "WaveSphere_" .. i
        local angle = (i - 1) / wave_count * 2 * PI
        
        Engine.create_sphere(name, 0.25, 0.2, 0.6, 1.0)
        
        local x = math.cos(angle) * 5
        local z = math.sin(angle) * 5
        Engine.set_position(name, x, -1, z)
        
        objects[name] = {
            type = "wave",
            angle = angle,
            radius = 5,
            phase = i / wave_count * 2 * PI
        }
    end
    
    -- Create pyramid sentinels
    print("Creating pyramid sentinels...")
    for i = 1, 4 do
        local name = "Sentinel_" .. i
        local angle = (i - 1) / 4 * 2 * PI
        local x = math.cos(angle) * 7
        local z = math.sin(angle) * 7
        
        Engine.create_pyramid(name, 0.8, 1.2, 0.8, 0.2, 0.3)
        Engine.set_position(name, x, -1, z)
        
        -- Face center
        local look_angle = math.deg(math.atan2(-x, -z))
        Engine.set_rotation(name, 0, look_angle, 0)
        
        objects[name] = {
            type = "sentinel",
            base_x = x,
            base_z = z,
            angle = angle
        }
    end
    
    -- Create a torus ring
    Engine.create_torus("CentralRing", 1.5, 0.15, 0.9, 0.7, 0.2)
    Engine.set_position("CentralRing", 0, 2, 0)
    Engine.set_rotation("CentralRing", 90, 0, 0)
    
    -- Camera and lighting setup
    Engine.set_camera_target(0, 0, 0)
    Engine.zoom_camera(2)
    Engine.orbit_camera(45, 25)
    
    Engine.set_light_position(10, 15, 10)
    Engine.set_light_color(1.0, 0.98, 0.95)
    
    print("Scene created successfully!")
    print("Watch the tower twist, ball bounce, and waves propagate!")
end

-- Called every frame
function on_update(dt)
    wave_offset = wave_offset + dt
    spawn_timer = spawn_timer + dt
    
    -- === Animate Tower ===
    for i, block in ipairs(tower_blocks) do
        -- Twist animation (higher blocks twist more)
        local twist = TOWER_TWIST_SPEED * i * dt
        Engine.rotate(block.name, 0, twist, 0)
        
        -- Gentle sway
        local sway = math.sin(time * 1.5 + i * 0.3) * 0.1
        local pos_x, pos_y, pos_z = Engine.get_position(block.name)
        Engine.set_position(block.name, -4 + sway * i * 0.1, block.base_height, sway * i * 0.05)
    end
    
    -- === Animate Bouncing Ball ===
    -- Apply gravity
    ball.velocity = ball.velocity + ball.gravity * dt
    ball.y = ball.y + ball.velocity * dt
    
    -- Bounce off ground
    if ball.y < ball.ground_level then
        ball.y = ball.ground_level
        ball.velocity = -ball.velocity * ball.bounce_factor
        
        -- Add some randomness to bounce direction
        if math.abs(ball.velocity) > 0.5 then
            -- Color change on bounce
            local r, g, b = random_color()
            Engine.set_color(ball.name, r, g, b)
        end
    end
    
    -- Reset ball if it stops
    if math.abs(ball.velocity) < 0.1 and ball.y <= ball.ground_level + 0.1 then
        ball.y = 5
        ball.velocity = 0
    end
    
    Engine.set_position(ball.name, 0, ball.y, 0)
    
    -- Ball rotation based on velocity
    Engine.rotate(ball.name, ball.velocity * 10 * dt, 30 * dt, 0)
    
    -- === Animate Wave Spheres ===
    for name, obj in pairs(objects) do
        if obj.type == "wave" then
            -- Calculate wave height
            local wave_height = math.sin(wave_offset * 3 + obj.phase) * 0.8
            
            -- Pulsating radius
            local pulse_radius = obj.radius + math.sin(wave_offset * 2 + obj.phase * 0.5) * 0.3
            
            local x = math.cos(obj.angle + wave_offset * 0.3) * pulse_radius
            local z = math.sin(obj.angle + wave_offset * 0.3) * pulse_radius
            local y = -1 + wave_height
            
            Engine.set_position(name, x, y, z)
            
            -- Scale based on height
            local scale = 1.0 + wave_height * 0.3
            Engine.set_scale(name, scale, scale, scale)
            
            -- Color based on height
            local blue = 0.5 + wave_height * 0.3
            Engine.set_color(name, 0.2, 0.5 + wave_height * 0.2, blue)
        elseif obj.type == "sentinel" then
            -- Sentinels bob up and down and rotate
            local bob = math.sin(time * 2 + obj.angle) * 0.2
            Engine.set_position(name, obj.base_x, -1 + bob, obj.base_z)
            
            -- Rotate to track the ball
            local bx, by, bz = Engine.get_position(ball.name)
            local dx = bx - obj.base_x
            local dz = bz - obj.base_z
            local track_angle = math.deg(math.atan2(dx, dz))
            Engine.set_rotation(name, 0, track_angle, 0)
        end
    end
    
    -- === Animate Central Ring ===
    Engine.rotate("CentralRing", 0, 60 * dt, 45 * dt)
    local ring_scale = 1.0 + math.sin(time * 2) * 0.1
    Engine.set_scale("CentralRing", ring_scale, ring_scale, 1.0)
    
    -- Ring color pulse
    local ring_brightness = 0.7 + math.sin(time * 3) * 0.3
    Engine.set_color("CentralRing", ring_brightness, ring_brightness * 0.8, 0.2)
    
    -- === Camera orbit ===
    Engine.orbit_camera(8 * dt, 0)
end

print("Interactive Scene Controller loaded!")
