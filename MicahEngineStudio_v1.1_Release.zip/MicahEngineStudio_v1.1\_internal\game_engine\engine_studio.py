"""Micah Engine Studio - Roblox-style editor with MEPLUA tooling."""

from __future__ import annotations

import copy
import json
import logging
import math
import os
import random
import sys
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# Setup logging
logger = logging.getLogger("MicahEngine")
logger.setLevel(logging.DEBUG)
_log_handler = logging.StreamHandler()
_log_handler.setFormatter(logging.Formatter("[%(levelname)s] %(message)s"))
logger.addHandler(_log_handler)

# Ensure we can import from the package root
if __name__ == "__main__":
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from game_engine.core.instances import (
    GameObject3D,
    BasePart,
    Part,
    WedgePart,
    CornerWedgePart,
    SpherePart,
    CylinderPart,
    MeshPart,
    SpawnLocation,
    Decal,
    Texture,
    Camera,
    Humanoid,
    Tool,
    Accessory,
    Accoutrement,
    Backpack,
    ForceField,
    BodyVelocity,
    BodyGyro,
    BodyPosition,
    Explosion,
    ClickDetector,
    ProximityPrompt,
    Script,
    LocalScript,
    ModuleScript,
    BindableEvent,
    BindableFunction,
    RemoteEvent,
    RemoteFunction,
    BoolValue,
    IntValue,
    NumberValue,
    StringValue,
    Vector3Value,
    CFrameValue,
    ObjectValue,
    BrickColorValue,
    Color3Value,
    RayValue,
    Folder,
    Model,
    Sound,
    Animation,
    AnimationController,
    Animator,
    Motor6D,
    Weld,
    Attachment,
    VelocityMotor,
    BallSocketConstraint,
    HingeConstraint,
    PrismaticConstraint,
    SpringConstraint,
    RopeConstraint,
    RodConstraint,
    ScreenGui,
    SurfaceGui,
    BillboardGui,
    Frame,
    TextLabel,
    TextButton,
    TextBox,
    ImageLabel,
    ImageButton,
    SelectionBox,
    SelectionSphere,
    HumanoidRootPart,
    Head,
    Torso,
    LeftArm,
    RightArm,
    LeftLeg,
    RightLeg,
    TerrainRegion,
    create_instance,
    instance_from_dict,
)
from game_engine.core.lua_runtime import StudioLuaRuntime

from OpenGL.GL import *
from OpenGL.GLU import *
from PyQt5.Qsci import QsciLexerPython, QsciScintilla
from PyQt5.QtCore import QSignalBlocker, Qt, QTimer, QSize, pyqtSignal
from PyQt5.QtGui import QColor, QFont, QIcon
from PyQt5.QtWidgets import (
    QAction,
    QApplication,
    QCheckBox,
    QColorDialog,
    QComboBox,
    QDockWidget,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMenu,
    QMessageBox,
    QPushButton,
    QSlider,
    QShortcut,
    QSizePolicy,
    QSpinBox,
    QSplitter,
    QTabWidget,
    QTextEdit,
    QToolBar,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)
from PyQt5.QtWidgets import QOpenGLWidget
from PyQt5.QtGui import QKeySequence


class TransformMode:
    SELECT = "select"
    MOVE = "move"
    SCALE = "scale"
    ROTATE = "rotate"


@dataclass
class PrefabDefinition:
    name: str
    shape_type: str
    color: List[float]
    scale: List[float]
    description: str


PREFABS: List[PrefabDefinition] = [
    PrefabDefinition(
        "Basic Part", "cube", [0.8, 0.2, 0.2], [1, 1, 1], "Standard building block"
    ),
    PrefabDefinition(
        "Tall Pillar",
        "cylinder",
        [0.65, 0.65, 0.7],
        [0.6, 3, 0.6],
        "Great for architecture",
    ),
    PrefabDefinition(
        "Mega Sphere", "sphere", [0.2, 0.6, 0.9], [2, 2, 2], "Hero prop / globe"
    ),
    PrefabDefinition(
        "Ground Plane", "plane", [0.35, 0.45, 0.35], [20, 1, 20], "Large terrain base"
    ),
    PrefabDefinition(
        "Pyramid", "pyramid", [0.9, 0.8, 0.4], [2, 2, 2], "Ancient style roof"
    ),
]


# GameObject3D moved to game_engine.core.instances


class OpenGLViewport(QOpenGLWidget):
    object_selected = pyqtSignal(object)
    object_transformed = pyqtSignal(object)
    scene_changed = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(640, 360)
        self.setFocusPolicy(Qt.StrongFocus)

        self.objects: List[GameObject3D] = []
        self.selected_object: Optional[GameObject3D] = None
        self.multi_selected: List[GameObject3D] = (
            []
        )  # Reference for multi-selection rendering

        self.camera_distance = 12.0
        self.camera_yaw = 45.0
        self.camera_pitch = 28.0
        self.camera_target = [0.0, 0.0, 0.0]
        self.camera_speed = 0.2

        self.transform_mode = TransformMode.SELECT
        self.gizmo_axis: Optional[str] = None
        self.left_mouse_dragging = False
        self.middle_mouse_dragging = False
        self.right_mouse_dragging = False
        self.last_mouse_x = 0
        self.last_mouse_y = 0
        self.keys_pressed = set()

        self.show_grid = True
        self.enable_lighting = True
        self.wireframe_mode = False
        self.grid_extent = 12
        self.grid_spacing = 1.0
        self.background_color = [0.12, 0.12, 0.16]
        self.ambient_intensity = 0.35

        self.snap_enabled = False
        self.snap_translate = 0.5
        self.snap_rotate = 15.0
        self.snap_scale = 0.1

        self.timer = QTimer()
        self.timer.timeout.connect(self.animate)
        self.timer.start(16)

    # ------------------------------------------------------------------
    # Rendering
    # ------------------------------------------------------------------
    def initializeGL(self):
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_COLOR_MATERIAL)
        glEnable(GL_LIGHT0)
        glClearColor(*self.background_color, 1.0)
        self._apply_lighting()

    def resizeGL(self, w, h):
        glViewport(0, 0, w, h)
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        gluPerspective(45.0, w / h if h else 1, 0.1, 200.0)
        glMatrixMode(GL_MODELVIEW)

    def paintGL(self):
        glClearColor(*self.background_color, 1.0)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        glMatrixMode(GL_MODELVIEW)
        glLoadIdentity()

        cam_x = self.camera_target[0] + self.camera_distance * math.cos(
            math.radians(self.camera_pitch)
        ) * math.sin(math.radians(self.camera_yaw))
        cam_y = self.camera_target[1] + self.camera_distance * math.sin(
            math.radians(self.camera_pitch)
        )
        cam_z = self.camera_target[2] + self.camera_distance * math.cos(
            math.radians(self.camera_pitch)
        ) * math.cos(math.radians(self.camera_yaw))
        gluLookAt(cam_x, cam_y, cam_z, *self.camera_target, 0, 1, 0)

        if self.enable_lighting:
            glEnable(GL_LIGHTING)
            self._apply_lighting()
        else:
            glDisable(GL_LIGHTING)

        glPolygonMode(GL_FRONT_AND_BACK, GL_LINE if self.wireframe_mode else GL_FILL)

        if self.show_grid:
            self._draw_grid()

        for obj in self.objects:
            if obj is not None and obj.visible:
                self._draw_object(obj, self.multi_selected)

        if self.selected_object and self.transform_mode != TransformMode.SELECT:
            # Only draw gizmo if selected object has position (is a BasePart)
            if hasattr(self.selected_object, "position"):
                self._draw_gizmo()

    def _apply_lighting(self):
        ambient = [self.ambient_intensity] * 3 + [1.0]
        diffuse = [0.8, 0.8, 0.8, 1.0]
        position = [8.0, 10.0, 6.0, 1.0]
        glLightfv(GL_LIGHT0, GL_AMBIENT, ambient)
        glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse)
        glLightfv(GL_LIGHT0, GL_POSITION, position)

    def _draw_grid(self):
        extent = self.grid_extent
        spacing = self.grid_spacing
        glDisable(GL_LIGHTING)
        glColor3f(0.3, 0.3, 0.35)
        glBegin(GL_LINES)
        for i in range(-extent, extent + 1):
            v = i * spacing
            glVertex3f(v, 0, -extent * spacing)
            glVertex3f(v, 0, extent * spacing)
            glVertex3f(-extent * spacing, 0, v)
            glVertex3f(extent * spacing, 0, v)
        glEnd()
        glEnable(GL_LIGHTING)

    def _draw_gizmo(self):
        glDisable(GL_LIGHTING)
        glDisable(GL_DEPTH_TEST)  # Always render on top
        glPushMatrix()
        glTranslatef(*self.selected_object.position)

        # Scale gizmo based on camera distance for consistent screen size
        gizmo_scale = self.camera_distance * 0.12
        size = max(0.5, min(gizmo_scale, 3.0))

        # Draw axis lines
        glLineWidth(3.0 if self.gizmo_axis is None else 2.0)
        glBegin(GL_LINES)
        # X axis (Red)
        glColor3f(1.0, 1.0, 0.0) if self.gizmo_axis == "x" else glColor3f(1.0, 0.3, 0.3)
        glVertex3f(0, 0, 0)
        glVertex3f(size, 0, 0)
        # Y axis (Green)
        glColor3f(1.0, 1.0, 0.0) if self.gizmo_axis == "y" else glColor3f(0.3, 1.0, 0.3)
        glVertex3f(0, 0, 0)
        glVertex3f(0, size, 0)
        # Z axis (Blue)
        glColor3f(1.0, 1.0, 0.0) if self.gizmo_axis == "z" else glColor3f(0.3, 0.3, 1.0)
        glVertex3f(0, 0, 0)
        glVertex3f(0, 0, size)
        glEnd()

        # Draw mode-specific indicators
        if self.transform_mode == TransformMode.SCALE:
            # Draw small cubes at axis tips
            cube_size = size * 0.1
            for axis, color, pos in [
                ("x", (1, 0.3, 0.3), (size, 0, 0)),
                ("y", (0.3, 1, 0.3), (0, size, 0)),
                ("z", (0.3, 0.3, 1), (0, 0, size)),
            ]:
                if self.gizmo_axis == axis:
                    glColor3f(1.0, 1.0, 0.0)
                else:
                    glColor3f(*color)
                glPushMatrix()
                glTranslatef(*pos)
                glBegin(GL_QUADS)
                for face in [
                    (-1, -1, -1, 1, -1, -1, 1, 1, -1, -1, 1, -1),
                    (-1, -1, 1, 1, -1, 1, 1, 1, 1, -1, 1, 1),
                ]:
                    for i in range(0, 12, 3):
                        glVertex3f(
                            face[i] * cube_size,
                            face[i + 1] * cube_size,
                            face[i + 2] * cube_size,
                        )
                glEnd()
                glPopMatrix()
        elif self.transform_mode == TransformMode.ROTATE:
            # Draw rotation circles
            segments = 32
            radius = size * 0.8

            # Define draw functions outside loop to avoid closure capture bug
            def draw_x_circle(t, r):
                return (0, r * math.cos(t), r * math.sin(t))

            def draw_y_circle(t, r):
                return (r * math.cos(t), 0, r * math.sin(t))

            def draw_z_circle(t, r):
                return (r * math.cos(t), r * math.sin(t), 0)

            axis_configs = [
                ("x", (1, 0.3, 0.3), draw_x_circle),
                ("y", (0.3, 1, 0.3), draw_y_circle),
                ("z", (0.3, 0.3, 1), draw_z_circle),
            ]

            for axis, color, draw_func in axis_configs:
                if self.gizmo_axis == axis:
                    glColor3f(1.0, 1.0, 0.0)
                    glLineWidth(3.0)
                else:
                    glColor3f(*color)
                    glLineWidth(1.5)
                glBegin(GL_LINE_LOOP)
                for i in range(segments):
                    t = 2 * math.pi * i / segments
                    glVertex3f(*draw_func(t, radius))
                glEnd()
        else:
            # Move mode - draw arrow heads
            arrow_size = size * 0.15
            glBegin(GL_TRIANGLES)
            # X arrow
            (
                glColor3f(1.0, 1.0, 0.0)
                if self.gizmo_axis == "x"
                else glColor3f(1.0, 0.3, 0.3)
            )
            glVertex3f(size, 0, 0)
            glVertex3f(size - arrow_size, arrow_size * 0.5, 0)
            glVertex3f(size - arrow_size, -arrow_size * 0.5, 0)
            # Y arrow
            (
                glColor3f(1.0, 1.0, 0.0)
                if self.gizmo_axis == "y"
                else glColor3f(0.3, 1.0, 0.3)
            )
            glVertex3f(0, size, 0)
            glVertex3f(arrow_size * 0.5, size - arrow_size, 0)
            glVertex3f(-arrow_size * 0.5, size - arrow_size, 0)
            # Z arrow
            (
                glColor3f(1.0, 1.0, 0.0)
                if self.gizmo_axis == "z"
                else glColor3f(0.3, 0.3, 1.0)
            )
            glVertex3f(0, 0, size)
            glVertex3f(arrow_size * 0.5, 0, size - arrow_size)
            glVertex3f(-arrow_size * 0.5, 0, size - arrow_size)
            glEnd()

        glLineWidth(1.0)
        glPopMatrix()
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_LIGHTING)

    def _draw_object(self, obj: GameObject3D, selected_objects: List = None):
        # Skip rendering non-BasePart objects (scripts, values, etc.)
        if not hasattr(obj, "position"):
            # But still recurse to children for Model/Folder that have parts
            for child in getattr(obj, "children", []):
                if getattr(child, "visible", True):
                    self._draw_object(child, selected_objects)
            return

        glPushMatrix()
        glTranslatef(*obj.position)
        glRotatef(obj.rotation[0], 1, 0, 0)
        glRotatef(obj.rotation[1], 0, 1, 0)
        glRotatef(obj.rotation[2], 0, 0, 1)
        glScalef(*obj.scale)

        # Only draw geometry if it's a visible shape (BasePart with shape_type)
        if hasattr(obj, "shape_type") and obj.shape_type not in [
            "script",
            "folder",
            "sound",
            "particle_emitter",
        ]:
            # Set color FIRST (works with or without lighting)
            r, g, b = obj.color[0], obj.color[1], obj.color[2]
            glColor3f(r, g, b)

            # Set material color for proper lighting
            if self.enable_lighting:
                # Create proper ctypes array for OpenGL
                ambient_diffuse = (GLfloat * 4)(r, g, b, 1.0)
                specular = (GLfloat * 4)(0.2, 0.2, 0.2, 1.0)
                glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, ambient_diffuse)
                glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specular)
                glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, 32.0)
            else:
                # Without lighting, just use glColor (already set above)
                pass
            if obj.mesh_vertices and obj.mesh_faces:
                glBegin(GL_TRIANGLES)
                for face in obj.mesh_faces:
                    for vertex_idx in face:
                        if 0 <= vertex_idx < len(obj.mesh_vertices):
                            vx, vy, vz = obj.mesh_vertices[vertex_idx]
                            glVertex3f(vx, vy, vz)
                glEnd()
            else:
                draw_func = getattr(self, f"_draw_{obj.shape_type}", None)
                if draw_func:
                    draw_func()
                else:
                    self._draw_cube()  # Fallback to cube

        # Highlight selected objects (primary = yellow, multi = cyan)
        is_primary = obj == self.selected_object
        is_multi_selected = selected_objects and obj in selected_objects
        if is_primary or is_multi_selected:
            glDisable(GL_LIGHTING)
            if is_primary:
                glColor3f(1.0, 1.0, 0.0)  # Yellow for primary
                glLineWidth(2.5)
            else:
                glColor3f(0.0, 1.0, 1.0)  # Cyan for multi-selected
                glLineWidth(1.5)
            self._draw_wireframe()
            glLineWidth(1.0)
            if self.enable_lighting:
                glEnable(GL_LIGHTING)

        # Draw children recursively
        for child in obj.children:
            if child.visible:
                self._draw_object(child, selected_objects)

        glPopMatrix()

    # Primitive helpers -------------------------------------------------
    def _draw_cube(self):
        vertices = [
            [-0.5, -0.5, -0.5],
            [0.5, -0.5, -0.5],
            [0.5, 0.5, -0.5],
            [-0.5, 0.5, -0.5],
            [-0.5, -0.5, 0.5],
            [0.5, -0.5, 0.5],
            [0.5, 0.5, 0.5],
            [-0.5, 0.5, 0.5],
        ]
        faces = [
            (0, 1, 2, 3),
            (4, 5, 6, 7),
            (0, 1, 5, 4),
            (2, 3, 7, 6),
            (0, 3, 7, 4),
            (1, 2, 6, 5),
        ]
        glBegin(GL_QUADS)
        for face in faces:
            for idx in face:
                glVertex3fv(vertices[idx])
        glEnd()

    def _draw_wireframe(self):
        s = 0.55
        glBegin(GL_LINE_LOOP)
        glVertex3f(-s, -s, -s)
        glVertex3f(s, -s, -s)
        glVertex3f(s, s, -s)
        glVertex3f(-s, s, -s)
        glEnd()
        glBegin(GL_LINE_LOOP)
        glVertex3f(-s, -s, s)
        glVertex3f(s, -s, s)
        glVertex3f(s, s, s)
        glVertex3f(-s, s, s)
        glEnd()
        glBegin(GL_LINES)
        glVertex3f(-s, -s, -s)
        glVertex3f(-s, -s, s)
        glVertex3f(s, -s, -s)
        glVertex3f(s, -s, s)
        glVertex3f(s, s, -s)
        glVertex3f(s, s, s)
        glVertex3f(-s, s, -s)
        glVertex3f(-s, s, s)
        glEnd()

    def _draw_sphere(self):
        quad = gluNewQuadric()
        gluSphere(quad, 0.5, 24, 24)

    def _draw_cylinder(self):
        quad = gluNewQuadric()
        gluCylinder(quad, 0.4, 0.4, 1.0, 24, 1)

    def _draw_pyramid(self):
        glBegin(GL_TRIANGLES)
        glVertex3f(0, 0.5, 0)
        glVertex3f(-0.5, -0.5, 0.5)
        glVertex3f(0.5, -0.5, 0.5)
        glVertex3f(0, 0.5, 0)
        glVertex3f(0.5, -0.5, 0.5)
        glVertex3f(0.5, -0.5, -0.5)
        glVertex3f(0, 0.5, 0)
        glVertex3f(0.5, -0.5, -0.5)
        glVertex3f(-0.5, -0.5, -0.5)
        glVertex3f(0, 0.5, 0)
        glVertex3f(-0.5, -0.5, -0.5)
        glVertex3f(-0.5, -0.5, 0.5)
        glEnd()

    def _draw_plane(self):
        glBegin(GL_QUADS)
        glVertex3f(-0.5, 0, -0.5)
        glVertex3f(0.5, 0, -0.5)
        glVertex3f(0.5, 0, 0.5)
        glVertex3f(-0.5, 0, 0.5)
        glEnd()

    # ------------------------------------------------------------------
    # Interaction
    # ------------------------------------------------------------------
    def animate(self):
        yaw_rad = math.radians(self.camera_yaw)
        speed = self.camera_speed
        if Qt.Key_W in self.keys_pressed:
            self.camera_target[0] -= math.sin(yaw_rad) * speed
            self.camera_target[2] -= math.cos(yaw_rad) * speed
        if Qt.Key_S in self.keys_pressed:
            self.camera_target[0] += math.sin(yaw_rad) * speed
            self.camera_target[2] += math.cos(yaw_rad) * speed
        if Qt.Key_A in self.keys_pressed:
            self.camera_target[0] -= math.cos(yaw_rad) * speed
            self.camera_target[2] += math.sin(yaw_rad) * speed
        if Qt.Key_D in self.keys_pressed:
            self.camera_target[0] += math.cos(yaw_rad) * speed
            self.camera_target[2] -= math.sin(yaw_rad) * speed
        if Qt.Key_E in self.keys_pressed:
            self.camera_target[1] += speed
        if Qt.Key_Q in self.keys_pressed:
            self.camera_target[1] -= speed
        for obj in self.objects:
            if hasattr(obj, "animation_speed") and any(obj.animation_speed):
                obj.rotation[0] += obj.animation_speed[0] * 0.016
                obj.rotation[1] += obj.animation_speed[1] * 0.016
                obj.rotation[2] += obj.animation_speed[2] * 0.016
        self.update()

    def mousePressEvent(self, event):
        self.last_mouse_x = event.x()
        self.last_mouse_y = event.y()
        if event.button() == Qt.LeftButton:
            self.left_mouse_dragging = True
            if self.transform_mode == TransformMode.SELECT:
                self.select_object(event.x(), event.y())
            elif self.selected_object:
                self.gizmo_axis = self._check_gizmo_hit(event.x(), event.y())
        elif event.button() == Qt.MiddleButton:
            self.middle_mouse_dragging = True
        elif event.button() == Qt.RightButton:
            self.right_mouse_dragging = True

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.left_mouse_dragging = False
            self.gizmo_axis = None
        elif event.button() == Qt.MiddleButton:
            self.middle_mouse_dragging = False
        elif event.button() == Qt.RightButton:
            self.right_mouse_dragging = False

    def mouseMoveEvent(self, event):
        dx = (event.x() - self.last_mouse_x) * 0.4
        dy = (event.y() - self.last_mouse_y) * 0.4
        if self.right_mouse_dragging:
            self.camera_yaw += dx
            self.camera_pitch = max(-89, min(89, self.camera_pitch - dy))
        elif self.middle_mouse_dragging:
            yaw_rad = math.radians(self.camera_yaw)
            right_x = math.cos(yaw_rad)
            right_z = -math.sin(yaw_rad)
            pan_speed = 0.02 * self.camera_distance
            self.camera_target[0] -= right_x * dx * pan_speed * 0.01
            self.camera_target[2] -= right_z * dx * pan_speed * 0.01
            self.camera_target[1] += dy * pan_speed * 0.01
        elif self.left_mouse_dragging and self.selected_object and self.gizmo_axis:
            self._apply_gizmo_transform(dx, dy)
        self.last_mouse_x = event.x()
        self.last_mouse_y = event.y()

    def wheelEvent(self, event):
        delta = event.angleDelta().y() / 120.0
        self.camera_distance = max(2.0, min(80.0, self.camera_distance - delta))

    def keyPressEvent(self, event):
        if not event.isAutoRepeat():
            self.keys_pressed.add(event.key())
        if event.key() == Qt.Key_F and self.selected_object:
            self.focus_on_object(self.selected_object)

    def keyReleaseEvent(self, event):
        if not event.isAutoRepeat():
            self.keys_pressed.discard(event.key())

    def _apply_gizmo_transform(self, dx: float, dy: float):
        if not self.selected_object or not self.gizmo_axis:
            return

        self.makeCurrent()
        try:
            modelview = glGetDoublev(GL_MODELVIEW_MATRIX)
            projection = glGetDoublev(GL_PROJECTION_MATRIX)
            viewport = glGetIntegerv(GL_VIEWPORT)
        except Exception:
            return

        obj = self.selected_object
        obj_pos = obj.position
        axis_idx = {"x": 0, "y": 1, "z": 2}[self.gizmo_axis]

        # Project object center to screen
        cx, cy, cz = gluProject(
            obj_pos[0], obj_pos[1], obj_pos[2], modelview, projection, viewport
        )
        cy = viewport[3] - cy  # Invert Y for screen coords

        # Get axis direction vector
        axis_vec = [0.0, 0.0, 0.0]
        axis_vec[axis_idx] = 1.0

        # Project axis tip to screen
        ax, ay, az = gluProject(
            obj_pos[0] + axis_vec[0],
            obj_pos[1] + axis_vec[1],
            obj_pos[2] + axis_vec[2],
            modelview,
            projection,
            viewport,
        )
        ay = viewport[3] - ay

        # Screen space axis vector
        sdx = ax - cx
        sdy = ay - cy
        axis_len = math.sqrt(sdx * sdx + sdy * sdy)

        if axis_len < 1.0:
            # Axis is perpendicular to screen - use fallback
            if self.gizmo_axis == "y":
                projection_factor = -dy  # Y moves with vertical mouse
            else:
                projection_factor = dx  # X/Z move with horizontal
            axis_len = 50.0  # Normalize
        else:
            # Project mouse delta onto screen axis vector (dot product)
            projection_factor = (dx * sdx + dy * sdy) / axis_len

        changed = False

        if self.transform_mode == TransformMode.MOVE:
            # Sensitivity scales with camera distance for consistent feel
            sensitivity = self.camera_distance * 0.005
            delta = projection_factor * sensitivity
            new_val = obj.position[axis_idx] + delta
            new_val = self._snap_value(new_val, self.snap_translate)
            if new_val != obj.position[axis_idx]:
                obj.position[axis_idx] = new_val
                changed = True

        elif self.transform_mode == TransformMode.SCALE:
            sensitivity = 0.02
            delta = projection_factor * sensitivity
            new_val = obj.scale[axis_idx] + delta
            new_val = max(0.01, self._snap_value(new_val, self.snap_scale))
            if new_val != obj.scale[axis_idx]:
                obj.scale[axis_idx] = new_val
                changed = True

        elif self.transform_mode == TransformMode.ROTATE:
            sensitivity = 1.5  # Degrees per pixel
            delta = projection_factor * sensitivity
            new_val = obj.rotation[axis_idx] + delta
            new_val = self._snap_value(new_val, self.snap_rotate)
            # Normalize rotation to -360..360
            while new_val > 360:
                new_val -= 360
            while new_val < -360:
                new_val += 360
            if new_val != obj.rotation[axis_idx]:
                obj.rotation[axis_idx] = new_val
                changed = True

        if changed:
            self.object_transformed.emit(obj)
            self.update()

    def _snap_value(self, value: float, increment: float) -> float:
        if not self.snap_enabled or increment <= 0:
            return value
        return round(value / increment) * increment

    def _check_gizmo_hit(self, mouse_x: int, mouse_y: int) -> Optional[str]:
        if not self.selected_object:
            return None
        try:
            self.makeCurrent()
            modelview = glGetDoublev(GL_MODELVIEW_MATRIX)
            projection = glGetDoublev(GL_PROJECTION_MATRIX)
            viewport = glGetIntegerv(GL_VIEWPORT)

            if modelview is None or projection is None or viewport is None:
                logger.warning("Gizmo hit check failed: OpenGL matrices not available")
                return None

            obj_pos = self.selected_object.position

            # Match gizmo size calculation from _draw_gizmo
            gizmo_scale = self.camera_distance * 0.12
            size = max(0.5, min(gizmo_scale, 3.0))

            def project(x, y, z):
                try:
                    screen = gluProject(x, y, z, modelview, projection, viewport)
                    return screen[0], viewport[3] - screen[1]
                except Exception:
                    return (0, 0)

            def point_to_line_distance(px, py, x1, y1, x2, y2):
                dx = x2 - x1
                dy = y2 - y1
                line_len_sq = dx * dx + dy * dy
                if line_len_sq < 0.0001:
                    return math.hypot(px - x1, py - y1)
                # Project point onto line segment
                t = max(0.0, min(1.0, ((px - x1) * dx + (py - y1) * dy) / line_len_sq))
                proj_x = x1 + t * dx
                proj_y = y1 + t * dy
                return math.hypot(px - proj_x, py - proj_y)

            center = project(*obj_pos)
            endpoints = {
                "x": project(obj_pos[0] + size, obj_pos[1], obj_pos[2]),
                "y": project(obj_pos[0], obj_pos[1] + size, obj_pos[2]),
                "z": project(obj_pos[0], obj_pos[1], obj_pos[2] + size),
            }

            distances = {
                axis: point_to_line_distance(
                    mouse_x, mouse_y, center[0], center[1], end[0], end[1]
                )
                for axis, end in endpoints.items()
            }

            axis, dist = min(distances.items(), key=lambda item: item[1])
            # Larger hit threshold for easier selection
            hit_threshold = 25
            return axis if dist < hit_threshold else None
        except Exception as e:
            logger.debug(f"Gizmo hit detection error: {e}")
            return None

    # ------------------------------------------------------------------
    # Scene helpers
    # ------------------------------------------------------------------
    def add_object(self, obj: GameObject3D):
        self.objects.append(obj)
        self.scene_changed.emit()
        self.update()

    def delete_object(self, target: GameObject3D):
        if target in self.objects:
            self.objects.remove(target)
            if self.selected_object == target:
                self.selected_object = None
                self.object_selected.emit(None)
            self.scene_changed.emit()
            self.update()

    def duplicate_selected(self) -> Optional[GameObject3D]:
        if not self.selected_object:
            return None
        duplicate = self.selected_object.clone()
        self.objects.append(duplicate)
        self.scene_changed.emit()
        self.select_object_by_id(duplicate.object_id)
        return duplicate

    def clear_scene(self):
        self.objects.clear()
        self.selected_object = None
        self.scene_changed.emit()
        self.update()

    def select_object(self, x: int, y: int):
        try:
            viewport = glGetIntegerv(GL_VIEWPORT)
            modelview = glGetDoublev(GL_MODELVIEW_MATRIX)
            projection = glGetDoublev(GL_PROJECTION_MATRIX)
            inv_y = viewport[3] - y
            near = gluUnProject(x, inv_y, 0.0, modelview, projection, viewport)
            far = gluUnProject(x, inv_y, 1.0, modelview, projection, viewport)
            ray_dir = [far[i] - near[i] for i in range(3)]
            length = math.sqrt(sum(d * d for d in ray_dir))
            ray_dir = [d / length for d in ray_dir]
            closest = None
            closest_dist = float("inf")
            for obj in self.objects:
                if not obj.visible or obj.locked:
                    continue
                to_obj = [obj.position[i] - near[i] for i in range(3)]
                dot = sum(to_obj[i] * ray_dir[i] for i in range(3))
                if dot <= 0:
                    continue
                closest_point = [near[i] + ray_dir[i] * dot for i in range(3)]
                dist = math.sqrt(
                    sum((closest_point[i] - obj.position[i]) ** 2 for i in range(3))
                )
                bounds = max(obj.scale)
                if dist < bounds and dot < closest_dist:
                    closest = obj
                    closest_dist = dot
            self.selected_object = closest
            self.object_selected.emit(closest)
        except Exception:
            pass

    def select_object_by_id(self, object_id: str):
        for obj in self.objects:
            if obj.object_id == object_id:
                self.selected_object = obj
                self.object_selected.emit(obj)
                break

    def focus_on_object(self, obj: GameObject3D):
        self.camera_target = obj.position[:]
        radius = max(obj.scale) * 3
        self.camera_distance = max(4.0, min(40.0, radius))
        self.update()

    # Settings ----------------------------------------------------------
    def set_transform_mode(self, mode: str):
        self.transform_mode = mode
        self.update()

    def set_grid_visible(self, state: bool):
        self.show_grid = state
        self.update()

    def set_lighting_enabled(self, state: bool):
        self.enable_lighting = state
        self.update()

    def set_wireframe_mode(self, state: bool):
        self.wireframe_mode = state
        self.update()

    def set_grid_settings(self, extent: int, spacing: float):
        self.grid_extent = max(1, extent)
        self.grid_spacing = max(0.25, spacing)
        self.update()

    def set_background_color(self, color: QColor):
        self.background_color = [color.redF(), color.greenF(), color.blueF()]
        self.update()

    def set_camera_speed(self, speed: float):
        self.camera_speed = max(0.02, speed)

    def set_snap_settings(
        self,
        enabled: bool,
        translate: Optional[float] = None,
        rotate: Optional[float] = None,
        scale: Optional[float] = None,
    ):
        self.snap_enabled = enabled
        if translate is not None:
            self.snap_translate = translate
        if rotate is not None:
            self.snap_rotate = rotate
        if scale is not None:
            self.snap_scale = scale

    def set_ambient_intensity(self, value: float):
        self.ambient_intensity = max(0.0, min(1.0, value))
        self.update()


class ScriptEditor(QsciScintilla):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setUtf8(True)
        font = QFont("Consolas", 11)
        self.setFont(font)
        lexer = QsciLexerPython()
        lexer.setFont(font)
        self.setLexer(lexer)
        self.setMarginType(0, QsciScintilla.NumberMargin)
        self.setMarginWidth(0, "0000")
        self.setMarginsForegroundColor(QColor(130, 130, 130))
        self.setMarginsBackgroundColor(QColor(30, 30, 30))
        self.setAutoIndent(True)
        self.setIndentationGuides(True)
        self.setCaretLineVisible(True)
        self.setCaretLineBackgroundColor(QColor(35, 40, 55))


class StudioMainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Micah Engine Studio - Roblox Ready")
        self.setGeometry(60, 40, 1920, 1080)
        self.current_project_path: Optional[Path] = None
        self.scene_dirty = False
        self.script_tabs: Dict[ScriptEditor, Dict] = {}
        self.tree_items: Dict[str, QTreeWidgetItem] = {}
        self.updating_properties = False

        # Multi-selection support
        self.selected_objects: List[GameObject3D] = []

        # Lua Runtime
        self.lua_runtime = StudioLuaRuntime()
        self.lua_runtime.set_print_callback(self.log_console)
        self.lua_runtime.set_error_callback(self._log_lua_error)
        self.play_mode = False
        self.play_timer = QTimer()
        self.play_timer.timeout.connect(self._update_play_mode)

        self._build_ui()
        self._build_menu_bar()
        self._build_toolbar()
        self._build_shortcuts()
        self.statusBar().showMessage("Ready")
        self._log_diagnostics("Studio initialized")

        if not self.lua_runtime.is_available():
            self._log_diagnostics(
                "⚠️ Lua runtime not available - install 'lupa' for scripting"
            )

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------
    def _build_ui(self):
        self.viewport_stack = QTabWidget()
        self.viewport_stack.setMovable(True)
        self.viewport_stack.setTabsClosable(True)
        self.viewport_stack.tabCloseRequested.connect(self.close_script_tab)

        self.gl_viewport = OpenGLViewport()
        self.gl_viewport.object_selected.connect(self.on_object_selected)
        self.gl_viewport.object_transformed.connect(self.on_object_transformed)
        self.gl_viewport.scene_changed.connect(self.refresh_scene_tree)
        self.viewport_stack.addTab(self.gl_viewport, "🕹️ 3D Viewport")

        # Add MEPIDE tab right next to 3D Viewport
        self.mepide_widget = self._create_mepide_tab()
        self.viewport_stack.addTab(self.mepide_widget, "📝 MEPIDE")

        self.bottom_tabs = self._create_bottom_tabs()

        splitter = QSplitter(Qt.Vertical)
        splitter.addWidget(self.viewport_stack)
        splitter.addWidget(self.bottom_tabs)
        splitter.setStretchFactor(0, 4)
        splitter.setStretchFactor(1, 1)
        self.setCentralWidget(splitter)

        self._create_dock_widgets()
        self.refresh_scene_tree()

    def _create_dock_widgets(self):
        toolbox_dock = QDockWidget("Toolbox & Snapping", self)
        toolbox_dock.setWidget(self._create_toolbox_panel())
        toolbox_dock.setAllowedAreas(Qt.LeftDockWidgetArea)
        self.addDockWidget(Qt.LeftDockWidgetArea, toolbox_dock)

        world_dock = QDockWidget("World Settings", self)
        world_dock.setWidget(self._create_world_panel())
        world_dock.setAllowedAreas(Qt.LeftDockWidgetArea)
        self.addDockWidget(Qt.LeftDockWidgetArea, world_dock)
        self.tabifyDockWidget(toolbox_dock, world_dock)
        toolbox_dock.raise_()

        explorer_dock = QDockWidget("Explorer", self)
        explorer_dock.setWidget(self._create_workspace_panel())
        explorer_dock.setAllowedAreas(Qt.RightDockWidgetArea)
        self.addDockWidget(Qt.RightDockWidgetArea, explorer_dock)

        properties_dock = QDockWidget("Properties", self)
        properties_dock.setWidget(self._create_properties_panel())
        properties_dock.setAllowedAreas(Qt.RightDockWidgetArea)
        self.addDockWidget(Qt.RightDockWidgetArea, properties_dock)
        self.tabifyDockWidget(explorer_dock, properties_dock)
        explorer_dock.raise_()

    def _create_toolbox_panel(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setSpacing(6)
        layout.addWidget(QLabel("Transform Modes"))
        self.mode_buttons: Dict[str, QPushButton] = {}
        for text, mode in [
            ("🎯 Select", TransformMode.SELECT),
            ("➡️ Move", TransformMode.MOVE),
            ("📏 Scale", TransformMode.SCALE),
            ("🔄 Rotate", TransformMode.ROTATE),
        ]:
            btn = QPushButton(text)
            btn.setCheckable(True)
            btn.clicked.connect(lambda checked, m=mode: self.set_transform_mode(m))
            layout.addWidget(btn)
            self.mode_buttons[mode] = btn
        self.mode_buttons[TransformMode.SELECT].setChecked(True)

        snap_group = QGroupBox("Snapping")
        snap_layout = QVBoxLayout(snap_group)
        self.snap_enabled_check = QCheckBox("Enable snapping (grid)")
        self.snap_enabled_check.toggled.connect(self._apply_snap_settings)
        snap_layout.addWidget(self.snap_enabled_check)

        self.snap_translate_combo = QComboBox()
        for value in ["0.25", "0.5", "1", "2"]:
            self.snap_translate_combo.addItem(f"Move step {value} stud", float(value))
        self.snap_translate_combo.currentIndexChanged.connect(self._apply_snap_settings)
        snap_layout.addWidget(self.snap_translate_combo)

        self.snap_rotate_combo = QComboBox()
        for value in ["5", "15", "30", "45"]:
            self.snap_rotate_combo.addItem(f"Rotate {value}°", float(value))
        self.snap_rotate_combo.currentIndexChanged.connect(self._apply_snap_settings)
        snap_layout.addWidget(self.snap_rotate_combo)

        self.snap_scale_combo = QComboBox()
        for value in ["0.1", "0.25", "0.5", "1"]:
            self.snap_scale_combo.addItem(f"Scale step {value}", float(value))
        self.snap_scale_combo.currentIndexChanged.connect(self._apply_snap_settings)
        snap_layout.addWidget(self.snap_scale_combo)
        layout.addWidget(snap_group)

        action_row = QHBoxLayout()
        self.duplicate_btn = QPushButton("⧉ Duplicate")
        self.duplicate_btn.clicked.connect(self.duplicate_selected_object)
        self.delete_btn = QPushButton("🗑️ Delete")
        self.delete_btn.clicked.connect(self.delete_selected_object)
        action_row.addWidget(self.duplicate_btn)
        action_row.addWidget(self.delete_btn)
        layout.addLayout(action_row)

        focus_row = QHBoxLayout()
        focus_button = QPushButton("🎯 Frame (F)")
        focus_button.clicked.connect(self.focus_on_selection)
        clear_button = QPushButton("🧹 Clear scene")
        clear_button.clicked.connect(self.clear_scene_prompt)
        focus_row.addWidget(focus_button)
        focus_row.addWidget(clear_button)
        layout.addLayout(focus_row)

        layout.addWidget(QLabel("Toolbox Assets"))
        self.prefab_list = QListWidget()
        for prefab in PREFABS:
            item = QListWidgetItem(f"{prefab.name} • {prefab.description}")
            item.setData(Qt.UserRole, prefab)
            self.prefab_list.addItem(item)
        self.prefab_list.itemDoubleClicked.connect(self.spawn_prefab)
        layout.addWidget(self.prefab_list)

        import_button = QPushButton("📥 Import 3D Model")
        import_button.clicked.connect(self.import_model)
        layout.addWidget(import_button)

        layout.addStretch()
        return widget

    def _create_world_panel(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout(widget)
        self.grid_check = QCheckBox("Show grid")
        self.grid_check.setChecked(True)
        self.grid_check.toggled.connect(self.gl_viewport.set_grid_visible)
        layout.addWidget(self.grid_check)

        self.light_check = QCheckBox("Enable lighting")
        self.light_check.setChecked(True)
        self.light_check.toggled.connect(self.gl_viewport.set_lighting_enabled)
        layout.addWidget(self.light_check)

        self.wire_check = QCheckBox("Wireframe mode")
        self.wire_check.toggled.connect(self.gl_viewport.set_wireframe_mode)
        layout.addWidget(self.wire_check)

        grid_form = QFormLayout()
        self.grid_extent_spin = QSpinBox()
        self.grid_extent_spin.setRange(2, 100)
        self.grid_extent_spin.setValue(12)
        self.grid_extent_spin.valueChanged.connect(
            lambda val: self._apply_grid_settings()
        )
        grid_form.addRow("Grid radius", self.grid_extent_spin)
        self.grid_spacing_spin = QDoubleSpinBox()
        self.grid_spacing_spin.setRange(0.25, 5.0)
        self.grid_spacing_spin.setSingleStep(0.25)
        self.grid_spacing_spin.setValue(1.0)
        self.grid_spacing_spin.valueChanged.connect(
            lambda val: self._apply_grid_settings()
        )
        grid_form.addRow("Grid spacing", self.grid_spacing_spin)
        layout.addLayout(grid_form)

        self.camera_speed_combo = QComboBox()
        self.camera_speed_combo.addItem("Camera speed: Slow", 0.12)
        self.camera_speed_combo.addItem("Camera speed: Normal", 0.2)
        self.camera_speed_combo.addItem("Camera speed: Fast", 0.4)
        self.camera_speed_combo.currentIndexChanged.connect(
            lambda: self.gl_viewport.set_camera_speed(
                self.camera_speed_combo.currentData()
            )
        )
        layout.addWidget(self.camera_speed_combo)

        ambient_form = QFormLayout()
        self.ambient_slider = QSlider(Qt.Horizontal)
        self.ambient_slider.setRange(5, 90)
        self.ambient_slider.setValue(35)
        self.ambient_slider.valueChanged.connect(
            lambda val: self.gl_viewport.set_ambient_intensity(val / 100.0)
        )
        ambient_form.addRow("Ambient", self.ambient_slider)
        layout.addLayout(ambient_form)

        self.background_btn = QPushButton("Sky color")
        self.background_btn.clicked.connect(self.pick_background_color)
        layout.addWidget(self.background_btn)

        layout.addStretch()
        return widget

    def _create_workspace_panel(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout(widget)
        search_layout = QHBoxLayout()
        search_layout.addWidget(QLabel("Filter:"))
        self.workspace_search = QLineEdit()
        self.workspace_search.setPlaceholderText("Search workspace…")
        self.workspace_search.textChanged.connect(self.refresh_scene_tree)
        search_layout.addWidget(self.workspace_search)
        layout.addLayout(search_layout)

        self.scene_tree = QTreeWidget()
        self.scene_tree.setHeaderLabels(["Name", "Type"])
        self.scene_tree.setSelectionMode(
            QTreeWidget.ExtendedSelection
        )  # Multi-select with Ctrl/Shift
        self.scene_tree.setContextMenuPolicy(Qt.CustomContextMenu)
        self.scene_tree.customContextMenuRequested.connect(self.open_context_menu)
        self.scene_tree.itemSelectionChanged.connect(self.on_tree_selection_changed)
        self.scene_tree.itemChanged.connect(self.on_tree_item_changed)
        self.scene_tree.itemDoubleClicked.connect(self.on_tree_item_double_clicked)
        layout.addWidget(self.scene_tree)

        stats_layout = QHBoxLayout()
        self.scene_stats_label = QLabel("Objects: 0")
        stats_layout.addWidget(self.scene_stats_label)
        stats_layout.addStretch()
        layout.addLayout(stats_layout)
        return widget

    def _create_properties_panel(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout(widget)

        # Object info section
        info_group = QGroupBox("Object")
        info_layout = QVBoxLayout(info_group)
        self.property_name = QLineEdit()
        self.property_name.setPlaceholderText("Object name")
        self.property_name.editingFinished.connect(self.on_property_changed)
        info_layout.addWidget(self.property_name)

        self.object_type_label = QLabel("Type: -")
        info_layout.addWidget(self.object_type_label)

        self.visible_check = QCheckBox("Visible")
        self.visible_check.setChecked(True)
        self.visible_check.toggled.connect(self.on_property_changed)
        self.locked_check = QCheckBox("Locked")
        self.locked_check.toggled.connect(self.on_property_changed)
        check_row = QHBoxLayout()
        check_row.addWidget(self.visible_check)
        check_row.addWidget(self.locked_check)
        info_layout.addLayout(check_row)
        layout.addWidget(info_group)

        # Transform section
        transform_group = QGroupBox("Transform")
        transform_layout = QFormLayout(transform_group)
        self.pos_spins = [QDoubleSpinBox() for _ in range(3)]
        self.rot_spins = [QDoubleSpinBox() for _ in range(3)]
        self.scale_spins = [QDoubleSpinBox() for _ in range(3)]
        for spin in self.pos_spins:
            spin.setRange(-999, 999)
            spin.setDecimals(3)
            spin.valueChanged.connect(self.on_property_changed)
        for spin in self.rot_spins:
            spin.setRange(-720, 720)
            spin.valueChanged.connect(self.on_property_changed)
        for spin in self.scale_spins:
            spin.setRange(0.05, 999)
            spin.setValue(1.0)
            spin.valueChanged.connect(self.on_property_changed)
        transform_layout.addRow(
            "Position", self._build_vector_widget(self.pos_spins, ["X", "Y", "Z"])
        )
        transform_layout.addRow(
            "Rotation", self._build_vector_widget(self.rot_spins, ["X", "Y", "Z"])
        )
        transform_layout.addRow(
            "Scale", self._build_vector_widget(self.scale_spins, ["X", "Y", "Z"])
        )
        layout.addWidget(transform_group)

        # Appearance section
        appearance_group = QGroupBox("Appearance")
        appearance_layout = QHBoxLayout(appearance_group)
        self.color_button = QPushButton("Color")
        self.color_button.clicked.connect(self.pick_object_color)
        appearance_layout.addWidget(self.color_button)
        layout.addWidget(appearance_group)

        # Custom properties section (for special objects)
        self.custom_props_group = QGroupBox("Properties")
        self.custom_props_layout = QFormLayout(self.custom_props_group)
        self.custom_props_group.setVisible(False)
        layout.addWidget(self.custom_props_group)

        # Scripts section
        scripts_group = QGroupBox("Scripts")
        scripts_layout = QVBoxLayout(scripts_group)
        self.script_list = QListWidget()
        self.script_list.itemDoubleClicked.connect(self.open_script_from_list)
        scripts_layout.addWidget(self.script_list)
        script_buttons = QHBoxLayout()
        attach_btn = QPushButton("Attach")
        attach_btn.clicked.connect(self.attach_script_to_object)
        detach_btn = QPushButton("Remove")
        detach_btn.clicked.connect(self.remove_script_from_object)
        script_buttons.addWidget(attach_btn)
        script_buttons.addWidget(detach_btn)
        scripts_layout.addLayout(script_buttons)
        layout.addWidget(scripts_group)

        layout.addStretch()
        return widget

    def _create_mepide_tab(self) -> QWidget:
        """Create the MEPIDE tab - full script IDE next to 3D viewport"""
        widget = QWidget()
        layout = QVBoxLayout(widget)

        # Toolbar for MEPIDE
        toolbar = QHBoxLayout()

        new_script_btn = QPushButton("📄 New Script")
        new_script_btn.clicked.connect(self.new_script)
        toolbar.addWidget(new_script_btn)

        open_script_btn = QPushButton("📂 Open Script")
        open_script_btn.clicked.connect(self.load_script)
        toolbar.addWidget(open_script_btn)

        save_script_btn = QPushButton("💾 Save")
        save_script_btn.clicked.connect(self.save_current_script)
        toolbar.addWidget(save_script_btn)

        toolbar.addWidget(QLabel("  |  "))

        run_btn = QPushButton("▶️ Run")
        run_btn.setStyleSheet("background-color: #2d5a2d; color: white;")
        run_btn.clicked.connect(self.run_script)
        toolbar.addWidget(run_btn)

        stop_btn = QPushButton("⏹️ Stop")
        stop_btn.setStyleSheet("background-color: #5a2d2d; color: white;")
        stop_btn.clicked.connect(self.stop_script)
        toolbar.addWidget(stop_btn)

        toolbar.addStretch()
        layout.addLayout(toolbar)

        # Main editor area with script tabs
        self.mepide_tabs = QTabWidget()
        self.mepide_tabs.setTabsClosable(True)
        self.mepide_tabs.tabCloseRequested.connect(self._close_mepide_tab)

        # Add a default welcome script
        welcome_editor = ScriptEditor()
        welcome_code = """-- Welcome to MEPLUA IDE!
-- This is where you write scripts for your game.

-- Example: Make a part spin
local part = script.Parent

function onUpdate()
    if part then
        part.Rotation = part.Rotation + Vector3.new(0, 1, 0)
    end
end

-- Example: Print when part is touched
part.Touched:Connect(function(otherPart)
    print("Touched by: " .. otherPart.Name)
end)

-- Run your script with the Play button!
"""
        welcome_editor.setText(welcome_code)
        self.mepide_tabs.addTab(welcome_editor, "Welcome.lua")

        layout.addWidget(self.mepide_tabs)

        # Output console at bottom
        output_group = QGroupBox("Output")
        output_layout = QVBoxLayout(output_group)
        self.mepide_output = QTextEdit()
        self.mepide_output.setReadOnly(True)
        self.mepide_output.setMaximumHeight(100)
        self.mepide_output.setStyleSheet(
            "background:#1a1a2e; color:#00ff88; font-family:Consolas; font-size:10px;"
        )
        output_layout.addWidget(self.mepide_output)
        layout.addWidget(output_group)

        return widget

    def _close_mepide_tab(self, index: int):
        """Close a tab in the MEPIDE"""
        if self.mepide_tabs.count() > 1:
            self.mepide_tabs.removeTab(index)

    def _create_bottom_tabs(self) -> QTabWidget:
        tabs = QTabWidget()
        tabs.setMaximumHeight(260)
        self.console_output = QTextEdit()
        self.console_output.setReadOnly(True)
        self.console_output.setStyleSheet(
            "background:#0f1116; color:#5cff8d; font-family:Consolas; font-size:11px;"
        )
        console_widget = QWidget()
        console_layout = QVBoxLayout(console_widget)
        clear_btn = QPushButton("Clear console")
        clear_btn.clicked.connect(lambda: self.console_output.clear())
        console_layout.addWidget(clear_btn)
        console_layout.addWidget(self.console_output)
        tabs.addTab(console_widget, "📟 Console")

        self.output_log = QTextEdit()
        self.output_log.setReadOnly(True)
        tabs.addTab(self.output_log, "📊 Output")

        self.diagnostics_log = QTextEdit()
        self.diagnostics_log.setReadOnly(True)
        tabs.addTab(self.diagnostics_log, "🩺 Diagnostics")
        return tabs

    def _build_vector_widget(
        self, spins: List[QDoubleSpinBox], labels: List[str]
    ) -> QWidget:
        container = QWidget()
        layout = QHBoxLayout(container)
        for label, spin in zip(labels, spins):
            sub = QVBoxLayout()
            sub.addWidget(QLabel(label))
            sub.addWidget(spin)
            layout.addLayout(sub)
        return container

    # ------------------------------------------------------------------
    # Menu / toolbar / shortcuts
    # ------------------------------------------------------------------
    def _build_menu_bar(self):
        menubar = self.menuBar()
        file_menu = menubar.addMenu("File")
        file_menu.addAction("New", self.new_project, QKeySequence("Ctrl+N"))
        file_menu.addAction("Open…", self.open_project, QKeySequence("Ctrl+O"))
        file_menu.addAction("Save", self.save_project, QKeySequence("Ctrl+S"))
        file_menu.addAction(
            "Save As…", self.save_project_as, QKeySequence("Ctrl+Shift+S")
        )
        file_menu.addSeparator()
        file_menu.addAction("Exit", self.close)

        edit_menu = menubar.addMenu("Edit")
        edit_menu.addAction(
            "Duplicate", self.duplicate_selected_object, QKeySequence("Ctrl+D")
        )
        edit_menu.addAction("Delete", self.delete_selected_object, QKeySequence.Delete)
        edit_menu.addAction(
            "Frame Selection", self.focus_on_selection, QKeySequence("F")
        )

        view_menu = menubar.addMenu("View")
        reset_cam = QAction("Reset camera", self)
        reset_cam.triggered.connect(self.reset_camera)
        view_menu.addAction(reset_cam)

        tools_menu = menubar.addMenu("Tools")
        diagnostics_action = QAction("Run diagnostics", self)
        diagnostics_action.triggered.connect(self.run_engine_diagnostics)
        tools_menu.addAction(diagnostics_action)

    def _build_toolbar(self):
        toolbar = QToolBar("Studio")
        toolbar.setIconSize(QSize(32, 32))
        play_action = QAction("▶️ Play", self)
        play_action.triggered.connect(self.run_script)
        toolbar.addAction(play_action)
        stop_action = QAction("⏹️ Stop", self)
        stop_action.triggered.connect(self.stop_script)
        toolbar.addAction(stop_action)
        toolbar.addSeparator()
        save_action = QAction("💾 Save", self)
        save_action.triggered.connect(self.save_project)
        toolbar.addAction(save_action)
        self.addToolBar(toolbar)

    def _build_shortcuts(self):
        QShortcut(QKeySequence.Delete, self, self.delete_selected_object)
        QShortcut(QKeySequence("Ctrl+D"), self, self.duplicate_selected_object)
        QShortcut(QKeySequence("F"), self, self.focus_on_selection)

    # ------------------------------------------------------------------
    # Scene operations
    # ------------------------------------------------------------------
    def set_transform_mode(self, mode: str):
        self.gl_viewport.set_transform_mode(mode)
        for key, btn in self.mode_buttons.items():
            btn.setChecked(key == mode)
        self.log_console(f"Transform mode: {mode.title()}")

    def add_object(self, shape_type: str, name: Optional[str] = None) -> GameObject3D:
        name = name or f"{shape_type.title()}_{len(self.gl_viewport.objects)+1}"

        # Map old shape_type strings to new Instance classes
        shape_map = {
            "cube": "Part",
            "sphere": "Sphere",
            "cylinder": "Cylinder",
            "pyramid": "Part",  # Treat as Part for now
            "plane": "Part",
        }
        class_name = shape_map.get(shape_type, "Part")
        obj = create_instance(class_name, name)

        if isinstance(obj, BasePart):
            obj.shape_type = shape_type
            obj.position = [random.uniform(-3, 3), 0.5, random.uniform(-3, 3)]
            obj.color = [random.random(), random.random(), random.random()]

        self.gl_viewport.add_object(obj)
        self.refresh_scene_tree()
        self.select_object(obj)
        self.set_dirty(True)
        self.log_console(f"Added {obj.name}")
        return obj

    def spawn_prefab(self, item: QListWidgetItem):
        prefab: PrefabDefinition = item.data(Qt.UserRole)

        # Map prefab shape types to Instance classes
        shape_map = {
            "cube": "Part",
            "sphere": "Sphere",
            "cylinder": "Cylinder",
            "pyramid": "Part",
            "plane": "Part",
        }
        class_name = shape_map.get(prefab.shape_type, "Part")
        obj = create_instance(class_name, prefab.name)

        if isinstance(obj, BasePart):
            obj.shape_type = prefab.shape_type
            obj.scale = prefab.scale[:]
            obj.color = prefab.color[:]
            obj.properties["prefab_name"] = prefab.name

        self.gl_viewport.add_object(obj)
        self.refresh_scene_tree()
        self.select_object(obj)
        self.set_dirty(True)
        self.log_console(f"Spawned prefab: {prefab.name}")

    def duplicate_selected_object(self):
        duplicate = self.gl_viewport.duplicate_selected()
        if duplicate:
            self.refresh_scene_tree()
            self.select_object(duplicate)
            self.set_dirty(True)
            self.log_console(f"Duplicated {duplicate.name}")

    def delete_selected_object(self):
        obj = self.gl_viewport.selected_object
        if obj:
            self.gl_viewport.delete_object(obj)
            self.refresh_scene_tree()
            self.set_dirty(True)
            self.log_console(f"Deleted {obj.name}")

    def delete_selected_objects(self):
        """Delete all selected objects (multi-selection)"""
        if not self.selected_objects:
            return
        count = len(self.selected_objects)
        for obj in self.selected_objects[:]:  # Copy list since we're modifying
            self.gl_viewport.delete_object(obj)
        self.selected_objects.clear()
        self.gl_viewport.selected_object = None
        self.refresh_scene_tree()
        self.set_dirty(True)
        self.log_console(f"Deleted {count} objects")

    def group_selection_as_model(self):
        """Group selected objects into a Model container"""
        if len(self.selected_objects) < 2:
            self.log_console("Select at least 2 objects to group")
            return

        name, ok = QInputDialog.getText(
            self, "Group as Model", "Model name:", text="Model"
        )
        if not ok or not name:
            return

        # Create new Model
        model = create_instance("Model", name)

        # Calculate center position of all selected objects
        center = [0.0, 0.0, 0.0]
        for obj in self.selected_objects:
            if hasattr(obj, "position"):
                for i in range(3):
                    center[i] += obj.position[i]
        for i in range(3):
            center[i] /= len(self.selected_objects)

        # Add selected objects as children of the model
        for obj in self.selected_objects:
            # Remove from viewport's main list
            if obj in self.gl_viewport.objects:
                self.gl_viewport.objects.remove(obj)
            # Add as child of model
            model.add_child(obj)

        # Set primary part to first selected
        if self.selected_objects:
            model.primary_part = self.selected_objects[0].object_id

        # Add model to viewport
        self.gl_viewport.objects.append(model)

        self.selected_objects = [model]
        self.gl_viewport.selected_object = model
        self.refresh_scene_tree()
        self.set_dirty(True)
        self.log_console(f"Created Model '{name}' with {len(model.children)} parts")

    def group_selection_as_rig(self):
        """Group selected objects into a Model with Humanoid for rigging/animation"""
        if len(self.selected_objects) < 1:
            self.log_console("Select at least 1 object to create a rig")
            return

        name, ok = QInputDialog.getText(
            self, "Create Rig", "Character name:", text="Character"
        )
        if not ok or not name:
            return

        # Create Model
        model = create_instance("Model", name)

        # Create HumanoidRootPart
        root_part = create_instance("HumanoidRootPart", "HumanoidRootPart")

        # Calculate center from selected objects
        center = [0.0, 0.0, 0.0]
        for obj in self.selected_objects:
            if hasattr(obj, "position"):
                for i in range(3):
                    center[i] += obj.position[i]
        for i in range(3):
            center[i] /= len(self.selected_objects)

        root_part.position = center
        model.add_child(root_part)
        model.primary_part = root_part.object_id

        # Create Humanoid controller
        humanoid = create_instance("Humanoid", "Humanoid")
        model.add_child(humanoid)

        # Add selected objects as children
        for obj in self.selected_objects:
            if obj in self.gl_viewport.objects:
                self.gl_viewport.objects.remove(obj)
            model.add_child(obj)

            # Create Motor6D to connect this part to root
            if hasattr(obj, "position"):
                motor = create_instance("Motor6D", f"{obj.name}Joint")
                motor.part0 = root_part.object_id
                motor.part1 = obj.object_id
                # Calculate offset from root
                motor.c0_position = [obj.position[i] - center[i] for i in range(3)]
                model.add_child(motor)

        # Add model to viewport
        self.gl_viewport.objects.append(model)

        self.selected_objects = [model]
        self.gl_viewport.selected_object = model
        self.refresh_scene_tree()
        self.set_dirty(True)
        self.log_console(
            f"Created Rig '{name}' with Humanoid and {len(model.children) - 2} rigged parts"
        )

    def focus_on_selection(self):
        obj = self.gl_viewport.selected_object
        if obj:
            self.gl_viewport.focus_on_object(obj)
            self.log_console(f"Framed {obj.name}")

    def clear_scene_prompt(self):
        if not self.gl_viewport.objects:
            return
        if (
            QMessageBox.question(
                self, "Clear scene", "Remove all objects? This cannot be undone."
            )
            == QMessageBox.Yes
        ):
            self.gl_viewport.clear_scene()
            self.refresh_scene_tree()
            self.set_dirty(True)

    def select_object(self, obj: Optional[GameObject3D]):
        if obj:
            self.gl_viewport.selected_object = obj
            self.gl_viewport.object_selected.emit(obj)

    # ------------------------------------------------------------------
    # Workspace tree
    # ------------------------------------------------------------------
    def refresh_scene_tree(self):
        filter_text = self.workspace_search.text().lower()
        self.scene_tree.blockSignals(True)
        self.scene_tree.clear()
        self.tree_items.clear()

        workspace_root = QTreeWidgetItem(["Workspace", "World"])
        workspace_root.setExpanded(True)
        scripts_root = QTreeWidgetItem(["Scripts", "Open files"])
        scripts_root.setExpanded(True)
        self.scene_tree.addTopLevelItem(workspace_root)
        self.scene_tree.addTopLevelItem(scripts_root)

        def add_node(obj: GameObject3D, parent_item: QTreeWidgetItem):
            # Determine icon/type string using class_name (new Instance system)
            type_str = getattr(obj, "class_name", "Object")

            # For BasePart objects, show shape_type if different from class
            if hasattr(obj, "shape_type") and obj.shape_type:
                shape = obj.shape_type
                if shape not in ["cube", type_str.lower()]:
                    type_str = f"{type_str} ({shape})"

            icon = None
            # Legacy icon placeholders
            # if isinstance(obj, Script):
            #     icon = QIcon(":/icons/script.png")

            item = QTreeWidgetItem([obj.name, type_str])
            item.setData(0, Qt.UserRole, obj)
            item.setCheckState(0, Qt.Checked if obj.visible else Qt.Unchecked)
            if obj.locked:
                item.setForeground(0, QColor("#9f9f9f"))

            parent_item.addChild(item)
            self.tree_items[obj.object_id] = item

            # Add children
            for child in obj.children:
                add_node(child, item)

            # Add legacy scripts list if any
            if hasattr(obj, "scripts") and obj.scripts:
                scripts_folder = QTreeWidgetItem(["Legacy Scripts", "Attached"])
                for script in obj.scripts:
                    child = QTreeWidgetItem([os.path.basename(script), "Script"])
                    child.setData(0, Qt.UserRole, ("attached_script", script))
                    scripts_folder.addChild(child)
                item.addChild(scripts_folder)

        for obj in self.gl_viewport.objects:
            if obj is not None:  # Skip None objects
                add_node(obj, workspace_root)

        for editor, data in self.script_tabs.items():
            script_item = QTreeWidgetItem([data["name"], "Tab"])
            script_item.setData(0, Qt.UserRole, ("open_script", data))
            scripts_root.addChild(script_item)

        self.scene_tree.blockSignals(False)
        self.update_scene_stats()

    def on_tree_selection_changed(self):
        selected_items = self.scene_tree.selectedItems()
        if not selected_items:
            self.selected_objects = []
            self.gl_viewport.selected_object = None
            self.gl_viewport.multi_selected = []
            self.gl_viewport.update()
            return

        # Build list of selected objects
        self.selected_objects = []
        for item in selected_items:
            payload = item.data(0, Qt.UserRole)
            if isinstance(payload, GameObject3D):
                self.selected_objects.append(payload)
            elif isinstance(payload, tuple) and payload[0] == "open_script":
                self.focus_script_tab(payload[1]["editor"])

        # Set primary selection (first object) for property editing
        if self.selected_objects:
            self.gl_viewport.selected_object = self.selected_objects[0]
            self.gl_viewport.multi_selected = (
                self.selected_objects
            )  # Sync with viewport
            self.gl_viewport.object_selected.emit(self.selected_objects[0])
            self.gl_viewport.update()

            # Update status bar to show selection count
            if len(self.selected_objects) > 1:
                self.statusBar().showMessage(
                    f"Selected {len(self.selected_objects)} objects (right-click to Group)"
                )
            else:
                self.statusBar().showMessage(
                    f"Selected: {self.selected_objects[0].name}"
                )

    def on_tree_item_changed(self, item: QTreeWidgetItem, column: int):
        payload = item.data(0, Qt.UserRole)
        if isinstance(payload, GameObject3D):
            payload.visible = item.checkState(0) == Qt.Checked
            self.gl_viewport.update()

    def open_context_menu(self, position):
        item = self.scene_tree.itemAt(position)
        if not item:
            menu = QMenu(self)
            insert_menu = menu.addMenu("Insert Object")
            self._populate_insert_menu(insert_menu, None)
            menu.exec_(self.scene_tree.viewport().mapToGlobal(position))
            return

        payload = item.data(0, Qt.UserRole)
        menu = QMenu(self)
        if isinstance(payload, GameObject3D):
            insert_menu = menu.addMenu("Insert Object")
            self._populate_insert_menu(insert_menu, payload)
            menu.addSeparator()

            # Multi-selection actions
            if len(self.selected_objects) > 1:
                menu.addAction(
                    f"📦 Group {len(self.selected_objects)} objects as Model",
                    self.group_selection_as_model,
                )
                menu.addAction(
                    f"🧍 Group as Model + Humanoid (Rig)", self.group_selection_as_rig
                )
                menu.addAction(
                    f"🗑️ Delete {len(self.selected_objects)} objects",
                    self.delete_selected_objects,
                )
                menu.addSeparator()

            menu.addAction("Rename", lambda: self.rename_object(payload))
            menu.addAction("Duplicate", self.duplicate_selected_object)
            menu.addAction("Delete", self.delete_selected_object)
            menu.addAction("Toggle lock", lambda: self.toggle_lock(payload))
            menu.addAction("Toggle visibility", lambda: self.toggle_visibility(payload))
            menu.addAction("Frame", self.focus_on_selection)
        elif isinstance(payload, tuple) and payload[0] == "open_script":
            menu.addAction(
                "Focus tab", lambda: self.focus_script_tab(payload[1]["editor"])
            )
        menu.exec_(self.scene_tree.viewport().mapToGlobal(position))

    def _populate_insert_menu(self, menu: QMenu, parent: Optional[GameObject3D]):
        # === 3D PARTS (The most common) ===
        parts_menu = menu.addMenu("🧱 Parts")
        parts_menu.addAction(
            "Part (Cube)", lambda: self.insert_instance("Part", parent)
        )
        parts_menu.addAction("Sphere", lambda: self.insert_instance("Sphere", parent))
        parts_menu.addAction(
            "Cylinder", lambda: self.insert_instance("Cylinder", parent)
        )
        parts_menu.addAction("Wedge", lambda: self.insert_instance("WedgePart", parent))
        parts_menu.addAction(
            "Corner Wedge", lambda: self.insert_instance("CornerWedgePart", parent)
        )
        parts_menu.addAction(
            "MeshPart", lambda: self.insert_instance("MeshPart", parent)
        )
        parts_menu.addSeparator()
        parts_menu.addAction(
            "🟢 SpawnLocation", lambda: self.insert_instance("SpawnLocation", parent)
        )

        # === VISUAL / DECORATION ===
        visual_menu = menu.addMenu("🎨 Visual")
        visual_menu.addAction("Decal", lambda: self.insert_instance("Decal", parent))
        visual_menu.addAction(
            "Texture", lambda: self.insert_instance("Texture", parent)
        )
        visual_menu.addAction("Camera", lambda: self.insert_instance("Camera", parent))
        visual_menu.addSeparator()
        visual_menu.addAction(
            "SelectionBox", lambda: self.insert_instance("SelectionBox", parent)
        )
        visual_menu.addAction(
            "SelectionSphere", lambda: self.insert_instance("SelectionSphere", parent)
        )

        # === SOUND & ANIMATION ===
        audio_menu = menu.addMenu("🔊 Sound & Animation")
        audio_menu.addAction("Sound", lambda: self.insert_instance("Sound", parent))
        audio_menu.addAction(
            "Animation", lambda: self.insert_instance("Animation", parent)
        )
        audio_menu.addAction(
            "AnimationController",
            lambda: self.insert_instance("AnimationController", parent),
        )
        audio_menu.addAction(
            "Animator", lambda: self.insert_instance("Animator", parent)
        )

        # === GAMEPLAY / CHARACTERS ===
        gameplay_menu = menu.addMenu("👤 Gameplay")
        gameplay_menu.addAction(
            "Humanoid", lambda: self.insert_instance("Humanoid", parent)
        )
        gameplay_menu.addAction("Tool", lambda: self.insert_instance("Tool", parent))
        gameplay_menu.addAction(
            "Accessory", lambda: self.insert_instance("Accessory", parent)
        )
        gameplay_menu.addAction(
            "Accoutrement", lambda: self.insert_instance("Accoutrement", parent)
        )
        gameplay_menu.addAction(
            "Backpack", lambda: self.insert_instance("Backpack", parent)
        )
        gameplay_menu.addAction(
            "ForceField", lambda: self.insert_instance("ForceField", parent)
        )

        # Character Body Parts submenu
        body_menu = gameplay_menu.addMenu("🦴 Body Parts")
        body_menu.addAction(
            "HumanoidRootPart", lambda: self.insert_instance("HumanoidRootPart", parent)
        )
        body_menu.addAction("Head", lambda: self.insert_instance("Head", parent))
        body_menu.addAction("Torso", lambda: self.insert_instance("Torso", parent))
        body_menu.addAction("Left Arm", lambda: self.insert_instance("LeftArm", parent))
        body_menu.addAction(
            "Right Arm", lambda: self.insert_instance("RightArm", parent)
        )
        body_menu.addAction("Left Leg", lambda: self.insert_instance("LeftLeg", parent))
        body_menu.addAction(
            "Right Leg", lambda: self.insert_instance("RightLeg", parent)
        )

        # === RIGGING / JOINTS ===
        rigging_menu = menu.addMenu("🦴 Rigging")
        rigging_menu.addAction(
            "Motor6D", lambda: self.insert_instance("Motor6D", parent)
        )
        rigging_menu.addAction("Weld", lambda: self.insert_instance("Weld", parent))
        rigging_menu.addAction(
            "Attachment", lambda: self.insert_instance("Attachment", parent)
        )
        rigging_menu.addAction(
            "VelocityMotor", lambda: self.insert_instance("VelocityMotor", parent)
        )

        # === PHYSICS / FORCES ===
        physics_menu = menu.addMenu("⚡ Physics")
        physics_menu.addAction(
            "BodyVelocity", lambda: self.insert_instance("BodyVelocity", parent)
        )
        physics_menu.addAction(
            "BodyGyro", lambda: self.insert_instance("BodyGyro", parent)
        )
        physics_menu.addAction(
            "BodyPosition", lambda: self.insert_instance("BodyPosition", parent)
        )
        physics_menu.addAction(
            "Explosion", lambda: self.insert_instance("Explosion", parent)
        )

        # === CONSTRAINTS ===
        constraints_menu = menu.addMenu("🔗 Constraints")
        constraints_menu.addAction(
            "BallSocketConstraint",
            lambda: self.insert_instance("BallSocketConstraint", parent),
        )
        constraints_menu.addAction(
            "HingeConstraint", lambda: self.insert_instance("HingeConstraint", parent)
        )
        constraints_menu.addAction(
            "PrismaticConstraint",
            lambda: self.insert_instance("PrismaticConstraint", parent),
        )
        constraints_menu.addAction(
            "SpringConstraint", lambda: self.insert_instance("SpringConstraint", parent)
        )
        constraints_menu.addAction(
            "RopeConstraint", lambda: self.insert_instance("RopeConstraint", parent)
        )
        constraints_menu.addAction(
            "RodConstraint", lambda: self.insert_instance("RodConstraint", parent)
        )

        # === INTERACTION ===
        interaction_menu = menu.addMenu("🖱️ Interaction")
        interaction_menu.addAction(
            "ClickDetector", lambda: self.insert_instance("ClickDetector", parent)
        )
        interaction_menu.addAction(
            "ProximityPrompt", lambda: self.insert_instance("ProximityPrompt", parent)
        )

        # === GUI ===
        gui_menu = menu.addMenu("🖼️ GUI")
        gui_menu.addAction(
            "ScreenGui", lambda: self.insert_instance("ScreenGui", parent)
        )
        gui_menu.addAction(
            "SurfaceGui", lambda: self.insert_instance("SurfaceGui", parent)
        )
        gui_menu.addAction(
            "BillboardGui", lambda: self.insert_instance("BillboardGui", parent)
        )
        gui_menu.addSeparator()
        gui_menu.addAction("Frame", lambda: self.insert_instance("Frame", parent))
        gui_menu.addAction(
            "TextLabel", lambda: self.insert_instance("TextLabel", parent)
        )
        gui_menu.addAction(
            "TextButton", lambda: self.insert_instance("TextButton", parent)
        )
        gui_menu.addAction("TextBox", lambda: self.insert_instance("TextBox", parent))
        gui_menu.addAction(
            "ImageLabel", lambda: self.insert_instance("ImageLabel", parent)
        )
        gui_menu.addAction(
            "ImageButton", lambda: self.insert_instance("ImageButton", parent)
        )

        # === SCRIPTING ===
        script_menu = menu.addMenu("📜 Scripting")
        script_menu.addAction("Script", lambda: self.insert_instance("Script", parent))
        script_menu.addAction(
            "LocalScript", lambda: self.insert_instance("LocalScript", parent)
        )
        script_menu.addAction(
            "ModuleScript", lambda: self.insert_instance("ModuleScript", parent)
        )
        script_menu.addSeparator()
        script_menu.addAction(
            "BindableEvent", lambda: self.insert_instance("BindableEvent", parent)
        )
        script_menu.addAction(
            "BindableFunction", lambda: self.insert_instance("BindableFunction", parent)
        )
        script_menu.addAction(
            "RemoteEvent", lambda: self.insert_instance("RemoteEvent", parent)
        )
        script_menu.addAction(
            "RemoteFunction", lambda: self.insert_instance("RemoteFunction", parent)
        )

        # === DATA VALUES ===
        values_menu = menu.addMenu("💾 Values")
        values_menu.addAction(
            "BoolValue", lambda: self.insert_instance("BoolValue", parent)
        )
        values_menu.addAction(
            "IntValue", lambda: self.insert_instance("IntValue", parent)
        )
        values_menu.addAction(
            "NumberValue", lambda: self.insert_instance("NumberValue", parent)
        )
        values_menu.addAction(
            "StringValue", lambda: self.insert_instance("StringValue", parent)
        )
        values_menu.addAction(
            "Vector3Value", lambda: self.insert_instance("Vector3Value", parent)
        )
        values_menu.addAction(
            "CFrameValue", lambda: self.insert_instance("CFrameValue", parent)
        )
        values_menu.addSeparator()
        values_menu.addAction(
            "ObjectValue", lambda: self.insert_instance("ObjectValue", parent)
        )
        values_menu.addAction(
            "BrickColorValue", lambda: self.insert_instance("BrickColorValue", parent)
        )
        values_menu.addAction(
            "Color3Value", lambda: self.insert_instance("Color3Value", parent)
        )
        values_menu.addAction(
            "RayValue", lambda: self.insert_instance("RayValue", parent)
        )

        # === TERRAIN ===
        menu.addSeparator()
        menu.addAction(
            "🏔️ TerrainRegion", lambda: self.insert_instance("TerrainRegion", parent)
        )

        # === ORGANIZATION ===
        menu.addSeparator()
        menu.addAction("📁 Folder", lambda: self.insert_instance("Folder", parent))
        menu.addAction("📦 Model", lambda: self.insert_instance("Model", parent))

    def insert_instance(self, class_name: str, parent: Optional[GameObject3D]):
        """Create and insert a new instance using the new Instance system"""
        # Create instance using factory
        new_obj = create_instance(class_name, class_name)

        # Set default properties based on type
        if isinstance(new_obj, BasePart):
            # Physical parts get random color and position
            new_obj.color = [random.random() * 0.5 + 0.3 for _ in range(3)]
            if parent and isinstance(parent, BasePart):
                new_obj.position = parent.position[:]
            else:
                new_obj.position = [0.0, 0.5, 0.0]

        elif isinstance(new_obj, Humanoid):
            # Humanoid with default stats
            new_obj.health = 100.0
            new_obj.max_health = 100.0
            new_obj.walk_speed = 16.0

        elif isinstance(new_obj, Script):
            # Scripts with default code templates
            if class_name == "Script":
                new_obj.source = "-- Server Script\nfunction on_start()\n    print('Script started!')\nend\n\nfunction on_update(dt)\n    -- Called every frame\nend"
            elif class_name == "LocalScript":
                new_obj.source = "-- Local Script (client-side)\nfunction on_start()\n    print('LocalScript started!')\nend"
            elif class_name == "ModuleScript":
                new_obj.source = "-- Module Script\nlocal module = {}\n\nfunction module.init()\n    print('Module initialized')\nend\n\nreturn module"

        elif isinstance(new_obj, Camera):
            # Camera looking at origin
            new_obj.position = [10.0, 5.0, 10.0]
            new_obj.look_at = [0.0, 0.0, 0.0]

        elif isinstance(new_obj, Explosion):
            # Explosion at world center
            new_obj.position = [0.0, 2.0, 0.0]
            new_obj.blast_radius = 10.0

        # Add to parent or scene
        if parent:
            parent.add_child(new_obj)
        else:
            self.gl_viewport.add_object(new_obj)

        self.refresh_scene_tree()
        self.select_object(new_obj)
        self.set_dirty(True)
        self.log_console(f"✓ Inserted {class_name}: {new_obj.name}")

    def on_tree_item_double_clicked(self, item: QTreeWidgetItem, column: int):
        payload = item.data(0, Qt.UserRole)
        if isinstance(payload, GameObject3D):
            # Check if it's a Script object - open in MEPIDE
            if payload.class_name in ["Script", "LocalScript", "ModuleScript"]:
                self.open_script_object_in_mepide(payload)
            else:
                self.select_object(payload)
                self.focus_on_selection()
        elif isinstance(payload, tuple) and payload[0] in {
            "attached_script",
            "open_script",
        }:
            script_path = (
                payload[1] if payload[0] == "attached_script" else payload[1]["path"]
            )
            if script_path:
                self.open_script_file(script_path)

    def open_script_object_in_mepide(self, script_obj):
        """Open a Script instance in the MEPIDE tab"""
        # Switch to MEPIDE tab
        self.viewport_stack.setCurrentWidget(self.mepide_widget)

        # Create new tab for this script
        editor = ScriptEditor()
        source = getattr(script_obj, "source", "-- Empty script")
        editor.setText(source)

        # Add tab
        tab_name = f"{script_obj.name}.lua"
        index = self.mepide_tabs.addTab(editor, tab_name)
        self.mepide_tabs.setCurrentIndex(index)

        # Store reference to update script when saved
        editor.setProperty("script_object", script_obj)
        self.log_console(f"Opened script: {script_obj.name}")

    def rename_object(self, obj: GameObject3D):
        new_name, ok = QInputDialog.getText(
            self, "Rename", "Object name", text=obj.name
        )
        if ok and new_name:
            obj.name = new_name
            self.set_dirty(True)
            self.refresh_scene_tree()
            self.on_object_selected(obj)

    def toggle_lock(self, obj: GameObject3D):
        obj.locked = not obj.locked
        self.refresh_scene_tree()
        self.set_dirty(True)

    def toggle_visibility(self, obj: GameObject3D):
        obj.visible = not obj.visible
        self.refresh_scene_tree()
        self.gl_viewport.update()
        self.set_dirty(True)

    def update_scene_stats(self):
        objects = len(self.gl_viewport.objects)
        scripts = sum(
            len(getattr(obj, "scripts", [])) for obj in self.gl_viewport.objects
        )
        self.scene_stats_label.setText(f"Objects: {objects} • Scripts: {scripts}")

    # ------------------------------------------------------------------
    # Properties panel
    # ------------------------------------------------------------------
    def on_object_selected(self, obj: Optional[GameObject3D]):
        self.updating_properties = True
        try:
            # Sync tree selection with 3D viewport click
            if obj and obj.object_id in self.tree_items:
                self.scene_tree.blockSignals(True)
                self.scene_tree.clearSelection()
                self.tree_items[obj.object_id].setSelected(True)
                self.scene_tree.scrollToItem(self.tree_items[obj.object_id])
                self.scene_tree.blockSignals(False)
                self.selected_objects = [obj]

            if not obj:
                self.property_name.clear()
                self.script_list.clear()
                self.object_type_label.setText("Type: -")
                for spin in self.pos_spins + self.rot_spins + self.scale_spins:
                    spin.setValue(0)
                self.visible_check.setChecked(True)
                self.locked_check.setChecked(False)
                self.update_color_button([0.5, 0.5, 0.5])
                self.custom_props_group.setVisible(False)
                self.statusBar().showMessage("No object selected")
                return

            self.property_name.setText(obj.name)

            # Display type - use class_name, or shape_type for BasePart
            type_display = getattr(obj, "class_name", "Object")
            if hasattr(obj, "shape_type") and obj.shape_type:
                type_display = obj.shape_type.replace("_", " ").title()
            self.object_type_label.setText(f"Type: {type_display}")

            self.visible_check.setChecked(obj.visible)
            self.locked_check.setChecked(obj.locked)

            # Update transform spinboxes (only for BasePart objects)
            if hasattr(obj, "position"):
                for spin, value in zip(self.pos_spins, obj.position):
                    spin.blockSignals(True)
                    spin.setValue(value)
                    spin.blockSignals(False)
            else:
                for spin in self.pos_spins:
                    spin.blockSignals(True)
                    spin.setValue(0)
                    spin.blockSignals(False)

            if hasattr(obj, "rotation"):
                for spin, value in zip(self.rot_spins, obj.rotation):
                    spin.blockSignals(True)
                    spin.setValue(value)
                    spin.blockSignals(False)
            else:
                for spin in self.rot_spins:
                    spin.blockSignals(True)
                    spin.setValue(0)
                    spin.blockSignals(False)

            if hasattr(obj, "scale"):
                for spin, value in zip(self.scale_spins, obj.scale):
                    spin.blockSignals(True)
                    spin.setValue(value)
                    spin.blockSignals(False)
            else:
                for spin in self.scale_spins:
                    spin.blockSignals(True)
                    spin.setValue(1)
                    spin.blockSignals(False)

            if hasattr(obj, "color"):
                self.update_color_button(obj.color)
            else:
                self.update_color_button([0.5, 0.5, 0.5])

            self.populate_script_list(obj)

            # Show custom properties for special object types
            self._update_custom_properties(obj)

            self.statusBar().showMessage(f"Selected {obj.name}")
        finally:
            self.updating_properties = False

    def _update_custom_properties(self, obj: GameObject3D):
        """Update custom properties panel based on object type - shows all advanced properties"""
        # Clear existing widgets
        while self.custom_props_layout.count():
            item = self.custom_props_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        # Collect all advanced properties to display
        advanced_props = {}

        # Get class-specific properties from common attributes
        prop_names = [
            # Physics
            "anchored",
            "can_collide",
            "mass",
            "density",
            # Visual
            "transparency",
            "material",
            "reflectance",
            # Humanoid
            "health",
            "max_health",
            "walk_speed",
            "jump_power",
            "state",
            # Tool
            "equipped",
            "can_be_dropped",
            # Sound
            "sound_id",
            "volume",
            "pitch",
            "looped",
            "playing",
            "playback_speed",
            # Animation
            "animation_id",
            "priority",
            # Motor6D / Weld
            "part0",
            "part1",
            "c0_position",
            "c0_rotation",
            "c1_position",
            "c1_rotation",
            "current_angle",
            "desired_angle",
            "max_velocity",
            "enabled",
            # Script
            "source",
            "disabled",
            "script_path",
            # SpawnLocation
            "team_color",
            "neutral",
            "duration",
            # ProximityPrompt
            "action_text",
            "object_text",
            "key_code",
            "max_activation_distance",
            "hold_duration",
            # ClickDetector
            "cursor_icon",
            # BodyVelocity/BodyPosition/BodyGyro
            "velocity",
            "max_force",
            "cframe",
            "max_torque",
            "d",
            "p",
            # Explosion
            "blast_radius",
            "blast_pressure",
            # Constraint
            "attachment0",
            "attachment1",
            "limits_enabled",
            "upper_angle",
            "lower_angle",
            # Model
            "primary_part",
            # GUI
            "text",
            "text_color3",
            "text_size",
            "font",
            # Attachment
            "axis",
            "secondary_axis",
            # Value objects
            "_value",
        ]

        for prop in prop_names:
            if hasattr(obj, prop):
                value = getattr(obj, prop)
                if value is not None:  # Skip None values
                    advanced_props[prop] = value

        # Also include obj.properties dict
        if obj.properties:
            advanced_props.update(obj.properties)

        if not advanced_props:
            self.custom_props_group.setVisible(False)
            return

        self.custom_props_group.setVisible(True)
        self.custom_props_group.setTitle(f"📋 {obj.class_name} Properties")

        # Add property widgets based on type
        for key, value in advanced_props.items():
            label = key.replace("_", " ").title().lstrip()  # Clean up label

            if isinstance(value, bool):
                widget = QCheckBox()
                widget.setChecked(value)
                widget.toggled.connect(
                    lambda checked, k=key, o=obj: self._set_advanced_prop(o, k, checked)
                )
            elif isinstance(value, int):
                widget = QSpinBox()
                widget.setRange(-999999, 999999)
                widget.setValue(value)
                widget.valueChanged.connect(
                    lambda val, k=key, o=obj: self._set_advanced_prop(o, k, val)
                )
            elif isinstance(value, float):
                widget = QDoubleSpinBox()
                widget.setRange(-999999, 999999)
                widget.setDecimals(3)
                widget.setValue(float(value))
                widget.valueChanged.connect(
                    lambda val, k=key, o=obj: self._set_advanced_prop(o, k, val)
                )
            elif isinstance(value, str):
                if key == "source":
                    # Multi-line text edit for script source
                    widget = QPushButton("📝 Edit Source")
                    widget.clicked.connect(lambda _, o=obj: self._edit_script_source(o))
                elif key == "material":
                    widget = QComboBox()
                    materials = [
                        "Plastic",
                        "Wood",
                        "Slate",
                        "Concrete",
                        "CorrodedMetal",
                        "DiamondPlate",
                        "Foil",
                        "Grass",
                        "Ice",
                        "Marble",
                        "Granite",
                        "Brick",
                        "Pebble",
                        "Sand",
                        "Fabric",
                        "SmoothPlastic",
                        "Metal",
                        "WoodPlanks",
                        "Cobblestone",
                        "Neon",
                        "Glass",
                        "ForceField",
                    ]
                    widget.addItems(materials)
                    widget.setCurrentText(value)
                    widget.currentTextChanged.connect(
                        lambda val, k=key, o=obj: self._set_advanced_prop(o, k, val)
                    )
                elif key == "state":
                    widget = QComboBox()
                    states = [
                        "Idle",
                        "Running",
                        "Walking",
                        "Jumping",
                        "Falling",
                        "Dead",
                    ]
                    widget.addItems(states)
                    widget.setCurrentText(value)
                    widget.currentTextChanged.connect(
                        lambda val, k=key, o=obj: self._set_advanced_prop(o, k, val)
                    )
                elif key == "priority":
                    widget = QComboBox()
                    priorities = ["Idle", "Movement", "Action", "Core"]
                    widget.addItems(priorities)
                    widget.setCurrentText(value)
                    widget.currentTextChanged.connect(
                        lambda val, k=key, o=obj: self._set_advanced_prop(o, k, val)
                    )
                else:
                    widget = QLineEdit()
                    widget.setText(value)
                    widget.editingFinished.connect(
                        lambda k=key, w=widget, o=obj: self._set_advanced_prop(
                            o, k, w.text()
                        )
                    )
            elif isinstance(value, list):
                if len(value) == 3 and all(
                    isinstance(v, float) and 0 <= v <= 1 for v in value
                ):
                    # Likely a color
                    widget = QPushButton("🎨 Pick Color")
                    widget.clicked.connect(
                        lambda _, k=key, o=obj: self._pick_advanced_color(k, o)
                    )
                else:
                    # Vector display
                    widget = QLineEdit()
                    widget.setText(", ".join(f"{v:.2f}" for v in value))
                    widget.setReadOnly(True)  # Read-only for complex vectors
            else:
                widget = QLabel(str(value)[:50])  # Truncate long values

            self.custom_props_layout.addRow(label, widget)

    def _set_advanced_prop(self, obj: GameObject3D, key: str, value):
        """Set an advanced property on an object"""
        if hasattr(obj, key):
            setattr(obj, key, value)
        elif key in obj.properties:
            obj.properties[key] = value
        self.set_dirty(True)
        self.gl_viewport.update()

    def _pick_advanced_color(self, key: str, obj: GameObject3D):
        """Pick color for an advanced property"""
        current_color = (
            getattr(obj, key, [1, 1, 1])
            if hasattr(obj, key)
            else obj.properties.get(key, [1, 1, 1])
        )
        color = QColorDialog.getColor(
            QColor.fromRgbF(*current_color), self, f"Pick {key}"
        )
        if color.isValid():
            new_color = [color.redF(), color.greenF(), color.blueF()]
            self._set_advanced_prop(obj, key, new_color)
            self._update_custom_properties(obj)

    def _on_custom_prop_changed(self, key: str, value):
        """Handle custom property change"""
        obj = self.gl_viewport.selected_object
        if obj and key in obj.properties:
            obj.properties[key] = value
            self.set_dirty(True)

    def _edit_script_source(self, obj: GameObject3D):
        """Open script source in a new tab"""
        if "source" in obj.properties:
            editor = ScriptEditor()
            editor.setText(obj.properties["source"])
            tab_index = self.viewport_stack.addTab(editor, f"📄 {obj.name}")
            self.viewport_stack.setCurrentIndex(tab_index)
            self.script_tabs[editor] = {
                "name": obj.name,
                "path": None,
                "editor": editor,
                "object": obj,  # Link to object for saving
                "tab_index": tab_index,
            }
            self.refresh_scene_tree()

    def _pick_custom_color(self, key: str, obj: GameObject3D):
        """Pick color for a custom property"""
        current_color = obj.properties.get(key, [1, 1, 1])
        color = QColorDialog.getColor(
            QColor.fromRgbF(*current_color), self, f"Pick {key}"
        )
        if color.isValid():
            obj.properties[key] = [color.redF(), color.greenF(), color.blueF()]
            self.set_dirty(True)
            self._update_custom_properties(obj)

    def on_object_transformed(self, obj: GameObject3D):
        self.on_object_selected(obj)
        self.set_dirty(True)

    def on_property_changed(self):
        if self.updating_properties:
            return
        obj = self.gl_viewport.selected_object
        if not obj:
            return

        # Update object properties from UI
        new_name = self.property_name.text().strip()
        if new_name:
            obj.name = new_name
        obj.visible = self.visible_check.isChecked()
        obj.locked = self.locked_check.isChecked()

        # Update transforms (only for BasePart objects)
        if hasattr(obj, "position"):
            obj.position[0] = self.pos_spins[0].value()
            obj.position[1] = self.pos_spins[1].value()
            obj.position[2] = self.pos_spins[2].value()
        if hasattr(obj, "rotation"):
            obj.rotation[0] = self.rot_spins[0].value()
            obj.rotation[1] = self.rot_spins[1].value()
            obj.rotation[2] = self.rot_spins[2].value()
        if hasattr(obj, "scale"):
            obj.scale[0] = self.scale_spins[0].value()
            obj.scale[1] = self.scale_spins[1].value()
            obj.scale[2] = self.scale_spins[2].value()
        if hasattr(obj, "color"):
            obj.color = self.get_color_from_button()

        self.set_dirty(True)
        self.refresh_scene_tree()
        self.gl_viewport.update()

    def pick_object_color(self):
        obj = self.gl_viewport.selected_object
        if not obj or not hasattr(obj, "color"):
            return

        # Get current color from object directly
        current = QColor.fromRgbF(obj.color[0], obj.color[1], obj.color[2])
        color = QColorDialog.getColor(current, self, "Pick color")
        if color.isValid():
            # Update object color directly
            obj.color = [color.redF(), color.greenF(), color.blueF()]
            self.update_color_button(obj.color)
            self.set_dirty(True)
            self.gl_viewport.update()

    def update_color_button(self, color: List[float]):
        hex_color = "#%02x%02x%02x" % (
            int(color[0] * 255),
            int(color[1] * 255),
            int(color[2] * 255),
        )
        self.color_button.setStyleSheet(
            f"background-color: {hex_color}; border:1px solid #444;"
        )

    def get_color_from_button(self) -> List[float]:
        """Safely extract color from button stylesheet."""
        try:
            stylesheet = self.color_button.styleSheet()
            if "#" in stylesheet:
                hex_color = stylesheet.split("#")[-1].split(";")[0].strip()
                # Validate hex color has at least 6 characters
                if len(hex_color) >= 6:
                    r = int(hex_color[0:2], 16) / 255
                    g = int(hex_color[2:4], 16) / 255
                    b = int(hex_color[4:6], 16) / 255
                    return [r, g, b]
        except (ValueError, IndexError) as e:
            logger.debug(f"Color parsing error: {e}")
        return [0.5, 0.5, 0.5]  # Default gray if parsing fails

    def populate_script_list(self, obj: GameObject3D):
        self.script_list.clear()
        if hasattr(obj, "scripts"):
            for script in obj.scripts:
                self.script_list.addItem(script)

    def attach_script_to_object(self):
        obj = self.gl_viewport.selected_object
        if not obj:
            return
        if not hasattr(obj, "scripts"):
            obj.scripts = []  # Initialize if missing
        filepath, _ = QFileDialog.getOpenFileName(
            self, "Attach script", "", "Lua Files (*.lua)"
        )
        if filepath:
            obj.scripts.append(filepath)
            self.populate_script_list(obj)
            self.refresh_scene_tree()
            self.set_dirty(True)

    def remove_script_from_object(self):
        obj = self.gl_viewport.selected_object
        item = self.script_list.currentItem()
        if obj and item and hasattr(obj, "scripts"):
            obj.scripts.remove(item.text())
            self.populate_script_list(obj)
            self.refresh_scene_tree()
            self.set_dirty(True)

    def open_script_from_list(self, item: QListWidgetItem):
        self.open_script_file(item.text())

    # ------------------------------------------------------------------
    # Script tabs
    # ------------------------------------------------------------------
    def new_script(self):
        script_name = f"Script_{len(self.script_tabs)+1}.lua"
        editor = ScriptEditor()
        editor.setText("-- New MEPLUA script\n")
        tab_index = self.viewport_stack.addTab(editor, f"📄 {script_name}")
        self.viewport_stack.setCurrentIndex(tab_index)
        self.script_tabs[editor] = {
            "name": script_name,
            "path": None,
            "editor": editor,
            "tab_index": tab_index,
        }
        self.refresh_scene_tree()
        self.log_console(f"Created script {script_name}")

    def close_script_tab(self, index: int):
        widget = self.viewport_stack.widget(index)
        if widget is self.gl_viewport:
            return
        if isinstance(widget, ScriptEditor):
            self.script_tabs.pop(widget, None)
        self.viewport_stack.removeTab(index)
        self.refresh_scene_tree()

    def save_current_script(self):
        widget = self.viewport_stack.currentWidget()
        if widget is self.gl_viewport:
            # No script to save from 3D viewport
            return
        if widget is self.mepide_widget:
            # Save from MEPIDE
            current_editor = self.mepide_tabs.currentWidget()
            if isinstance(current_editor, ScriptEditor):
                filepath, _ = QFileDialog.getSaveFileName(
                    self, "Save IDE Script", "", "Lua (*.lua)"
                )
                if filepath:
                    with open(filepath, "w", encoding="utf-8") as fh:
                        fh.write(current_editor.text())
                    self.log_console(f"Saved IDE script to {filepath}")
            return
        if isinstance(widget, ScriptEditor):
            info = self.script_tabs.get(widget)
            if info and info["path"]:
                filepath = info["path"]
            else:
                filepath, _ = QFileDialog.getSaveFileName(
                    self, "Save Script", info["name"], "Lua (*.lua)"
                )
                if not filepath:
                    return
            with open(filepath, "w", encoding="utf-8") as fh:
                fh.write(widget.text())
            info["path"] = filepath
            info["name"] = os.path.basename(filepath)
            tab_index = self.viewport_stack.indexOf(widget)
            self.viewport_stack.setTabText(tab_index, f"📄 {info['name']}")
            self.refresh_scene_tree()
            self.log_console(f"Saved script {info['name']}")

    def load_script(self):
        filepath, _ = QFileDialog.getOpenFileName(
            self, "Open Script", "", "Lua (*.lua)"
        )
        if filepath:
            with open(filepath, "r", encoding="utf-8") as fh:
                content = fh.read()
            editor = ScriptEditor()
            editor.setText(content)
            tab_index = self.viewport_stack.addTab(
                editor, f"📄 {os.path.basename(filepath)}"
            )
            self.viewport_stack.setCurrentIndex(tab_index)
            self.script_tabs[editor] = {
                "name": os.path.basename(filepath),
                "path": filepath,
                "editor": editor,
                "tab_index": tab_index,
            }
            self.refresh_scene_tree()
            self.log_console(f"Opened script {filepath}")

    def open_script_file(self, filepath: str):
        if not os.path.exists(filepath):
            QMessageBox.warning(self, "Script missing", f"Cannot find {filepath}")
            return
        with open(filepath, "r", encoding="utf-8") as fh:
            content = fh.read()
        editor = ScriptEditor()
        editor.setText(content)
        tab_index = self.viewport_stack.addTab(
            editor, f"📄 {os.path.basename(filepath)}"
        )
        self.viewport_stack.setCurrentIndex(tab_index)
        self.script_tabs[editor] = {
            "name": os.path.basename(filepath),
            "path": filepath,
            "editor": editor,
            "tab_index": tab_index,
        }
        self.refresh_scene_tree()

    def focus_script_tab(self, editor: ScriptEditor):
        index = self.viewport_stack.indexOf(editor)
        if index >= 0:
            self.viewport_stack.setCurrentIndex(index)

    # ------------------------------------------------------------------
    # Import / export
    # ------------------------------------------------------------------
    def import_model(self):
        filepath, _ = QFileDialog.getOpenFileName(
            self, "Import OBJ", "", "OBJ Files (*.obj)"
        )
        if not filepath:
            return

        # Check file size (limit to 50MB)
        file_size = os.path.getsize(filepath)
        if file_size > 50 * 1024 * 1024:
            QMessageBox.warning(self, "Import", "File too large (max 50MB)")
            return

        vertices: List[List[float]] = []
        faces: List[List[int]] = []
        line_num = 0
        try:
            with open(filepath, "r", encoding="utf-8", errors="ignore") as fh:
                for line in fh:
                    line_num += 1
                    line = line.strip()
                    if line.startswith("v "):
                        parts = line.split()
                        if len(parts) >= 4:
                            try:
                                x, y, z = (
                                    float(parts[1]),
                                    float(parts[2]),
                                    float(parts[3]),
                                )
                                vertices.append([x, y, z])
                            except ValueError:
                                logger.warning(f"OBJ line {line_num}: invalid vertex")
                    elif line.startswith("f "):
                        parts = line.split()[1:]
                        try:
                            face = [int(part.split("/")[0]) - 1 for part in parts]
                            if len(face) >= 3:
                                faces.append(face[:3])
                        except ValueError:
                            logger.warning(f"OBJ line {line_num}: invalid face")

            if not vertices:
                QMessageBox.warning(self, "Import", "No valid vertices found in file")
                return

            # Normalize mesh size to fit within reasonable bounds
            if vertices:
                # Calculate bounding box
                min_x = min(v[0] for v in vertices)
                max_x = max(v[0] for v in vertices)
                min_y = min(v[1] for v in vertices)
                max_y = max(v[1] for v in vertices)
                min_z = min(v[2] for v in vertices)
                max_z = max(v[2] for v in vertices)

                # Get dimensions
                size_x = max_x - min_x
                size_y = max_y - min_y
                size_z = max_z - min_z
                max_dimension = max(size_x, size_y, size_z)

                # Scale to max 2 units if mesh is too large
                if max_dimension > 2.0:
                    scale_factor = 2.0 / max_dimension
                    center_x = (min_x + max_x) / 2
                    center_y = (min_y + max_y) / 2
                    center_z = (min_z + max_z) / 2

                    # Center and scale vertices
                    vertices = [
                        [
                            (v[0] - center_x) * scale_factor,
                            (v[1] - center_y) * scale_factor,
                            (v[2] - center_z) * scale_factor,
                        ]
                        for v in vertices
                    ]
                    logger.info(
                        f"Normalized mesh from {max_dimension:.2f} to 2.0 units"
                    )

            # Create MeshPart for imported geometry
            obj = create_instance("MeshPart", os.path.basename(filepath))
            if isinstance(obj, MeshPart):
                obj.mesh_vertices = vertices
                obj.mesh_faces = faces
                obj.mesh_file = filepath
                obj.color = [0.7, 0.7, 0.7]

            self.gl_viewport.add_object(obj)
            self.refresh_scene_tree()
            self.select_object(obj)
            self.set_dirty(True)
            self.log_console(
                f"Imported model {filepath} ({len(vertices)} verts, {len(faces)} faces)"
            )
        except Exception as exc:
            logger.exception("OBJ import error")
            QMessageBox.critical(self, "Import failed", str(exc))

    def export_model(self):
        obj = self.gl_viewport.selected_object
        if not obj:
            QMessageBox.warning(self, "Export", "Select an object first")
            return
        filepath, _ = QFileDialog.getSaveFileName(
            self, "Export OBJ", obj.name, "OBJ (*.obj)"
        )
        if not filepath:
            return
        vertices, faces = self._generate_mesh_data(obj)
        try:
            with open(filepath, "w", encoding="utf-8") as fh:
                for vx, vy, vz in vertices:
                    fh.write(f"v {vx} {vy} {vz}\n")
                for face in faces:
                    fh.write("f " + " ".join(str(idx + 1) for idx in face) + "\n")
            self.log_console(f"Exported {obj.name} to {filepath}")
        except Exception as exc:
            QMessageBox.critical(self, "Export failed", str(exc))

    def _generate_mesh_data(
        self, obj: GameObject3D
    ) -> Tuple[List[List[float]], List[List[int]]]:
        if obj.mesh_vertices and obj.mesh_faces:
            return obj.mesh_vertices, obj.mesh_faces
        vertices = []
        faces = []
        if obj.shape_type == "cube":
            base_vertices = [
                [-0.5, -0.5, -0.5],
                [0.5, -0.5, -0.5],
                [0.5, 0.5, -0.5],
                [-0.5, 0.5, -0.5],
                [-0.5, -0.5, 0.5],
                [0.5, -0.5, 0.5],
                [0.5, 0.5, 0.5],
                [-0.5, 0.5, 0.5],
            ]
            faces = [
                [0, 1, 2],
                [0, 2, 3],
                [4, 5, 6],
                [4, 6, 7],
                [0, 1, 5],
                [0, 5, 4],
                [2, 3, 7],
                [2, 7, 6],
                [1, 2, 6],
                [1, 6, 5],
                [0, 3, 7],
                [0, 7, 4],
            ]
            for vx, vy, vz in base_vertices:
                vertices.append(
                    [
                        obj.position[0] + vx * obj.scale[0],
                        obj.position[1] + vy * obj.scale[1],
                        obj.position[2] + vz * obj.scale[2],
                    ]
                )
        else:
            vertices = [[0, 0, 0]]
            faces = [[0, 0, 0]]
        return vertices, faces

    # ------------------------------------------------------------------
    # Project handling
    # ------------------------------------------------------------------
    def new_project(self):
        if self.scene_dirty and not self.confirm_discard_changes():
            return
        self.gl_viewport.clear_scene()
        self.script_tabs.clear()
        while self.viewport_stack.count() > 1:
            self.viewport_stack.removeTab(1)
        self.current_project_path = None
        self.refresh_scene_tree()
        self.set_dirty(False)
        self.log_console("Started new project")

    def open_project(self):
        if self.scene_dirty and not self.confirm_discard_changes():
            return
        filepath, _ = QFileDialog.getOpenFileName(
            self, "Open Project", "", "Micah Scene (*.json)"
        )
        if not filepath:
            return
        try:
            with open(filepath, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            self.gl_viewport.clear_scene()
            for obj_data in data.get("objects", []):
                self.gl_viewport.add_object(GameObject3D.from_dict(obj_data))
            camera = data.get("camera", {})
            self.gl_viewport.camera_distance = camera.get("distance", 12.0)
            self.gl_viewport.camera_yaw = camera.get("yaw", 45.0)
            self.gl_viewport.camera_pitch = camera.get("pitch", 28.0)
            self.gl_viewport.camera_target = camera.get("target", [0, 0, 0])
            bg = camera.get("background")
            if bg:
                self.gl_viewport.background_color = bg
            self.current_project_path = Path(filepath)
            self.refresh_scene_tree()
            self.set_dirty(False)
            self.log_console(f"Opened {filepath}")
        except Exception as exc:
            QMessageBox.critical(self, "Open failed", str(exc))

    def save_project(self):
        if self.current_project_path:
            filepath = self.current_project_path
        else:
            filepath = QFileDialog.getSaveFileName(
                self, "Save Project", "workspace", "Micah Scene (*.json)"
            )[0]
        if not filepath:
            return
        self._persist_project(Path(filepath))

    def save_project_as(self):
        filepath, _ = QFileDialog.getSaveFileName(
            self, "Save Project As", "workspace", "Micah Scene (*.json)"
        )
        if filepath:
            self._persist_project(Path(filepath))

    def _persist_project(self, path: Path):
        data = {
            "objects": [obj.to_dict() for obj in self.gl_viewport.objects],
            "camera": {
                "distance": self.gl_viewport.camera_distance,
                "yaw": self.gl_viewport.camera_yaw,
                "pitch": self.gl_viewport.camera_pitch,
                "target": self.gl_viewport.camera_target,
                "background": self.gl_viewport.background_color,
            },
            "saved_at": datetime.utcnow().isoformat(),
        }
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2)
        self.current_project_path = path
        self.set_dirty(False)
        self.log_console(f"Saved project to {path}")

    def confirm_discard_changes(self) -> bool:
        return (
            QMessageBox.question(self, "Unsaved changes", "Discard current changes?")
            == QMessageBox.Yes
        )

    def set_dirty(self, dirty: bool):
        self.scene_dirty = dirty
        suffix = "*" if dirty else ""
        name = (
            self.current_project_path.name if self.current_project_path else "Untitled"
        )
        self.setWindowTitle(f"Micah Engine Studio - {name}{suffix}")

    # ------------------------------------------------------------------
    # Scripting (Lua Runtime) - Scene State Management
    # ------------------------------------------------------------------
    def _save_scene_snapshot(self):
        """Serialize scene state before entering play mode"""
        import copy

        self._scene_snapshot = []
        for obj in self.gl_viewport.objects:
            self._scene_snapshot.append(obj.to_dict())
        self.log_console("📸 Scene state saved")

    def _restore_scene_snapshot(self):
        """Restore scene state after exiting play mode"""
        if not hasattr(self, "_scene_snapshot") or not self._scene_snapshot:
            return

        # Clear current objects
        self.gl_viewport.objects.clear()

        # Restore from snapshot
        for obj_data in self._scene_snapshot:
            obj = instance_from_dict(obj_data)
            self.gl_viewport.objects.append(obj)

        self._scene_snapshot = None
        self.refresh_scene_tree()
        self.log_console("🔄 Scene state restored")

    def run_script(self):
        if self.play_mode:
            self.log_console("⚠️ Already running")
            return

        if not self.lua_runtime.is_available():
            self.log_console("❌ Lua runtime not available - install 'lupa' package")
            return

        try:
            # Save scene state before playing
            self._save_scene_snapshot()

            # Register all objects with the Lua runtime
            self.lua_runtime.register_objects(self.gl_viewport.objects)

            # Set callback for adding new instances from scripts
            self.lua_runtime.set_scene_add_callback(self._add_script_instance)

            # Load scripts from MEPIDE tabs
            for i in range(self.mepide_tabs.count()):
                editor = self.mepide_tabs.widget(i)
                if isinstance(editor, ScriptEditor):
                    tab_name = self.mepide_tabs.tabText(i)
                    ide_code = editor.text()
                    if ide_code.strip():
                        success = self.lua_runtime.load_script(tab_name, ide_code)
                        if not success:
                            self.log_console(f"⚠️ {tab_name} has errors - check console")

            # Load scripts attached to objects (Script instances)
            for obj in self.gl_viewport.objects:
                self._load_object_scripts(obj)

            # Start execution
            self.lua_runtime.start()
            self.play_mode = True
            self.play_timer.start(16)  # ~60 FPS

            self.log_console("▶️ Play mode started - Scene is now LIVE")
            self.statusBar().showMessage("▶️ PLAYING - Press Stop to exit")
        except Exception as e:
            self.log_console(f"❌ Failed to start: {e}")
            logger.exception("Error starting play mode")
            self.play_mode = False
            self._restore_scene_snapshot()

    def _load_object_scripts(self, obj):
        """Recursively load Script instances from objects"""
        # Check if this object is a Script
        if isinstance(obj, Script) and not obj.disabled:
            if obj.source and obj.source.strip():
                self.lua_runtime.load_script(obj.name, obj.source, obj)
                self.log_console(f"📜 Loaded script: {obj.name}")

        # Check legacy script paths
        if hasattr(obj, "scripts"):
            for script_path in obj.scripts:
                if os.path.exists(script_path):
                    self.lua_runtime.load_script_file(script_path)
                else:
                    self.log_console(f"⚠️ Script not found: {script_path}")

        # Load scripts from children
        for child in obj.children:
            self._load_object_scripts(child)

    def _add_script_instance(self, obj):
        """Callback when script creates a new instance"""
        self.gl_viewport.add_object(obj)
        self.refresh_scene_tree()

    def stop_script(self):
        if not self.play_mode:
            return

        self.play_timer.stop()
        self.lua_runtime.stop()
        self.play_mode = False

        # Restore scene to pre-play state
        self._restore_scene_snapshot()

        self.log_console("⏹️ Play mode stopped - Scene restored")
        self.statusBar().showMessage("Ready")

        # Refresh the UI
        self.gl_viewport.update()
        self.gl_viewport.selected_object = None
        self.on_object_selected(None) if self.gl_viewport.objects else None

    def _update_play_mode(self):
        """Called each frame during play mode"""
        if not self.play_mode:
            return

        dt = 0.016  # ~60 FPS
        self.lua_runtime.update(dt)

        # Check for collisions and fire Touched events
        all_parts = [
            obj
            for obj in self.gl_viewport.objects
            if hasattr(obj, "position") and hasattr(obj, "scale")
        ]
        self.lua_runtime.check_collisions(all_parts)

        # Update viewport to show changes
        self.gl_viewport.update()

        # Update properties panel if object is selected
        obj = self.gl_viewport.selected_object
        if obj and hasattr(obj, "position"):
            self.updating_properties = True
            try:
                if hasattr(obj, "position"):
                    for spin, value in zip(self.pos_spins, obj.position):
                        spin.setValue(value)
                if hasattr(obj, "rotation"):
                    for spin, value in zip(self.rot_spins, obj.rotation):
                        spin.setValue(value)
                if hasattr(obj, "scale"):
                    for spin, value in zip(self.scale_spins, obj.scale):
                        spin.setValue(value)
                if hasattr(obj, "color"):
                    self.update_color_button(obj.color)
            finally:
                self.updating_properties = False

    def _log_lua_error(self, message: str):
        """Log Lua errors to console"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.console_output.append(
            f"<span style='color:#ff5555'>[{timestamp}] ❌ {message}</span>"
        )

    # ------------------------------------------------------------------
    # Utilities
    # ------------------------------------------------------------------
    def log_console(self, message: str):
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.console_output.append(f"[{timestamp}] {message}")

    def _log_diagnostics(self, message: str):
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.diagnostics_log.append(f"[{timestamp}] {message}")

    def run_engine_diagnostics(self):
        checklist = [
            ("Viewport", bool(self.gl_viewport)),
            ("Objects", len(self.gl_viewport.objects) >= 0),
            ("Scripts", True),
            ("Lighting", self.light_check.isChecked()),
        ]
        for label, ok in checklist:
            status = "OK" if ok else "FAIL"
            self._log_diagnostics(f"{label}: {status}")
        self._log_diagnostics("Diagnostics complete")

    def pick_background_color(self):
        current = QColor.fromRgbF(*self.gl_viewport.background_color)
        color = QColorDialog.getColor(current, self, "Sky color")
        if color.isValid():
            self.gl_viewport.set_background_color(color)
            self.set_dirty(True)

    def reset_camera(self):
        self.gl_viewport.camera_distance = 12.0
        self.gl_viewport.camera_yaw = 45.0
        self.gl_viewport.camera_pitch = 28.0
        self.gl_viewport.camera_target = [0, 0, 0]
        self.log_console("Camera reset")

    def _apply_grid_settings(self):
        self.gl_viewport.set_grid_settings(
            self.grid_extent_spin.value(), self.grid_spacing_spin.value()
        )

    def _apply_snap_settings(self):
        self.gl_viewport.set_snap_settings(
            self.snap_enabled_check.isChecked(),
            self.snap_translate_combo.currentData(),
            self.snap_rotate_combo.currentData(),
            self.snap_scale_combo.currentData(),
        )


def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    palette = app.palette()
    palette.setColor(palette.Window, QColor(45, 45, 52))
    palette.setColor(palette.WindowText, Qt.white)
    palette.setColor(palette.Base, QColor(28, 28, 34))
    palette.setColor(palette.AlternateBase, QColor(45, 45, 52))
    palette.setColor(palette.ToolTipBase, Qt.white)
    palette.setColor(palette.ToolTipText, Qt.white)
    palette.setColor(palette.Text, Qt.white)
    palette.setColor(palette.Button, QColor(45, 45, 52))
    palette.setColor(palette.ButtonText, Qt.white)
    palette.setColor(palette.Highlight, QColor(0, 120, 212))
    palette.setColor(palette.HighlightedText, Qt.white)
    app.setPalette(palette)

    window = StudioMainWindow()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
