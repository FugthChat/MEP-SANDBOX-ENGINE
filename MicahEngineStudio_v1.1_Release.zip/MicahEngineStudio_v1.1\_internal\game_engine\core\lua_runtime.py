"""
MEPLua Runtime for Micah Engine Studio
Advanced Lua scripting integration with Roblox-style API
Supports: wait(), script.Parent, Instance.new(), Touched events, property modification
"""

from typing import Dict, List, Optional, Any, Callable, Set
import math
import os
import time
from collections import deque

try:
    from lupa import LuaRuntime, LuaError

    LUPA_AVAILABLE = True
except ImportError:
    LUPA_AVAILABLE = False
    LuaRuntime = None
    LuaError = Exception

from .instances import (
    Instance,
    BasePart,
    Part,
    Script,
    LocalScript,
    ModuleScript,
    Humanoid,
    create_instance,
)

# Alias for backward compatibility
GameObject3D = BasePart


class WaitTask:
    """Represents a waiting coroutine"""

    def __init__(self, resume_time: float, callback: Callable):
        self.resume_time = resume_time
        self.callback = callback


class TouchedConnection:
    """Represents a Touched event connection"""

    def __init__(self, part: BasePart, callback: Callable):
        self.part = part
        self.callback = callback
        self.connected = True

    def disconnect(self):
        self.connected = False


class Signal:
    """Event signal system for Roblox-style events"""

    def __init__(self, name: str = "Signal"):
        self.name = name
        self.connections: List[Callable] = []

    def connect(self, callback: Callable) -> "SignalConnection":
        """Connect a callback to this signal"""
        self.connections.append(callback)
        return SignalConnection(self, callback)

    def fire(self, *args):
        """Fire the signal, calling all connected callbacks"""
        for callback in self.connections[:]:
            try:
                callback(*args)
            except Exception as e:
                print(f"Signal '{self.name}' error: {e}")

    def wait(self):
        """Wait for the signal to fire"""
        pass


class SignalConnection:
    """Represents a connection to a signal"""

    def __init__(self, signal: Signal, callback: Callable):
        self.signal = signal
        self.callback = callback
        self.connected = True

    def disconnect(self):
        if self.connected and self.callback in self.signal.connections:
            self.signal.connections.remove(self.callback)
            self.connected = False


class StudioLuaRuntime:
    """Enhanced Lua runtime manager with Roblox-style API"""

    def __init__(self):
        self.lua: Optional[Any] = None
        self.scripts: Dict[str, "StudioScript"] = {}
        self.objects: Dict[str, Instance] = {}
        self.objects_by_id: Dict[str, Instance] = {}
        self.running = False
        self.time = 0.0
        self.delta_time = 0.0
        self._print_callback: Optional[Callable[[str], None]] = None
        self._error_callback: Optional[Callable[[str], None]] = None

        # Wait/coroutine system
        self.wait_tasks: List[WaitTask] = []

        # Touched event system
        self.touched_connections: List[TouchedConnection] = []
        self.last_collisions: Set[tuple] = set()

        # Scene reference for creating new instances
        self.scene_add_callback: Optional[Callable[[Instance], None]] = None

        if LUPA_AVAILABLE:
            self._init_lua()

    def _init_lua(self):
        """Initialize the Lua runtime with Roblox-style engine bindings"""
        self.lua = LuaRuntime(unpack_returned_tuples=True)
        g = self.lua.globals()

        # Math constants
        g.PI = math.pi
        g.TAU = math.tau

        # Time (updated each frame)
        g.time = 0.0
        g.delta_time = 0.0

        # === GLOBAL FUNCTIONS ===
        g.print = self._lua_print
        g.warn = lambda *args: self._lua_print("[WARN]", *args)
        g.wait = self._lua_wait
        g.delay = self._lua_delay
        g.spawn = self._lua_spawn
        g.tick = lambda: time.time()
        g.elapsedTime = lambda: self.time
        g.typeof = lambda obj: type(obj).__name__

        # === Instance API ===
        instance_api = self.lua.table()
        instance_api.new = self._lua_instance_new
        g.Instance = instance_api

        # === game/workspace objects ===
        game = self.lua.table()
        game.GetService = self._lua_get_service
        g.game = game

        workspace = self.lua.table()
        workspace.GetChildren = self._lua_workspace_get_children
        workspace.FindFirstChild = self._lua_workspace_find_first_child
        g.workspace = workspace
        g.Workspace = workspace

        # === Vector3 API ===
        vector3 = self.lua.table()
        vector3.new = lambda x=0, y=0, z=0: self._create_vector3(x, y, z)
        vector3.zero = self._create_vector3(0, 0, 0)
        vector3.one = self._create_vector3(1, 1, 1)
        g.Vector3 = vector3

        # === Color3 API ===
        color3 = self.lua.table()
        color3.new = lambda r=0, g=0, b=0: self._create_color3(r, g, b)
        color3.fromRGB = lambda r, g, b: self._create_color3(r / 255, g / 255, b / 255)
        color3.fromHSV = self._create_color3_from_hsv
        g.Color3 = color3

        # === CFrame API ===
        cframe = self.lua.table()
        cframe.new = self._create_cframe
        cframe.Angles = self._create_cframe_angles
        g.CFrame = cframe

        # Create Engine API (backward compatible)
        engine = self.lua.table()
        engine.get_object = self._lua_get_object
        engine.get_all_objects = self._lua_get_all_objects
        engine.set_position = self._lua_set_position
        engine.set_rotation = self._lua_set_rotation
        engine.set_scale = self._lua_set_scale
        engine.get_position = self._lua_get_position
        engine.get_rotation = self._lua_get_rotation
        engine.get_scale = self._lua_get_scale
        engine.move = self._lua_move
        engine.rotate = self._lua_rotate
        engine.set_color = self._lua_set_color
        engine.set_visible = self._lua_set_visible
        engine.set_property = self._lua_set_property
        engine.get_property = self._lua_get_property

        # Math utilities
        engine.sin = math.sin
        engine.cos = math.cos
        engine.tan = math.tan
        engine.sqrt = math.sqrt
        engine.abs = abs
        engine.min = min
        engine.max = max
        engine.clamp = lambda x, lo, hi: max(lo, min(hi, x))
        engine.lerp = lambda a, b, t: a + (b - a) * t
        engine.rad = math.radians
        engine.deg = math.degrees
        engine.random = lambda a=0, b=1: a + (b - a) * __import__("random").random()
        engine.print = self._lua_print

        g.Engine = engine

        # Also expose common functions globally
        g.get_object = engine.get_object
        g.set_position = engine.set_position
        g.set_rotation = engine.set_rotation
        g.set_scale = engine.set_scale
        g.move = engine.move
        g.rotate = engine.rotate
        g.set_color = engine.set_color
        g.sin = engine.sin
        g.cos = engine.cos
        g.lerp = engine.lerp
        g.clamp = engine.clamp

    def set_print_callback(self, callback: Callable[[str], None]):
        """Set callback for Lua print statements"""
        self._print_callback = callback

    def set_error_callback(self, callback: Callable[[str], None]):
        """Set callback for Lua errors"""
        self._error_callback = callback

    def set_scene_add_callback(self, callback: Callable[[Instance], None]):
        """Set callback for adding new instances to scene"""
        self.scene_add_callback = callback

    def _lua_print(self, *args):
        """Print from Lua to console"""
        message = " ".join(str(a) for a in args)
        if self._print_callback:
            self._print_callback(f"[Lua] {message}")
        else:
            print(f"[Lua] {message}")

    def _report_error(self, message: str):
        """Report an error"""
        if self._error_callback:
            self._error_callback(message)
        else:
            print(f"[Lua Error] {message}")

    # ========== WAIT / COROUTINE SYSTEM ==========

    def _lua_wait(self, seconds: float = 0.03):
        """Non-blocking wait function."""
        return max(0.03, float(seconds)), self.time

    def _lua_delay(self, delay_time: float, callback):
        """Schedule a function to run after delay"""
        resume_time = self.time + delay_time
        self.wait_tasks.append(WaitTask(resume_time, callback))

    def _lua_spawn(self, callback):
        """Spawn a new thread (runs immediately)"""
        try:
            callback()
        except Exception as e:
            self._report_error(f"spawn error: {e}")

    # ========== INSTANCE API ==========

    def _lua_instance_new(self, class_name: str, parent=None):
        """Create a new Instance (Roblox-style Instance.new)"""
        try:
            obj = create_instance(class_name, class_name)

            if parent is not None:
                if hasattr(parent, "_obj"):
                    parent._obj.add_child(obj)
                elif isinstance(parent, Instance):
                    parent.add_child(obj)

            if self.scene_add_callback and parent is None:
                self.scene_add_callback(obj)

            self.objects[obj.name] = obj
            self.objects_by_id[obj.object_id] = obj

            self._lua_print(f"Created {class_name}: {obj.name}")
            return LuaInstanceWrapper(obj, self)
        except Exception as e:
            self._report_error(f"Instance.new error: {e}")
            return None

    def _lua_get_service(self, service_name: str):
        """Get a game service (stub for compatibility)"""
        return self.lua.table()

    def _lua_workspace_get_children(self):
        """Get all objects in workspace"""
        return list(self.objects.keys())

    def _lua_workspace_find_first_child(self, name: str):
        """Find object by name in workspace"""
        obj = self.objects.get(name)
        if obj:
            return LuaInstanceWrapper(obj, self)
        return None

    # ========== VECTOR3/COLOR3/CFRAME HELPERS ==========

    def _create_vector3(self, x=0, y=0, z=0):
        """Create a Vector3 table"""
        v = self.lua.table()
        v.X = float(x)
        v.Y = float(y)
        v.Z = float(z)
        v.x = v.X
        v.y = v.Y
        v.z = v.Z
        v.Magnitude = math.sqrt(x * x + y * y + z * z)
        return v

    def _create_color3(self, r=0, g=0, b=0):
        """Create a Color3 table"""
        c = self.lua.table()
        c.R = float(r)
        c.G = float(g)
        c.B = float(b)
        c.r = c.R
        c.g = c.G
        c.b = c.B
        return c

    def _create_color3_from_hsv(self, h, s, v):
        """Create Color3 from HSV"""
        import colorsys

        r, g, b = colorsys.hsv_to_rgb(h, s, v)
        return self._create_color3(r, g, b)

    def _create_cframe(self, *args):
        """Create a CFrame table"""
        cf = self.lua.table()
        if len(args) >= 3:
            cf.X = float(args[0])
            cf.Y = float(args[1])
            cf.Z = float(args[2])
        else:
            cf.X = 0
            cf.Y = 0
            cf.Z = 0
        cf.Position = self._create_vector3(cf.X, cf.Y, cf.Z)
        return cf

    def _create_cframe_angles(self, rx, ry, rz):
        """Create CFrame from angles"""
        cf = self._create_cframe(0, 0, 0)
        cf.rx = float(rx)
        cf.ry = float(ry)
        cf.rz = float(rz)
        return cf

    # ========== OBJECT API ==========

    def _lua_get_object(self, name: str) -> Optional["LuaInstanceWrapper"]:
        """Get object by name"""
        obj = self.objects.get(name)
        if obj:
            return LuaInstanceWrapper(obj, self)
        return None

    def _lua_get_all_objects(self):
        """Get list of all object names"""
        return list(self.objects.keys())

    def _lua_set_position(self, name: str, x: float, y: float, z: float):
        """Set object position"""
        obj = self.objects.get(name)
        if obj and hasattr(obj, "position"):
            obj.position = [float(x), float(y), float(z)]

    def _lua_set_rotation(self, name: str, rx: float, ry: float, rz: float):
        """Set object rotation"""
        obj = self.objects.get(name)
        if obj and hasattr(obj, "rotation"):
            obj.rotation = [float(rx), float(ry), float(rz)]

    def _lua_set_scale(self, name: str, sx: float, sy: float, sz: float):
        """Set object scale"""
        obj = self.objects.get(name)
        if obj and hasattr(obj, "scale"):
            obj.scale = [float(sx), float(sy), float(sz)]

    def _lua_get_position(self, name: str):
        """Get object position"""
        obj = self.objects.get(name)
        if obj and hasattr(obj, "position"):
            return tuple(obj.position)
        return (0, 0, 0)

    def _lua_get_rotation(self, name: str):
        """Get object rotation"""
        obj = self.objects.get(name)
        if obj and hasattr(obj, "rotation"):
            return tuple(obj.rotation)
        return (0, 0, 0)

    def _lua_get_scale(self, name: str):
        """Get object scale"""
        obj = self.objects.get(name)
        if obj and hasattr(obj, "scale"):
            return tuple(obj.scale)
        return (1, 1, 1)

    def _lua_move(self, name: str, dx: float, dy: float, dz: float):
        """Move object by offset"""
        obj = self.objects.get(name)
        if obj and hasattr(obj, "position"):
            obj.position[0] += float(dx)
            obj.position[1] += float(dy)
            obj.position[2] += float(dz)

    def _lua_rotate(self, name: str, rx: float, ry: float, rz: float):
        """Rotate object by offset"""
        obj = self.objects.get(name)
        if obj and hasattr(obj, "rotation"):
            obj.rotation[0] += float(rx)
            obj.rotation[1] += float(ry)
            obj.rotation[2] += float(rz)

    def _lua_set_color(self, name: str, r: float, g: float, b: float):
        """Set object color"""
        obj = self.objects.get(name)
        if obj and hasattr(obj, "color"):
            obj.color = [float(r), float(g), float(b)]

    def _lua_set_visible(self, name: str, visible: bool):
        """Set object visibility"""
        obj = self.objects.get(name)
        if obj:
            obj.visible = bool(visible)

    def _lua_set_property(self, name: str, prop: str, value):
        """Set any object property"""
        obj = self.objects.get(name)
        if obj and hasattr(obj, prop):
            setattr(obj, prop, value)

    def _lua_get_property(self, name: str, prop: str):
        """Get any object property"""
        obj = self.objects.get(name)
        if obj and hasattr(obj, prop):
            return getattr(obj, prop)
        return None

    # ========== TOUCHED EVENT SYSTEM ==========

    def register_touched_callback(
        self, part: BasePart, callback: Callable
    ) -> TouchedConnection:
        """Register a Touched event handler for a part"""
        connection = TouchedConnection(part, callback)
        self.touched_connections.append(connection)
        return connection

    def check_collisions(self, all_parts: List[BasePart]):
        """Check for collisions between parts and fire Touched events"""
        current_collisions = set()

        for i, part_a in enumerate(all_parts):
            if not hasattr(part_a, "position") or not hasattr(part_a, "scale"):
                continue
            for j, part_b in enumerate(all_parts):
                if i >= j:
                    continue
                if not hasattr(part_b, "position") or not hasattr(part_b, "scale"):
                    continue

                if self._check_aabb_collision(part_a, part_b):
                    collision_key = (part_a.object_id, part_b.object_id)
                    current_collisions.add(collision_key)

                    if collision_key not in self.last_collisions:
                        self._fire_touched(part_a, part_b)
                        self._fire_touched(part_b, part_a)

        self.last_collisions = current_collisions

    def _check_aabb_collision(self, a: BasePart, b: BasePart) -> bool:
        """Simple AABB collision detection"""
        a_min = [a.position[i] - a.scale[i] / 2 for i in range(3)]
        a_max = [a.position[i] + a.scale[i] / 2 for i in range(3)]
        b_min = [b.position[i] - b.scale[i] / 2 for i in range(3)]
        b_max = [b.position[i] + b.scale[i] / 2 for i in range(3)]

        return (
            a_min[0] <= b_max[0]
            and a_max[0] >= b_min[0]
            and a_min[1] <= b_max[1]
            and a_max[1] >= b_min[1]
            and a_min[2] <= b_max[2]
            and a_max[2] >= b_min[2]
        )

    def _fire_touched(self, part: BasePart, other: BasePart):
        """Fire Touched event for a part"""
        for conn in self.touched_connections:
            if conn.connected and conn.part.object_id == part.object_id:
                try:
                    conn.callback(LuaInstanceWrapper(other, self))
                except Exception as e:
                    self._report_error(f"Touched event error: {e}")

    # ========== SCRIPT MANAGEMENT ==========

    def register_objects(self, objects: List[Instance]):
        """Register scene objects for Lua access"""
        self.objects.clear()
        self.objects_by_id.clear()
        for obj in objects:
            self.objects[obj.name] = obj
            self.objects_by_id[obj.object_id] = obj
            self._register_children(obj)

    def _register_children(self, obj: Instance):
        """Recursively register children"""
        for child in obj.children:
            self.objects[child.name] = child
            self.objects_by_id[child.object_id] = child
            self._register_children(child)

    def load_script(
        self, name: str, code: str, script_instance: Optional[Script] = None
    ) -> bool:
        """Load a Lua script from code string"""
        if not LUPA_AVAILABLE:
            self._report_error("Lua runtime not available (lupa not installed)")
            return False

        try:
            script = StudioScript(name, code, self, script_instance)
            self.scripts[name] = script
            return True
        except Exception as e:
            self._report_error(f"Failed to load script '{name}': {e}")
            return False

    def load_script_file(self, filepath: str) -> bool:
        """Load a Lua script from file"""
        if not os.path.exists(filepath):
            self._report_error(f"Script file not found: {filepath}")
            return False

        try:
            with open(filepath, "r", encoding="utf-8") as f:
                code = f.read()
            name = os.path.basename(filepath)
            return self.load_script(name, code)
        except Exception as e:
            self._report_error(f"Failed to read script file: {e}")
            return False

    def start(self):
        """Start script execution"""
        if not LUPA_AVAILABLE:
            self._report_error("Lua runtime not available")
            return

        self.running = True
        self.time = 0.0
        self.wait_tasks.clear()

        for script in self.scripts.values():
            script.initialize()

        for script in self.scripts.values():
            script.call_start()

    def stop(self):
        """Stop script execution"""
        self.running = False
        self.wait_tasks.clear()
        self.touched_connections.clear()
        self.last_collisions.clear()
        for script in self.scripts.values():
            script.cleanup()
        self.scripts.clear()

    def update(self, dt: float):
        """Update all scripts (called each frame) with error isolation"""
        if not self.running or not LUPA_AVAILABLE:
            return

        self.delta_time = dt
        self.time += dt

        try:
            g = self.lua.globals()
            g.time = self.time
            g.delta_time = self.delta_time
        except Exception as e:
            self._report_error(f"Failed to update Lua globals: {e}")
            return

        # Process wait tasks
        ready_tasks = [t for t in self.wait_tasks if t.resume_time <= self.time]
        self.wait_tasks = [t for t in self.wait_tasks if t.resume_time > self.time]
        for task in ready_tasks:
            try:
                task.callback()
            except Exception as e:
                self._report_error(f"Wait task error: {e}")

        # Call on_update for all scripts
        failed_scripts = []
        for name, script in self.scripts.items():
            try:
                script.call_update(dt)
            except Exception as e:
                self._report_error(f"Script '{name}' crashed: {e}")
                failed_scripts.append(name)

        for name in failed_scripts:
            self._report_error(f"Disabled script '{name}' due to errors")
            del self.scripts[name]

    def is_available(self) -> bool:
        """Check if Lua runtime is available"""
        return LUPA_AVAILABLE


class StudioScript:
    """A single Lua script in the Studio environment"""

    def __init__(
        self,
        name: str,
        code: str,
        runtime: StudioLuaRuntime,
        script_instance: Optional[Script] = None,
    ):
        self.name = name
        self.code = code
        self.runtime = runtime
        self.script_instance = script_instance
        self._start_func = None
        self._update_func = None
        self.initialized = False

    def initialize(self):
        """Execute the script code"""
        if self.initialized:
            return

        try:
            g = self.runtime.lua.globals()

            if self.script_instance:
                script_wrapper = LuaInstanceWrapper(self.script_instance, self.runtime)
                g.script = script_wrapper
            else:
                script_obj = self.runtime.lua.table()
                script_obj.Name = self.name
                script_obj.Parent = None
                g.script = script_obj

            self.runtime.lua.execute(self.code)

            if "on_start" in g:
                self._start_func = g["on_start"]
            if "on_update" in g:
                self._update_func = g["on_update"]

            self.initialized = True
            self.runtime._lua_print(f"Script '{self.name}' loaded")

        except LuaError as e:
            self.runtime._report_error(f"Script '{self.name}' error: {e}")

    def call_start(self):
        """Call the on_start function"""
        if self._start_func:
            try:
                self._start_func()
            except LuaError as e:
                self.runtime._report_error(f"on_start error in '{self.name}': {e}")

    def call_update(self, dt: float):
        """Call the on_update function"""
        if self._update_func:
            try:
                self._update_func(dt)
            except LuaError as e:
                self.runtime._report_error(f"on_update error in '{self.name}': {e}")

    def cleanup(self):
        """Cleanup script resources"""
        self._start_func = None
        self._update_func = None
        self.initialized = False


class LuaInstanceWrapper:
    """Wrapper to expose Instance objects to Lua with Roblox-style API."""

    def __init__(self, obj: Instance, runtime: StudioLuaRuntime):
        self._obj = obj
        self._runtime = runtime
        self._touched_signal = None

    def __getattr__(self, name):
        if name.startswith("_"):
            return object.__getattribute__(self, name)

        obj = object.__getattribute__(self, "_obj")
        runtime = object.__getattribute__(self, "_runtime")

        # Common properties
        if name == "Name":
            return obj.name
        elif name == "ClassName":
            return obj.class_name
        elif name == "Parent":
            if obj.parent_id:
                parent = runtime.objects_by_id.get(obj.parent_id)
                if parent:
                    return LuaInstanceWrapper(parent, runtime)
            return None

        # BasePart properties
        elif name == "Position" and hasattr(obj, "position"):
            return runtime._create_vector3(*obj.position)
        elif name == "Rotation" and hasattr(obj, "rotation"):
            return runtime._create_vector3(*obj.rotation)
        elif name == "Size" and hasattr(obj, "scale"):
            return runtime._create_vector3(*obj.scale)
        elif name == "Color" and hasattr(obj, "color"):
            return runtime._create_color3(*obj.color)
        elif name == "Transparency" and hasattr(obj, "transparency"):
            return obj.transparency
        elif name == "Anchored" and hasattr(obj, "anchored"):
            return obj.anchored
        elif name == "CanCollide" and hasattr(obj, "can_collide"):
            return obj.can_collide

        # Humanoid properties
        elif name == "Health" and hasattr(obj, "health"):
            return obj.health
        elif name == "MaxHealth" and hasattr(obj, "max_health"):
            return obj.max_health
        elif name == "WalkSpeed" and hasattr(obj, "walk_speed"):
            return obj.walk_speed
        elif name == "JumpPower" and hasattr(obj, "jump_power"):
            return obj.jump_power

        # Value objects
        elif name == "Value" and hasattr(obj, "value"):
            return obj.value

        # Events
        elif name == "Touched" and isinstance(obj, BasePart):
            if self._touched_signal is None:
                self._touched_signal = LuaTouchedSignal(obj, runtime)
            return self._touched_signal
        elif name == "Died" and isinstance(obj, Humanoid):
            return LuaSignal("Died")

        # Methods
        elif name == "FindFirstChild":
            return lambda child_name: self._find_first_child(child_name)
        elif name == "GetChildren":
            return lambda: self._get_children()
        elif name == "Destroy":
            return lambda: self._destroy()
        elif name == "Clone":
            return lambda: self._clone()
        elif name == "TakeDamage" and isinstance(obj, Humanoid):
            return lambda amount: obj.take_damage(amount)

        # Fallback
        if hasattr(obj, name.lower()):
            return getattr(obj, name.lower())
        if hasattr(obj, name):
            return getattr(obj, name)

        return None

    def __setattr__(self, name, value):
        if name.startswith("_"):
            object.__setattr__(self, name, value)
            return

        obj = object.__getattribute__(self, "_obj")
        runtime = object.__getattribute__(self, "_runtime")

        if name == "Name":
            old_name = obj.name
            obj.name = str(value)
            if old_name in runtime.objects:
                del runtime.objects[old_name]
            runtime.objects[obj.name] = obj
        elif name == "Parent":
            if value is None:
                if obj.parent_id:
                    parent = runtime.objects_by_id.get(obj.parent_id)
                    if parent:
                        parent.remove_child(obj)
            elif hasattr(value, "_obj"):
                value._obj.add_child(obj)
        elif name == "Position" and hasattr(obj, "position"):
            if hasattr(value, "X"):
                obj.position = [value.X, value.Y, value.Z]
            elif isinstance(value, (list, tuple)):
                obj.position = list(value)
        elif name == "Rotation" and hasattr(obj, "rotation"):
            if hasattr(value, "X"):
                obj.rotation = [value.X, value.Y, value.Z]
            elif isinstance(value, (list, tuple)):
                obj.rotation = list(value)
        elif name == "Size" and hasattr(obj, "scale"):
            if hasattr(value, "X"):
                obj.scale = [value.X, value.Y, value.Z]
            elif isinstance(value, (list, tuple)):
                obj.scale = list(value)
        elif name == "Color" and hasattr(obj, "color"):
            if hasattr(value, "R"):
                obj.color = [value.R, value.G, value.B]
            elif isinstance(value, (list, tuple)):
                obj.color = list(value)
        elif name == "Transparency" and hasattr(obj, "transparency"):
            obj.transparency = float(value)
        elif name == "Anchored" and hasattr(obj, "anchored"):
            obj.anchored = bool(value)
        elif name == "CanCollide" and hasattr(obj, "can_collide"):
            obj.can_collide = bool(value)
        elif name == "Health" and hasattr(obj, "health"):
            obj.health = float(value)
        elif name == "MaxHealth" and hasattr(obj, "max_health"):
            obj.max_health = float(value)
        elif name == "WalkSpeed" and hasattr(obj, "walk_speed"):
            obj.walk_speed = float(value)
        elif name == "JumpPower" and hasattr(obj, "jump_power"):
            obj.jump_power = float(value)
        elif name == "Value" and hasattr(obj, "value"):
            obj.value = value
        elif hasattr(obj, name.lower()):
            setattr(obj, name.lower(), value)
        elif hasattr(obj, name):
            setattr(obj, name, value)

    def _find_first_child(self, name: str):
        """Find first child by name"""
        child = self._obj.find_first_child(name)
        if child:
            return LuaInstanceWrapper(child, self._runtime)
        return None

    def _get_children(self):
        """Get all children"""
        return [
            LuaInstanceWrapper(child, self._runtime) for child in self._obj.children
        ]

    def _destroy(self):
        """Destroy this instance"""
        obj = self._obj
        runtime = self._runtime
        if obj.name in runtime.objects:
            del runtime.objects[obj.name]
        if obj.object_id in runtime.objects_by_id:
            del runtime.objects_by_id[obj.object_id]
        if obj.parent_id:
            parent = runtime.objects_by_id.get(obj.parent_id)
            if parent:
                parent.remove_child(obj)

    def _clone(self):
        """Clone this instance"""
        cloned = self._obj.clone()
        self._runtime.objects[cloned.name] = cloned
        self._runtime.objects_by_id[cloned.object_id] = cloned
        return LuaInstanceWrapper(cloned, self._runtime)

    # Legacy methods
    def set_position(self, x: float, y: float, z: float):
        if hasattr(self._obj, "position"):
            self._obj.position = [float(x), float(y), float(z)]

    def set_rotation(self, rx: float, ry: float, rz: float):
        if hasattr(self._obj, "rotation"):
            self._obj.rotation = [float(rx), float(ry), float(rz)]

    def move(self, dx: float, dy: float, dz: float):
        if hasattr(self._obj, "position"):
            self._obj.position[0] += float(dx)
            self._obj.position[1] += float(dy)
            self._obj.position[2] += float(dz)

    def rotate(self, rx: float, ry: float, rz: float):
        if hasattr(self._obj, "rotation"):
            self._obj.rotation[0] += float(rx)
            self._obj.rotation[1] += float(ry)
            self._obj.rotation[2] += float(rz)

    def set_color(self, r: float, g: float, b: float):
        if hasattr(self._obj, "color"):
            self._obj.color = [float(r), float(g), float(b)]


class LuaTouchedSignal:
    """Lua wrapper for Touched event"""

    def __init__(self, part: BasePart, runtime: StudioLuaRuntime):
        self.part = part
        self.runtime = runtime

    def Connect(self, callback):
        """Connect a callback to the Touched event"""
        return self.runtime.register_touched_callback(self.part, callback)


class LuaSignal:
    """Generic Lua signal for events"""

    def __init__(self, name: str):
        self.name = name
        self.connections = []

    def Connect(self, callback):
        """Connect a callback"""
        self.connections.append(callback)
        return self

    def Fire(self, *args):
        """Fire the signal"""
        for callback in self.connections:
            try:
                callback(*args)
            except Exception as e:
                print(f"Signal {self.name} error: {e}")
