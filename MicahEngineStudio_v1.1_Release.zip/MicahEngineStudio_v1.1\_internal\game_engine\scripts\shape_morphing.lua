--[[
    Script 2: Shape Morphing Demo
    
    This script demonstrates:
    - Creating different primitive shapes
    - Dynamic scaling to morph between sizes
    - Pulsating animations
    - Color transitions over time
    - Orbital movement patterns
]]

-- Objects we'll create
local shapes = {}
local center_object = nil

-- Animation state
local morph_time = 0
local color_cycle = 0

-- Helper: Interpolate between two values
local function lerp(a, b, t)
    return a + (b - a) * t
end

-- Helper: Smooth step interpolation
local function smoothstep(t)
    return t * t * (3 - 2 * t)
end

-- Helper: HSV to RGB conversion
local function hsv_to_rgb(h, s, v)
    local i = math.floor(h * 6)
    local f = h * 6 - i
    local p = v * (1 - s)
    local q = v * (1 - f * s)
    local t = v * (1 - (1 - f) * s)
    
    i = i % 6
    if i == 0 then return v, t, p
    elseif i == 1 then return q, v, p
    elseif i == 2 then return p, v, t
    elseif i == 3 then return p, q, v
    elseif i == 4 then return t, p, v
    else return v, p, q
    end
end

-- Called when script starts
function on_start()
    print("=== Shape Morphing Demo Started ===")
    
    -- Create ground
    Engine.create_plane("MorphGround", 12.0, 12.0, 0.15, 0.2, 0.25)
    Engine.set_position("MorphGround", 0, -2, 0)
    
    -- Create center sphere (the "sun")
    center_object = Engine.create_sphere("CenterSphere", 0.6, 1.0, 0.9, 0.3)
    Engine.set_position("CenterSphere", 0, 0, 0)
    
    -- Create orbiting shapes
    local shape_configs = {
        {type = "cube", name = "OrbitCube", create_func = Engine.create_cube, 
         size = 0.5, orbit_radius = 3.0, orbit_speed = 1.0, height = 0},
        {type = "pyramid", name = "OrbitPyramid", create_func = Engine.create_pyramid,
         size = 0.6, orbit_radius = 2.2, orbit_speed = -1.5, height = 0.5},
        {type = "cylinder", name = "OrbitCylinder", create_func = Engine.create_cylinder,
         size = 0.3, orbit_radius = 4.0, orbit_speed = 0.7, height = -0.3},
        {type = "torus", name = "OrbitTorus", create_func = Engine.create_torus,
         size = 0.4, orbit_radius = 2.8, orbit_speed = -0.9, height = 0.8},
    }
    
    for i, config in ipairs(shape_configs) do
        -- Create shape with initial color
        local r, g, b = hsv_to_rgb(i / #shape_configs, 0.7, 0.9)
        
        if config.type == "cube" then
            Engine.create_cube(config.name, config.size, r, g, b)
        elseif config.type == "pyramid" then
            Engine.create_pyramid(config.name, config.size, config.size, r, g, b)
        elseif config.type == "cylinder" then
            Engine.create_cylinder(config.name, config.size, config.size * 2, r, g, b)
        elseif config.type == "torus" then
            Engine.create_torus(config.name, config.size, config.size * 0.3, r, g, b)
        end
        
        -- Store shape data
        shapes[i] = {
            name = config.name,
            orbit_radius = config.orbit_radius,
            orbit_speed = config.orbit_speed,
            base_height = config.height,
            angle = (i - 1) * (2 * PI / #shape_configs),  -- Spread evenly
            scale_phase = i * 0.7,
            color_offset = i / #shape_configs
        }
    end
    
    -- Camera setup
    Engine.set_camera_target(0, 0, 0)
    Engine.zoom_camera(-2)
    Engine.orbit_camera(30, 20)
    
    -- Lighting
    Engine.set_light_position(8, 12, 8)
    
    print("Created morphing shapes demo with " .. #shapes .. " orbiting objects")
end

-- Called every frame
function on_update(dt)
    morph_time = morph_time + dt
    color_cycle = color_cycle + dt * 0.2
    
    -- Animate center sphere (pulsating)
    local center_scale = 1.0 + math.sin(morph_time * 3) * 0.2
    Engine.set_scale("CenterSphere", center_scale, center_scale, center_scale)
    
    -- Update center color
    local cr, cg, cb = hsv_to_rgb((color_cycle * 0.5) % 1.0, 0.6, 1.0)
    Engine.set_color("CenterSphere", cr, cg, cb)
    
    -- Animate orbiting shapes
    for i, shape in ipairs(shapes) do
        -- Update orbit angle
        shape.angle = shape.angle + shape.orbit_speed * dt
        
        -- Calculate position on orbit
        local x = math.cos(shape.angle) * shape.orbit_radius
        local z = math.sin(shape.angle) * shape.orbit_radius
        local y = shape.base_height + math.sin(morph_time * 2 + shape.scale_phase) * 0.3
        
        Engine.set_position(shape.name, x, y, z)
        
        -- Rotation (each shape rotates differently)
        Engine.rotate(shape.name, 30 * dt, 45 * dt * (i % 2 == 0 and 1 or -1), 20 * dt)
        
        -- Scale morphing (breathing effect)
        local scale_factor = 1.0 + math.sin(morph_time * 1.5 + shape.scale_phase) * 0.3
        local stretch_x = scale_factor * (1.0 + math.sin(morph_time * 2.1) * 0.15)
        local stretch_y = scale_factor * (1.0 + math.cos(morph_time * 1.8) * 0.15)
        local stretch_z = scale_factor * (1.0 + math.sin(morph_time * 2.5) * 0.15)
        
        Engine.set_scale(shape.name, stretch_x, stretch_y, stretch_z)
        
        -- Color cycling
        local hue = (color_cycle + shape.color_offset) % 1.0
        local r, g, b = hsv_to_rgb(hue, 0.7, 0.95)
        Engine.set_color(shape.name, r, g, b)
    end
    
    -- Gentle camera orbit
    Engine.orbit_camera(5 * dt, 0)
end

print("Shape Morphing script loaded!")
