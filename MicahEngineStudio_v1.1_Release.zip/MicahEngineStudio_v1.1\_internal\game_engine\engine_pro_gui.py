"""
Enhanced 3D Game Engine GUI with Gizmo Tools, Lua IDE, and Robust Camera
"""

import sys
import os
import math
import random
import numpy as np
from enum import Enum
from PyQt5.QtWidgets import (
    QApplication,
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QTabWidget,
    QPushButton,
    QLabel,
    QSlider,
    QGroupBox,
    QListWidget,
    QSplitter,
    QFrame,
    QColorDialog,
    QDoubleSpinBox,
    QCheckBox,
    QListWidgetItem,
    QScrollArea,
    QGridLayout,
    QComboBox,
    QLineEdit,
    QToolBar,
    QAction,
    QStatusBar,
    QDockWidget,
    QSizePolicy,
    QTextEdit,
    QMenuBar,
    QMenu,
    QFileDialog,
    QMessageBox,
    QSpinBox,
)
from PyQt5.QtCore import Qt, QTimer, QSize, QRect, pyqtSignal, QObject
from PyQt5.QtGui import QColor, QIcon, QFont, QKeySequence
from PyQt5.QtOpenGL import QGLWidget
from PyQt5.Qsci import QsciScintilla, QsciLexerPython

from OpenGL.GL import *
from OpenGL.GLU import *
from pyrr import Matrix44, Vector3


class TransformMode(Enum):
    """Transform mode enumeration"""

    SELECT = "select"
    MOVE = "move"
    SCALE = "scale"
    ROTATE = "rotate"


class GameObject3D:
    """Simple 3D object for the scene"""

    _id_counter = 0

    def __init__(self, name, shape_type="cube"):
        GameObject3D._id_counter += 1
        self.id = GameObject3D._id_counter
        self.name = name
        self.shape_type = shape_type
        self.position = [0.0, 0.0, 0.0]
        self.rotation = [0.0, 0.0, 0.0]
        self.scale = [1.0, 1.0, 1.0]
        self.color = [1.0, 1.0, 1.0]
        self.visible = True
        self.animation_speed = [0.0, 0.0, 0.0]
        self.selected = False


class LuaCodeEditor(QsciScintilla):
    """Lua code editor with syntax highlighting"""

    play_triggered = pyqtSignal(str)
    stop_triggered = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)

        # Use Python lexer (similar enough for Lua)
        lexer = QsciLexerPython()
        lexer.setDefaultFont(QFont("Courier", 10))
        self.setLexer(lexer)

        # Editor settings
        self.setMarginType(0, QsciScintilla.NumberMargin)
        self.setMarginWidth(0, "000")
        self.setBraceMatching(QsciScintilla.SloppyBraceMatch)
        self.setAutoIndent(True)
        self.setIndentationsUseTabs(False)
        self.setIndentationWidth(2)
        self.setTabWidth(2)

        # Load default script
        self.load_default_script()

    def load_default_script(self):
        """Load a default Lua script"""
        default_script = """-- Lua Script Editor
-- Write your MEPLUA code here
-- Press Play to execute

function on_start()
    print("Script started!")
end

function on_update(dt)
    -- Update logic here
end

function on_render()
    -- Render logic here
end
"""
        self.setText(default_script)

    def get_code(self):
        """Get the current code"""
        return self.text()

    def set_code(self, code):
        """Set the code"""
        self.setText(code)


class OpenGLWidget(QGLWidget):
    """Enhanced OpenGL viewport with gizmo tools and camera controls"""

    object_selected = pyqtSignal(object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(400, 300)
        self.setFocusPolicy(Qt.StrongFocus)

        # Camera
        self.camera_distance = 10.0
        self.camera_yaw = 30.0
        self.camera_pitch = 25.0
        self.camera_target = [0.0, 0.0, 0.0]
        self.camera_velocity = [0.0, 0.0, 0.0]

        # Mouse
        self.last_mouse_x = 0
        self.last_mouse_y = 0
        self.mouse_dragging = False
        self.left_mouse_dragging = False
        self.middle_mouse_dragging = False

        # Keyboard
        self.keys_pressed = set()  # Scene
        self.objects = []
        self.show_grid = True
        self.show_axes = True
        self.selected_object = None
        self.transform_mode = TransformMode.SELECT
        self.gizmo_axis = None  # 'x', 'y', or 'z'

        # Animation
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.animate)
        self.timer.start(16)  # ~60 FPS

        # Create demo scene
        self.create_demo_scene()

    def create_demo_scene(self):
        """Create initial demo objects"""
        colors = [
            [1.0, 0.3, 0.3],
            [0.3, 1.0, 0.3],
            [0.3, 0.3, 1.0],
            [1.0, 1.0, 0.3],
            [1.0, 0.3, 1.0],
            [0.3, 1.0, 1.0],
            [1.0, 0.6, 0.2],
            [0.6, 0.2, 1.0],
            [0.2, 0.8, 0.6],
        ]

        idx = 0
        for row in range(3):
            for col in range(3):
                obj = GameObject3D(f"Cube_{idx+1}", "cube")
                obj.position = [(col - 1) * 2.5, 0.0, (row - 1) * 2.5]
                obj.color = colors[idx]
                obj.scale = [0.8, 0.8, 0.8]
                obj.animation_speed = [
                    random.uniform(20, 60),
                    random.uniform(20, 60),
                    random.uniform(20, 60),
                ]
                self.objects.append(obj)
                idx += 1

    def initializeGL(self):
        """Initialize OpenGL"""
        glClearColor(0.15, 0.15, 0.2, 1.0)
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_LIGHTING)
        glEnable(GL_LIGHT0)
        glEnable(GL_COLOR_MATERIAL)
        glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE)

        glLightfv(GL_LIGHT0, GL_POSITION, [5.0, 10.0, 5.0, 1.0])
        glLightfv(GL_LIGHT0, GL_AMBIENT, [0.3, 0.3, 0.3, 1.0])
        glLightfv(GL_LIGHT0, GL_DIFFUSE, [0.8, 0.8, 0.8, 1.0])

    def resizeGL(self, width, height):
        """Handle resize"""
        glViewport(0, 0, width, height)
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        aspect = width / height if height > 0 else 1.0
        gluPerspective(60.0, aspect, 0.1, 1000.0)
        glMatrixMode(GL_MODELVIEW)

    def paintGL(self):
        """Render the scene"""
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glLoadIdentity()

        # Update camera position
        cam_x = self.camera_target[0] + self.camera_distance * math.cos(
            math.radians(self.camera_pitch)
        ) * math.sin(math.radians(self.camera_yaw))
        cam_y = self.camera_target[1] + self.camera_distance * math.sin(
            math.radians(self.camera_pitch)
        )
        cam_z = self.camera_target[2] + self.camera_distance * math.cos(
            math.radians(self.camera_pitch)
        ) * math.cos(math.radians(self.camera_yaw))

        gluLookAt(
            cam_x,
            cam_y,
            cam_z,
            self.camera_target[0],
            self.camera_target[1],
            self.camera_target[2],
            0,
            1,
            0,
        )

        # Draw grid
        if self.show_grid:
            self.draw_grid()

        # Draw axes
        if self.show_axes:
            self.draw_axes()

        # Draw gizmo for selected object
        if self.selected_object and self.transform_mode != TransformMode.SELECT:
            self.draw_transform_gizmo()

        # Draw objects
        glEnable(GL_LIGHTING)
        for obj in self.objects:
            if obj.visible:
                self.draw_object(obj)

    def draw_grid(self):
        """Draw grid on XZ plane"""
        glDisable(GL_LIGHTING)
        glBegin(GL_LINES)

        grid_size = 10
        for i in range(-grid_size, grid_size + 1):
            if i == 0:
                glColor3f(0.5, 0.5, 0.5)
            else:
                glColor3f(0.3, 0.3, 0.3)

            glVertex3f(i, 0, -grid_size)
            glVertex3f(i, 0, grid_size)
            glVertex3f(-grid_size, 0, i)
            glVertex3f(grid_size, 0, i)

        glEnd()
        glEnable(GL_LIGHTING)

    def draw_axes(self):
        """Draw XYZ axes"""
        glDisable(GL_LIGHTING)
        glLineWidth(2.0)
        glBegin(GL_LINES)

        glColor3f(1.0, 0.0, 0.0)
        glVertex3f(0, 0, 0)
        glVertex3f(2, 0, 0)

        glColor3f(0.0, 1.0, 0.0)
        glVertex3f(0, 0, 0)
        glVertex3f(0, 2, 0)

        glColor3f(0.0, 0.0, 1.0)
        glVertex3f(0, 0, 0)
        glVertex3f(0, 0, 2)

        glEnd()
        glLineWidth(1.0)
        glEnable(GL_LIGHTING)

    def draw_transform_gizmo(self):
        """Draw transformation gizmo for selected object"""
        if not self.selected_object:
            return

        glDisable(GL_LIGHTING)
        glPushMatrix()
        glTranslatef(*self.selected_object.position)

        size = 1.5
        glLineWidth(3.0)
        glBegin(GL_LINES)

        # X axis - Red
        glColor3f(1.0, 0.2, 0.2) if self.gizmo_axis != "x" else glColor3f(1.0, 1.0, 0.0)
        glVertex3f(0, 0, 0)
        glVertex3f(size, 0, 0)

        # Y axis - Green
        glColor3f(0.2, 1.0, 0.2) if self.gizmo_axis != "y" else glColor3f(1.0, 1.0, 0.0)
        glVertex3f(0, 0, 0)
        glVertex3f(0, size, 0)

        # Z axis - Blue
        glColor3f(0.2, 0.2, 1.0) if self.gizmo_axis != "z" else glColor3f(1.0, 1.0, 0.0)
        glVertex3f(0, 0, 0)
        glVertex3f(0, 0, size)

        glEnd()
        glLineWidth(1.0)
        glPopMatrix()
        glEnable(GL_LIGHTING)

    def draw_object(self, obj):
        """Draw a 3D object"""
        glPushMatrix()

        glTranslatef(*obj.position)
        glRotatef(obj.rotation[0], 1, 0, 0)
        glRotatef(obj.rotation[1], 0, 1, 0)
        glRotatef(obj.rotation[2], 0, 0, 1)
        glScalef(*obj.scale)

        glColor3f(*obj.color)

        if obj.shape_type == "cube":
            self.draw_cube()
        elif obj.shape_type == "sphere":
            self.draw_sphere()
        elif obj.shape_type == "cylinder":
            self.draw_cylinder()
        elif obj.shape_type == "pyramid":
            self.draw_pyramid()
        elif obj.shape_type == "plane":
            self.draw_plane()
        elif obj.shape_type == "torus":
            self.draw_torus()

        # Selection outline
        if obj == self.selected_object:
            glDisable(GL_LIGHTING)
            glColor3f(1.0, 1.0, 0.0)
            glLineWidth(2.0)
            self.draw_cube_wireframe()
            glLineWidth(1.0)
            glEnable(GL_LIGHTING)

        glPopMatrix()

    def draw_cube(self):
        """Draw a unit cube"""
        vertices = [
            [-0.5, -0.5, -0.5],
            [0.5, -0.5, -0.5],
            [0.5, 0.5, -0.5],
            [-0.5, 0.5, -0.5],
            [-0.5, -0.5, 0.5],
            [0.5, -0.5, 0.5],
            [0.5, 0.5, 0.5],
            [-0.5, 0.5, 0.5],
        ]
        faces = [
            (0, 1, 2, 3),
            (4, 7, 6, 5),
            (0, 4, 5, 1),
            (2, 6, 7, 3),
            (0, 3, 7, 4),
            (1, 5, 6, 2),
        ]
        normals = [(0, 0, -1), (0, 0, 1), (0, -1, 0), (0, 1, 0), (-1, 0, 0), (1, 0, 0)]

        glBegin(GL_QUADS)
        for i, face in enumerate(faces):
            glNormal3f(*normals[i])
            for vertex in face:
                glVertex3f(*vertices[vertex])
        glEnd()

    def draw_cube_wireframe(self):
        """Draw wireframe cube for selection"""
        s = 0.55
        glBegin(GL_LINE_LOOP)
        glVertex3f(-s, -s, -s)
        glVertex3f(s, -s, -s)
        glVertex3f(s, s, -s)
        glVertex3f(-s, s, -s)
        glEnd()
        glBegin(GL_LINE_LOOP)
        glVertex3f(-s, -s, s)
        glVertex3f(s, -s, s)
        glVertex3f(s, s, s)
        glVertex3f(-s, s, s)
        glEnd()
        glBegin(GL_LINES)
        glVertex3f(-s, -s, -s)
        glVertex3f(-s, -s, s)
        glVertex3f(s, -s, -s)
        glVertex3f(s, -s, s)
        glVertex3f(s, s, -s)
        glVertex3f(s, s, s)
        glVertex3f(-s, s, -s)
        glVertex3f(-s, s, s)
        glEnd()

    def draw_sphere(self):
        """Draw a sphere"""
        quad = gluNewQuadric()
        gluSphere(quad, 0.5, 20, 20)

    def draw_cylinder(self):
        """Draw a cylinder"""
        quad = gluNewQuadric()
        glTranslatef(0, -0.5, 0)
        glRotatef(-90, 1, 0, 0)
        gluCylinder(quad, 0.4, 0.4, 1.0, 20, 1)

    def draw_pyramid(self):
        """Draw a pyramid"""
        glBegin(GL_TRIANGLES)
        glNormal3f(0, 0.5, 0.5)
        glVertex3f(0, 0.5, 0)
        glVertex3f(-0.5, -0.5, 0.5)
        glVertex3f(0.5, -0.5, 0.5)
        glNormal3f(0.5, 0.5, 0)
        glVertex3f(0, 0.5, 0)
        glVertex3f(0.5, -0.5, 0.5)
        glVertex3f(0.5, -0.5, -0.5)
        glNormal3f(0, 0.5, -0.5)
        glVertex3f(0, 0.5, 0)
        glVertex3f(0.5, -0.5, -0.5)
        glVertex3f(-0.5, -0.5, -0.5)
        glNormal3f(-0.5, 0.5, 0)
        glVertex3f(0, 0.5, 0)
        glVertex3f(-0.5, -0.5, -0.5)
        glVertex3f(-0.5, -0.5, 0.5)
        glEnd()
        glBegin(GL_QUADS)
        glNormal3f(0, -1, 0)
        glVertex3f(-0.5, -0.5, 0.5)
        glVertex3f(-0.5, -0.5, -0.5)
        glVertex3f(0.5, -0.5, -0.5)
        glVertex3f(0.5, -0.5, 0.5)
        glEnd()

    def draw_plane(self):
        """Draw a flat plane"""
        glBegin(GL_QUADS)
        glNormal3f(0, 1, 0)
        glVertex3f(-1, 0, -1)
        glVertex3f(-1, 0, 1)
        glVertex3f(1, 0, 1)
        glVertex3f(1, 0, -1)
        glEnd()

    def draw_torus(self):
        """Draw a torus"""
        from math import sin, cos, pi

        R, r = 0.4, 0.15
        sides, rings = 20, 20

        glBegin(GL_QUADS)
        for i in range(rings):
            theta1 = 2 * pi * i / rings
            theta2 = 2 * pi * (i + 1) / rings

            for j in range(sides):
                phi1 = 2 * pi * j / sides
                phi2 = 2 * pi * (j + 1) / sides

                def vertex(theta, phi):
                    x = (R + r * cos(phi)) * cos(theta)
                    y = r * sin(phi)
                    z = (R + r * cos(phi)) * sin(theta)
                    nx = cos(phi) * cos(theta)
                    ny = sin(phi)
                    nz = cos(phi) * sin(theta)
                    glNormal3f(nx, ny, nz)
                    glVertex3f(x, y, z)

                vertex(theta1, phi1)
                vertex(theta2, phi1)
                vertex(theta2, phi2)
                vertex(theta1, phi2)
        glEnd()

    def animate(self):
        """Animation update"""
        dt = 0.016

        # Update camera from keyboard (corrected directions)
        speed = 0.1
        # Calculate forward/right vectors based on camera yaw
        yaw_rad = math.radians(self.camera_yaw)
        forward_x = math.sin(yaw_rad)
        forward_z = math.cos(yaw_rad)
        right_x = math.cos(yaw_rad)
        right_z = -math.sin(yaw_rad)

        if Qt.Key_W in self.keys_pressed:  # Forward
            self.camera_target[0] -= forward_x * speed
            self.camera_target[2] -= forward_z * speed
        if Qt.Key_S in self.keys_pressed:  # Backward
            self.camera_target[0] += forward_x * speed
            self.camera_target[2] += forward_z * speed
        if Qt.Key_A in self.keys_pressed:  # Left
            self.camera_target[0] -= right_x * speed
            self.camera_target[2] -= right_z * speed
        if Qt.Key_D in self.keys_pressed:  # Right
            self.camera_target[0] += right_x * speed
            self.camera_target[2] += right_z * speed
        if Qt.Key_E in self.keys_pressed:  # Up
            self.camera_target[1] += speed
        if Qt.Key_Q in self.keys_pressed:  # Down
            self.camera_target[1] -= speed

        for obj in self.objects:
            obj.rotation[0] += obj.animation_speed[0] * dt
            obj.rotation[1] += obj.animation_speed[1] * dt
            obj.rotation[2] += obj.animation_speed[2] * dt
        self.update()

    def mousePressEvent(self, event):
        self.last_mouse_x = event.x()
        self.last_mouse_y = event.y()

        if event.button() == Qt.LeftButton:
            # Check if clicking on gizmo axis first
            if self.selected_object and self.transform_mode != TransformMode.SELECT:
                axis = self.check_gizmo_hit(event.x(), event.y())
                if axis:
                    self.gizmo_axis = axis
                    self.left_mouse_dragging = True
                    print(f"Gizmo axis selected: {axis.upper()}")
                else:
                    self.gizmo_axis = None
                    self.select_object(event.x(), event.y())
            else:
                self.select_object(event.x(), event.y())
        elif event.button() == Qt.MiddleButton:
            self.middle_mouse_dragging = True
        elif event.button() == Qt.RightButton:
            self.mouse_dragging = True

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.left_mouse_dragging = False
            if self.gizmo_axis:
                print(f"Released gizmo axis: {self.gizmo_axis.upper()}")
            self.gizmo_axis = None
        elif event.button() == Qt.MiddleButton:
            self.middle_mouse_dragging = False
        elif event.button() == Qt.RightButton:
            self.mouse_dragging = False

    def check_gizmo_hit(self, mouse_x, mouse_y):
        """Check if mouse is near a gizmo axis and return which axis"""
        if not self.selected_object:
            return None

        # Get viewport dimensions and matrices
        try:
            modelview = glGetDoublev(GL_MODELVIEW_MATRIX)
            projection = glGetDoublev(GL_PROJECTION_MATRIX)
            viewport = glGetIntegerv(GL_VIEWPORT)

            obj_pos = self.selected_object.position

            # Project object center to screen
            screen_pos = gluProject(
                obj_pos[0], obj_pos[1], obj_pos[2], modelview, projection, viewport
            )
            obj_screen_x, obj_screen_y = screen_pos[0], viewport[3] - screen_pos[1]

            # Project gizmo endpoints
            gizmo_size = 1.5
            x_end = gluProject(
                obj_pos[0] + gizmo_size,
                obj_pos[1],
                obj_pos[2],
                modelview,
                projection,
                viewport,
            )
            y_end = gluProject(
                obj_pos[0],
                obj_pos[1] + gizmo_size,
                obj_pos[2],
                modelview,
                projection,
                viewport,
            )
            z_end = gluProject(
                obj_pos[0],
                obj_pos[1],
                obj_pos[2] + gizmo_size,
                modelview,
                projection,
                viewport,
            )

            x_screen_x, x_screen_y = x_end[0], viewport[3] - x_end[1]
            y_screen_x, y_screen_y = y_end[0], viewport[3] - y_end[1]
            z_screen_x, z_screen_y = z_end[0], viewport[3] - z_end[1]

            # Check distance to each axis line
            threshold = 15  # pixels

            # Calculate distance to each axis
            dist_x = self.point_to_line_distance(
                mouse_x, mouse_y, obj_screen_x, obj_screen_y, x_screen_x, x_screen_y
            )
            dist_y = self.point_to_line_distance(
                mouse_x, mouse_y, obj_screen_x, obj_screen_y, y_screen_x, y_screen_y
            )
            dist_z = self.point_to_line_distance(
                mouse_x, mouse_y, obj_screen_x, obj_screen_y, z_screen_x, z_screen_y
            )

            # Return closest axis if within threshold
            min_dist = min(dist_x, dist_y, dist_z)
            if min_dist < threshold:
                if min_dist == dist_x:
                    return "x"
                elif min_dist == dist_y:
                    return "y"
                else:
                    return "z"

        except Exception as e:
            pass

        return None

    def point_to_line_distance(self, px, py, x1, y1, x2, y2):
        """Calculate distance from point to line segment"""
        dx = x2 - x1
        dy = y2 - y1
        if dx == 0 and dy == 0:
            return math.sqrt((px - x1) ** 2 + (py - y1) ** 2)

        t = max(0, min(1, ((px - x1) * dx + (py - y1) * dy) / (dx * dx + dy * dy)))
        proj_x = x1 + t * dx
        proj_y = y1 + t * dy

        return math.sqrt((px - proj_x) ** 2 + (py - proj_y) ** 2)

    def mouseMoveEvent(self, event):
        dx = event.x() - self.last_mouse_x
        dy = event.y() - self.last_mouse_y

        if self.mouse_dragging:  # Right-click drag for camera rotation
            self.camera_yaw += dx * 0.5
            self.camera_pitch = max(-89, min(89, self.camera_pitch + dy * 0.5))

        elif self.middle_mouse_dragging:  # Middle-click drag for camera panning
            pan_speed = 0.02
            # Calculate camera right and up vectors
            yaw_rad = math.radians(self.camera_yaw)
            right_x = math.cos(yaw_rad)
            right_z = -math.sin(yaw_rad)

            # Pan horizontally (right/left)
            self.camera_target[0] -= right_x * dx * pan_speed
            self.camera_target[2] -= right_z * dx * pan_speed

            # Pan vertically (up/down)
            self.camera_target[1] += dy * pan_speed

        elif self.left_mouse_dragging and self.selected_object and self.gizmo_axis:
            # Transform gizmo interaction with left-click drag
            sensitivity = 0.05  # Increased sensitivity for better response
            if self.gizmo_axis == "x":
                if self.transform_mode == TransformMode.MOVE:
                    self.selected_object.position[0] += dx * sensitivity
                elif self.transform_mode == TransformMode.SCALE:
                    new_scale = max(
                        0.1, self.selected_object.scale[0] + dx * sensitivity * 0.5
                    )
                    self.selected_object.scale[0] = new_scale
            elif self.gizmo_axis == "y":
                if self.transform_mode == TransformMode.MOVE:
                    self.selected_object.position[1] -= dy * sensitivity
                elif self.transform_mode == TransformMode.SCALE:
                    new_scale = max(
                        0.1, self.selected_object.scale[1] - dy * sensitivity * 0.5
                    )
                    self.selected_object.scale[1] = new_scale
            elif self.gizmo_axis == "z":
                if self.transform_mode == TransformMode.MOVE:
                    self.selected_object.position[2] += (
                        dy * sensitivity
                    )  # Fixed: removed negative
                elif self.transform_mode == TransformMode.SCALE:
                    new_scale = max(
                        0.1,
                        self.selected_object.scale[2]
                        + dy * sensitivity * 0.5,  # Fixed: removed negative
                    )
                    self.selected_object.scale[2] = new_scale

        self.last_mouse_x = event.x()
        self.last_mouse_y = event.y()

    def wheelEvent(self, event):
        delta = event.angleDelta().y() / 120.0
        self.camera_distance = max(2.0, min(50.0, self.camera_distance - delta))

    def keyPressEvent(self, event):
        if not event.isAutoRepeat():
            self.keys_pressed.add(event.key())

    def keyReleaseEvent(self, event):
        if not event.isAutoRepeat():
            self.keys_pressed.discard(event.key())

    def select_object(self, x, y):
        """Select object by clicking with better hit detection"""
        # Get matrices for unprojection
        try:
            modelview = glGetDoublev(GL_MODELVIEW_MATRIX)
            projection = glGetDoublev(GL_PROJECTION_MATRIX)
            viewport = glGetIntegerv(GL_VIEWPORT)

            # Unproject mouse position to world coordinates
            win_y = viewport[3] - y
            near_point = gluUnProject(x, win_y, 0.0, modelview, projection, viewport)
            far_point = gluUnProject(x, win_y, 1.0, modelview, projection, viewport)

            # Create ray
            ray_dir = [
                far_point[0] - near_point[0],
                far_point[1] - near_point[1],
                far_point[2] - near_point[2],
            ]

            # Normalize ray
            ray_length = math.sqrt(ray_dir[0] ** 2 + ray_dir[1] ** 2 + ray_dir[2] ** 2)
            ray_dir = [d / ray_length for d in ray_dir]

            # Find closest object to ray
            closest_obj = None
            closest_dist = float("inf")

            for obj in self.objects:
                if not obj.visible:
                    continue

                # Simple sphere collision (approximate)
                obj_pos = obj.position
                to_obj = [
                    obj_pos[0] - near_point[0],
                    obj_pos[1] - near_point[1],
                    obj_pos[2] - near_point[2],
                ]

                # Project onto ray
                dot = sum(to_obj[i] * ray_dir[i] for i in range(3))
                if dot < 0:
                    continue

                # Point on ray closest to object
                closest_point = [
                    near_point[0] + ray_dir[0] * dot,
                    near_point[1] + ray_dir[1] * dot,
                    near_point[2] + ray_dir[2] * dot,
                ]

                # Distance from object to ray
                dist = math.sqrt(
                    (obj_pos[0] - closest_point[0]) ** 2
                    + (obj_pos[1] - closest_point[1]) ** 2
                    + (obj_pos[2] - closest_point[2]) ** 2
                )

                # Check if hit (within object bounds)
                max_scale = max(obj.scale)
                if dist < max_scale and dot < closest_dist:
                    closest_obj = obj
                    closest_dist = dot

            if closest_obj:
                self.selected_object = closest_obj
                self.object_selected.emit(closest_obj)
                print(f"Selected: {closest_obj.name}")
            else:
                self.selected_object = None
                print("Selection cleared")

        except Exception as e:
            print(f"Selection error: {e}")
            # Fallback to first object
            if self.objects:
                self.selected_object = self.objects[0]
                self.object_selected.emit(self.objects[0])

    def add_object(self, shape_type, name=None):
        """Add a new object to the scene"""
        if name is None:
            name = f"{shape_type.title()}_{len(self.objects)+1}"

        obj = GameObject3D(name, shape_type)
        obj.position = [random.uniform(-3, 3), 0.5, random.uniform(-3, 3)]
        obj.color = [random.random(), random.random(), random.random()]
        obj.animation_speed = [
            random.uniform(0, 30),
            random.uniform(0, 30),
            random.uniform(0, 30),
        ]
        self.objects.append(obj)
        return obj


class EnhancedMainWindow(QMainWindow):
    """Enhanced main application window"""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("3D Game Engine Pro - Lua Scripted")
        self.setGeometry(100, 100, 1600, 1000)

        # Create central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        main_layout = QHBoxLayout(central_widget)
        main_layout.setContentsMargins(5, 5, 5, 5)
        main_layout.setSpacing(5)

        # Left panel - Scene hierarchy
        left_panel = self.create_hierarchy_panel()

        # Center - OpenGL viewport
        self.gl_widget = OpenGLWidget()
        self.gl_widget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.gl_widget.object_selected.connect(self.on_object_selected)

        # Right panel - Properties and tools
        right_panel = self.create_properties_panel()

        # Add layouts
        left_splitter = QSplitter(Qt.Vertical)
        left_splitter.addWidget(left_panel)
        left_splitter.setSizes([300, 400])

        right_splitter = QSplitter(Qt.Vertical)
        right_splitter.addWidget(right_panel)
        right_splitter.setSizes([300, 400])

        main_layout.addWidget(left_splitter, 1)
        main_layout.addWidget(self.gl_widget, 3)
        main_layout.addWidget(right_splitter, 1)

        # Menu bar
        self.create_menu_bar()

        # Toolbar
        self.create_toolbar()

        # Status bar
        self.statusBar().showMessage(
            "WASD/EQ: Move | Left: Select/Drag Gizmo | Middle: Pan | Right: Rotate | Scroll: Zoom"
        )

        # UI update timer
        self.ui_timer = QTimer(self)
        self.ui_timer.timeout.connect(self.update_ui)
        self.ui_timer.start(100)

    def create_hierarchy_panel(self):
        """Create scene hierarchy panel"""
        panel = QFrame()
        panel.setFrameStyle(QFrame.StyledPanel)
        panel.setMaximumWidth(280)
        layout = QVBoxLayout(panel)

        layout.addWidget(QLabel("📋 Scene Hierarchy"))

        self.object_list = QListWidget()
        self.object_list.itemClicked.connect(self.on_list_object_selected)
        layout.addWidget(self.object_list)

        # Object creation buttons
        create_group = QGroupBox("Create Object")
        create_layout = QGridLayout(create_group)

        shapes = [
            ("Cube", "cube"),
            ("Sphere", "sphere"),
            ("Cylinder", "cylinder"),
            ("Pyramid", "pyramid"),
            ("Plane", "plane"),
            ("Torus", "torus"),
        ]

        for i, (label, shape) in enumerate(shapes):
            btn = QPushButton(f"➕ {label}")
            btn.clicked.connect(lambda checked, s=shape: self.create_object(s))
            create_layout.addWidget(btn, i // 3, i % 3)

        layout.addWidget(create_group)

        # Delete button
        delete_btn = QPushButton("🗑️ Delete Selected")
        delete_btn.clicked.connect(self.delete_selected)
        layout.addWidget(delete_btn)

        return panel

    def create_properties_panel(self):
        """Create properties panel with tabs"""
        panel = QFrame()
        panel.setFrameStyle(QFrame.StyledPanel)
        panel.setMaximumWidth(300)
        layout = QVBoxLayout(panel)

        tabs = QTabWidget()

        # Transform tab
        transform_tab = QWidget()
        transform_layout = QGridLayout(transform_tab)

        transform_layout.addWidget(QLabel("Position"), 0, 0)
        self.pos_x = QDoubleSpinBox()
        self.pos_x.setRange(-100, 100)
        self.pos_x.valueChanged.connect(self.update_transform)
        self.pos_y = QDoubleSpinBox()
        self.pos_y.setRange(-100, 100)
        self.pos_y.valueChanged.connect(self.update_transform)
        self.pos_z = QDoubleSpinBox()
        self.pos_z.setRange(-100, 100)
        self.pos_z.valueChanged.connect(self.update_transform)
        transform_layout.addWidget(self.pos_x, 0, 1)
        transform_layout.addWidget(self.pos_y, 0, 2)
        transform_layout.addWidget(self.pos_z, 0, 3)

        transform_layout.addWidget(QLabel("Rotation"), 1, 0)
        self.rot_x = QDoubleSpinBox()
        self.rot_x.setRange(-360, 360)
        self.rot_x.valueChanged.connect(self.update_transform)
        self.rot_y = QDoubleSpinBox()
        self.rot_y.setRange(-360, 360)
        self.rot_y.valueChanged.connect(self.update_transform)
        self.rot_z = QDoubleSpinBox()
        self.rot_z.setRange(-360, 360)
        self.rot_z.valueChanged.connect(self.update_transform)
        transform_layout.addWidget(self.rot_x, 1, 1)
        transform_layout.addWidget(self.rot_y, 1, 2)
        transform_layout.addWidget(self.rot_z, 1, 3)

        transform_layout.addWidget(QLabel("Scale"), 2, 0)
        self.scale_x = QDoubleSpinBox()
        self.scale_x.setRange(0.1, 10)
        self.scale_x.setValue(1)
        self.scale_x.setSingleStep(0.1)
        self.scale_x.valueChanged.connect(self.update_transform)
        self.scale_y = QDoubleSpinBox()
        self.scale_y.setRange(0.1, 10)
        self.scale_y.setValue(1)
        self.scale_y.setSingleStep(0.1)
        self.scale_y.valueChanged.connect(self.update_transform)
        self.scale_z = QDoubleSpinBox()
        self.scale_z.setRange(0.1, 10)
        self.scale_z.setValue(1)
        self.scale_z.setSingleStep(0.1)
        self.scale_z.valueChanged.connect(self.update_transform)
        transform_layout.addWidget(self.scale_x, 2, 1)
        transform_layout.addWidget(self.scale_y, 2, 2)
        transform_layout.addWidget(self.scale_z, 2, 3)

        # Transform mode buttons
        mode_group = QGroupBox("Transform Mode")
        mode_layout = QHBoxLayout(mode_group)
        for mode_name, mode_value in [
            ("Select", TransformMode.SELECT),
            ("Move", TransformMode.MOVE),
            ("Scale", TransformMode.SCALE),
        ]:
            btn = QPushButton(mode_name)
            btn.clicked.connect(
                lambda checked, m=mode_value: self.set_transform_mode(m)
            )
            mode_layout.addWidget(btn)
        transform_layout.addWidget(mode_group, 3, 0, 1, 4)

        transform_layout.setRowStretch(4, 1)
        tabs.addTab(transform_tab, "🎯 Transform")

        # Lua IDE tab
        lua_tab = QWidget()
        lua_layout = QVBoxLayout(lua_tab)

        # Top control buttons
        control_layout = QHBoxLayout()
        self.play_btn = QPushButton("▶️ Play")
        self.stop_btn = QPushButton("⏹️ Stop")
        self.save_script_btn = QPushButton("💾 Save")
        self.load_script_btn = QPushButton("📂 Load")
        self.clear_console = QPushButton("🗑️ Clear")

        self.play_btn.clicked.connect(self.run_script)
        self.stop_btn.clicked.connect(self.stop_script)
        self.save_script_btn.clicked.connect(self.save_script)
        self.load_script_btn.clicked.connect(self.load_script)
        self.clear_console.clicked.connect(self.clear_console_output)

        control_layout.addWidget(self.play_btn)
        control_layout.addWidget(self.stop_btn)
        control_layout.addWidget(self.save_script_btn)
        control_layout.addWidget(self.load_script_btn)
        control_layout.addWidget(self.clear_console)
        lua_layout.addLayout(control_layout)

        # Script info/status bar
        status_layout = QHBoxLayout()
        self.script_status = QLabel("Status: Ready")
        self.script_status.setStyleSheet("color: #00ff00;")
        self.line_col_label = QLabel("Line: 1, Col: 1")
        status_layout.addWidget(self.script_status)
        status_layout.addStretch()
        status_layout.addWidget(self.line_col_label)
        lua_layout.addLayout(status_layout)

        # Code editor with label
        lua_layout.addWidget(QLabel("MEPLUA Script Editor:"))
        self.code_editor = LuaCodeEditor()
        self.code_editor.cursorPositionChanged.connect(self.update_cursor_position)
        lua_layout.addWidget(self.code_editor, 2)

        # Quick insert buttons
        quick_layout = QHBoxLayout()
        quick_label = QLabel("Quick Insert:")
        quick_layout.addWidget(quick_label)

        quick_inserts = [
            ("Function", "function name()\n    \nend"),
            ("If", "if condition then\n    \nend"),
            ("For", "for i=1,10 do\n    \nend"),
            ("Print", "print()"),
        ]

        for label, code in quick_inserts:
            btn = QPushButton(label)
            btn.clicked.connect(lambda checked, c=code: self.insert_code_snippet(c))
            quick_layout.addWidget(btn)

        quick_layout.addStretch()
        lua_layout.addLayout(quick_layout)

        # Console output
        console_label_layout = QHBoxLayout()
        console_label_layout.addWidget(QLabel("Console Output:"))
        self.console_lines_label = QLabel("Lines: 0")
        console_label_layout.addStretch()
        console_label_layout.addWidget(self.console_lines_label)
        lua_layout.addLayout(console_label_layout)

        self.console_output = QTextEdit()
        self.console_output.setReadOnly(True)
        self.console_output.setMaximumHeight(120)
        self.console_output.setStyleSheet(
            "background-color: #1e1e1e; color: #00ff00; font-family: Consolas, monospace;"
        )
        lua_layout.addWidget(self.console_output, 1)

        tabs.addTab(lua_tab, "🐍 MEPLUA IDE")

        # View tab
        view_tab = QWidget()
        view_layout = QVBoxLayout(view_tab)

        self.grid_check = QCheckBox("Show Grid")
        self.grid_check.setChecked(True)
        self.grid_check.stateChanged.connect(
            lambda s: setattr(self.gl_widget, "show_grid", s == Qt.Checked)
        )
        view_layout.addWidget(self.grid_check)

        self.axes_check = QCheckBox("Show Axes")
        self.axes_check.setChecked(True)
        self.axes_check.stateChanged.connect(
            lambda s: setattr(self.gl_widget, "show_axes", s == Qt.Checked)
        )
        view_layout.addWidget(self.axes_check)

        view_layout.addWidget(QLabel("Camera Distance"))
        self.dist_slider = QSlider(Qt.Horizontal)
        self.dist_slider.setRange(20, 500)
        self.dist_slider.setValue(100)
        self.dist_slider.valueChanged.connect(
            lambda v: setattr(self.gl_widget, "camera_distance", v / 10.0)
        )
        view_layout.addWidget(self.dist_slider)

        reset_cam_btn = QPushButton("Reset Camera")
        reset_cam_btn.clicked.connect(self.reset_camera)
        view_layout.addWidget(reset_cam_btn)

        view_layout.addStretch()
        tabs.addTab(view_tab, "👁️ View")

        layout.addWidget(tabs)
        return panel

    def create_menu_bar(self):
        """Create menu bar"""
        menubar = self.menuBar()

        # File menu
        file_menu = menubar.addMenu("File")
        file_menu.addAction("New Scene", self.new_scene)
        file_menu.addAction("Open Scene...", self.open_scene)
        file_menu.addAction("Save Scene...", self.save_scene)
        file_menu.addSeparator()
        file_menu.addAction("Exit", self.close)

        # Edit menu
        edit_menu = menubar.addMenu("Edit")
        edit_menu.addAction("Undo")
        edit_menu.addAction("Redo")

        # View menu
        view_menu = menubar.addMenu("View")
        view_menu.addAction("Reset Camera", self.reset_camera)

    def create_toolbar(self):
        """Create toolbar"""
        toolbar = self.addToolBar("Main")
        toolbar.setMovable(False)

        cube_action = QAction("➕ Cube", self)
        cube_action.triggered.connect(lambda: self.create_object("cube"))
        toolbar.addAction(cube_action)

        sphere_action = QAction("➕ Sphere", self)
        sphere_action.triggered.connect(lambda: self.create_object("sphere"))
        toolbar.addAction(sphere_action)

        toolbar.addSeparator()

        select_action = QAction("🎯 Select", self)
        select_action.triggered.connect(
            lambda: self.set_transform_mode(TransformMode.SELECT)
        )
        toolbar.addAction(select_action)

        move_action = QAction("➡️ Move", self)
        move_action.triggered.connect(
            lambda: self.set_transform_mode(TransformMode.MOVE)
        )
        toolbar.addAction(move_action)

        scale_action = QAction("📏 Scale", self)
        scale_action.triggered.connect(
            lambda: self.set_transform_mode(TransformMode.SCALE)
        )
        toolbar.addAction(scale_action)

    def set_transform_mode(self, mode):
        """Set the transform mode"""
        self.gl_widget.transform_mode = mode
        self.statusBar().showMessage(f"Transform Mode: {mode.value.upper()}")

    def on_object_selected(self, obj):
        """Handle object selection"""
        self.update_properties_panel()

    def on_list_object_selected(self, item):
        """Handle selection from list"""
        name = item.text().split(" ")[0]
        for obj in self.gl_widget.objects:
            if obj.name == name:
                self.gl_widget.selected_object = obj
                self.on_object_selected(obj)
                break

    def update_properties_panel(self):
        """Update properties from selected object"""
        if not self.gl_widget.selected_object:
            return

        obj = self.gl_widget.selected_object

        self.pos_x.blockSignals(True)
        self.pos_y.blockSignals(True)
        self.pos_z.blockSignals(True)
        self.pos_x.setValue(obj.position[0])
        self.pos_y.setValue(obj.position[1])
        self.pos_z.setValue(obj.position[2])
        self.pos_x.blockSignals(False)
        self.pos_y.blockSignals(False)
        self.pos_z.blockSignals(False)

        self.rot_x.blockSignals(True)
        self.rot_y.blockSignals(True)
        self.rot_z.blockSignals(True)
        self.rot_x.setValue(obj.rotation[0])
        self.rot_y.setValue(obj.rotation[1])
        self.rot_z.setValue(obj.rotation[2])
        self.rot_x.blockSignals(False)
        self.rot_y.blockSignals(False)
        self.rot_z.blockSignals(False)

        self.scale_x.blockSignals(True)
        self.scale_y.blockSignals(True)
        self.scale_z.blockSignals(True)
        self.scale_x.setValue(obj.scale[0])
        self.scale_y.setValue(obj.scale[1])
        self.scale_z.setValue(obj.scale[2])
        self.scale_x.blockSignals(False)
        self.scale_y.blockSignals(False)
        self.scale_z.blockSignals(False)

    def update_transform(self):
        """Update selected object transform"""
        if self.gl_widget.selected_object:
            obj = self.gl_widget.selected_object
            obj.position = [self.pos_x.value(), self.pos_y.value(), self.pos_z.value()]
            obj.rotation = [self.rot_x.value(), self.rot_y.value(), self.rot_z.value()]
            obj.scale = [
                self.scale_x.value(),
                self.scale_y.value(),
                self.scale_z.value(),
            ]

    def update_ui(self):
        """Update UI elements"""
        self.object_list.clear()
        for obj in self.gl_widget.objects:
            item = QListWidgetItem(f"{obj.name} ({obj.shape_type})")
            if obj == self.gl_widget.selected_object:
                item.setBackground(QColor(42, 130, 218))
            self.object_list.addItem(item)

        self.statusBar().showMessage(
            f"Objects: {len(self.gl_widget.objects)} | Mode: {self.gl_widget.transform_mode.value}"
        )

    def create_object(self, shape_type):
        """Create a new object"""
        obj = self.gl_widget.add_object(shape_type)
        self.gl_widget.selected_object = obj
        self.update_properties_panel()

    def delete_selected(self):
        """Delete selected object"""
        if self.gl_widget.selected_object:
            self.gl_widget.objects.remove(self.gl_widget.selected_object)
            self.gl_widget.selected_object = None

    def run_script(self):
        """Execute Lua script"""
        code = self.code_editor.get_code()
        self.script_status.setText("Status: Running...")
        self.script_status.setStyleSheet("color: #ffff00;")
        self.console_output.append(f"[{self.get_timestamp()}] Script execution started")
        self.console_output.append(f"[INFO] Code length: {len(code)} characters")
        self.console_output.append(f"[INFO] Lines: {self.code_editor.lines()}")
        self.console_output.append("[MEPLUA] Engine API ready")
        self.console_output.append(
            "[INFO] Script would execute here (Full Lua integration coming)"
        )
        self.update_console_line_count()
        self.play_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.script_status.setText("Status: Running")
        self.script_status.setStyleSheet("color: #00ff00;")

    def stop_script(self):
        """Stop Lua script"""
        self.console_output.append(f"[{self.get_timestamp()}] Script stopped by user")
        self.script_status.setText("Status: Stopped")
        self.script_status.setStyleSheet("color: #ff0000;")
        self.update_console_line_count()
        self.play_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)

    def save_script(self):
        """Save Lua script to file"""
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Save MEPLUA Script", "", "MEPLUA Scripts (*.lua);;All Files (*)"
        )
        if file_path:
            try:
                with open(file_path, "w") as f:
                    f.write(self.code_editor.get_code())
                self.console_output.append(
                    f"[{self.get_timestamp()}] Script saved: {file_path}"
                )
                self.script_status.setText(f"Status: Saved to {Path(file_path).name}")
                self.update_console_line_count()
            except Exception as e:
                self.console_output.append(f"[ERROR] Failed to save: {e}")

    def load_script(self):
        """Load Lua script from file"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Load MEPLUA Script", "", "MEPLUA Scripts (*.lua);;All Files (*)"
        )
        if file_path:
            try:
                with open(file_path, "r") as f:
                    code = f.read()
                self.code_editor.set_code(code)
                self.console_output.append(
                    f"[{self.get_timestamp()}] Script loaded: {file_path}"
                )
                self.script_status.setText(f"Status: Loaded {Path(file_path).name}")
                self.update_console_line_count()
            except Exception as e:
                self.console_output.append(f"[ERROR] Failed to load: {e}")

    def insert_code_snippet(self, code):
        """Insert code snippet at cursor"""
        self.code_editor.insert(code)
        self.console_output.append(f"[{self.get_timestamp()}] Code snippet inserted")
        self.update_console_line_count()

    def update_cursor_position(self):
        """Update cursor position display"""
        line, col = self.code_editor.getCursorPosition()
        self.line_col_label.setText(f"Line: {line + 1}, Col: {col + 1}")

    def update_console_line_count(self):
        """Update console line count"""
        lines = self.console_output.document().blockCount()
        self.console_lines_label.setText(f"Lines: {lines}")

    def get_timestamp(self):
        """Get current timestamp for console"""
        from datetime import datetime

        return datetime.now().strftime("%H:%M:%S")

    def clear_console_output(self):
        """Clear console output"""
        self.console_output.clear()
        self.console_output.append(f"[{self.get_timestamp()}] Console cleared")
        self.script_status.setText("Status: Ready")
        self.script_status.setStyleSheet("color: #00ff00;")
        self.update_console_line_count()

    def reset_camera(self):
        """Reset camera"""
        self.gl_widget.camera_distance = 10.0
        self.gl_widget.camera_yaw = 30.0
        self.gl_widget.camera_pitch = 25.0
        self.dist_slider.setValue(100)

    def new_scene(self):
        """Create a new scene"""
        self.gl_widget.objects.clear()
        self.gl_widget.selected_object = None

    def open_scene(self):
        """Open a scene file"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Open Scene", "", "Scene Files (*.scene);;All Files (*)"
        )
        if file_path:
            self.console_output.append(f"[INFO] Loading scene: {file_path}")

    def save_scene(self):
        """Save the current scene"""
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Save Scene", "", "Scene Files (*.scene);;All Files (*)"
        )
        if file_path:
            self.console_output.append(f"[INFO] Saving scene: {file_path}")


def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")

    # Dark theme
    palette = app.palette()
    palette.setColor(palette.Window, QColor(53, 53, 53))
    palette.setColor(palette.WindowText, QColor(255, 255, 255))
    palette.setColor(palette.Base, QColor(35, 35, 35))
    palette.setColor(palette.AlternateBase, QColor(53, 53, 53))
    palette.setColor(palette.ToolTipBase, QColor(25, 25, 25))
    palette.setColor(palette.ToolTipText, QColor(255, 255, 255))
    palette.setColor(palette.Text, QColor(255, 255, 255))
    palette.setColor(palette.Button, QColor(53, 53, 53))
    palette.setColor(palette.ButtonText, QColor(255, 255, 255))
    palette.setColor(palette.BrightText, QColor(255, 0, 0))
    palette.setColor(palette.Link, QColor(42, 130, 218))
    palette.setColor(palette.Highlight, QColor(42, 130, 218))
    palette.setColor(palette.HighlightedText, QColor(35, 35, 35))
    app.setPalette(palette)

    window = EnhancedMainWindow()
    window.show()

    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
