"""
Transform Module - Handles position, rotation, and scale transformations
"""

import numpy as np
from pyrr import Matrix44, Vector3, Quaternion
import math


class Transform:
    """3D Transform component for game objects"""

    def __init__(self):
        self._position = np.array([0.0, 0.0, 0.0], dtype=np.float32)
        self._rotation = np.array(
            [0.0, 0.0, 0.0], dtype=np.float32
        )  # Euler angles in degrees
        self._scale = np.array([1.0, 1.0, 1.0], dtype=np.float32)
        self._matrix = None
        self._dirty = True

    @property
    def position(self) -> np.ndarray:
        return self._position.copy()

    @position.setter
    def position(self, value):
        self._position = np.array(value, dtype=np.float32)
        self._dirty = True

    @property
    def rotation(self) -> np.ndarray:
        """Rotation in degrees (pitch, yaw, roll)"""
        return self._rotation.copy()

    @rotation.setter
    def rotation(self, value):
        self._rotation = np.array(value, dtype=np.float32)
        self._dirty = True

    @property
    def scale(self) -> np.ndarray:
        return self._scale.copy()

    @scale.setter
    def scale(self, value):
        self._scale = np.array(value, dtype=np.float32)
        self._dirty = True

    def set_position(self, x: float, y: float, z: float):
        """Set position directly"""
        self._position = np.array([x, y, z], dtype=np.float32)
        self._dirty = True

    def set_rotation(self, pitch: float, yaw: float, roll: float):
        """Set rotation in degrees"""
        self._rotation = np.array([pitch, yaw, roll], dtype=np.float32)
        self._dirty = True

    def set_scale(self, x: float, y: float, z: float):
        """Set scale directly"""
        self._scale = np.array([x, y, z], dtype=np.float32)
        self._dirty = True

    def set_uniform_scale(self, s: float):
        """Set uniform scale"""
        self._scale = np.array([s, s, s], dtype=np.float32)
        self._dirty = True

    def translate(self, dx: float, dy: float, dz: float):
        """Move by offset"""
        self._position += np.array([dx, dy, dz], dtype=np.float32)
        self._dirty = True

    def rotate(self, dpitch: float, dyaw: float, droll: float):
        """Rotate by offset in degrees"""
        self._rotation += np.array([dpitch, dyaw, droll], dtype=np.float32)
        self._dirty = True

    def scale_by(self, sx: float, sy: float, sz: float):
        """Scale by factor"""
        self._scale *= np.array([sx, sy, sz], dtype=np.float32)
        self._dirty = True

    def get_model_matrix(self) -> np.ndarray:
        """Get the 4x4 model transformation matrix"""
        if self._dirty:
            self._rebuild_matrix()
        return self._matrix

    def _rebuild_matrix(self):
        """Rebuild the transformation matrix"""
        # Create translation matrix
        translation = Matrix44.from_translation(self._position.tolist())

        # Create rotation matrices (convert degrees to radians)
        pitch = math.radians(self._rotation[0])
        yaw = math.radians(self._rotation[1])
        roll = math.radians(self._rotation[2])

        rot_x = Matrix44.from_x_rotation(pitch)
        rot_y = Matrix44.from_y_rotation(yaw)
        rot_z = Matrix44.from_z_rotation(roll)
        rotation = rot_z * rot_y * rot_x

        # Create scale matrix
        scale = Matrix44.from_scale(self._scale.tolist())

        # Combine: Translation * Rotation * Scale
        # Transpose to convert from pyrr row-major to OpenGL column-major
        self._matrix = np.array(translation * rotation * scale, dtype=np.float32).T
        self._dirty = False

    def get_forward(self) -> np.ndarray:
        """Get the forward direction vector"""
        yaw = math.radians(self._rotation[1])
        pitch = math.radians(self._rotation[0])

        forward = np.array(
            [
                math.cos(pitch) * math.sin(yaw),
                math.sin(pitch),
                math.cos(pitch) * math.cos(yaw),
            ],
            dtype=np.float32,
        )

        return forward / np.linalg.norm(forward)

    def get_right(self) -> np.ndarray:
        """Get the right direction vector"""
        forward = self.get_forward()
        up = np.array([0.0, 1.0, 0.0], dtype=np.float32)
        right = np.cross(forward, up)
        return right / np.linalg.norm(right)

    def get_up(self) -> np.ndarray:
        """Get the up direction vector"""
        forward = self.get_forward()
        right = self.get_right()
        up = np.cross(right, forward)
        return up / np.linalg.norm(up)

    def look_at(self, target_x: float, target_y: float, target_z: float):
        """Rotate to look at a target position"""
        target = np.array([target_x, target_y, target_z], dtype=np.float32)
        direction = target - self._position
        direction = direction / np.linalg.norm(direction)

        # Calculate pitch and yaw
        pitch = math.degrees(math.asin(-direction[1]))
        yaw = math.degrees(math.atan2(direction[0], direction[2]))

        self._rotation = np.array([pitch, yaw, 0.0], dtype=np.float32)
        self._dirty = True

    def copy(self) -> "Transform":
        """Create a copy of this transform"""
        t = Transform()
        t._position = self._position.copy()
        t._rotation = self._rotation.copy()
        t._scale = self._scale.copy()
        t._dirty = True
        return t

    def __repr__(self):
        return f"Transform(pos={self._position}, rot={self._rotation}, scale={self._scale})"
