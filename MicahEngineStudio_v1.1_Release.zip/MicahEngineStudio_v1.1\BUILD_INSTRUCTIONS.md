# Micah Engine Studio v1.1 - Build Instructions

## Quick Build (Recommended)

Just run the automated build script:

```bash
python build_installer.py
```

This will:
1. Install PyInstaller if needed
2. Build the standalone EXE
3. Create a distribution ZIP
4. Generate release notes

The final package will be in `dist/MicahEngineStudio_v1.1_Release.zip`

---

## Manual Build Steps

If you prefer manual control:

### 1. Install PyInstaller

```bash
pip install pyinstaller
```

### 2. Build EXE

```bash
pyinstaller build_config.spec
```

This creates `dist/MicahEngineStudio_v1.1/` with the bundled executable.

### 3. Test the Build

```bash
cd dist/MicahEngineStudio_v1.1
./MicahEngineStudio.exe
```

### 4. Create Distribution ZIP

```bash
cd dist
powershell Compress-Archive -Path MicahEngineStudio_v1.1 -DestinationPath MicahEngineStudio_v1.1_Release.zip
```

---

## What Gets Bundled

- ✅ Python runtime (no install needed)
- ✅ All dependencies (PyQt5, PyOpenGL, numpy, lupa, etc.)
- ✅ Game engine code (`game_engine/`)
- ✅ Documentation (README, MEPLua manual)
- ✅ Requirements list (for reference)

## Distribution

Share `MicahEngineStudio_v1.1_Release.zip` on Discord. Users just:
1. Extract the ZIP
2. Run `MicahEngineStudio.exe`
3. Start creating!

No Python installation or pip commands required.

---

## Troubleshooting

**"ModuleNotFoundError" when running EXE:**
- Add missing module to `hiddenimports=[]` in `build_config.spec`
- Rebuild with `pyinstaller build_config.spec`

**EXE is huge (>500MB):**
- Normal! Includes Python + all libraries + OpenGL
- Use `upx=True` (already enabled) to compress

**Antivirus blocks EXE:**
- PyInstaller exes sometimes trigger false positives
- Share SHA256 hash with users or code-sign if you have a cert

**Build fails:**
- Ensure all dependencies installed: `pip install -r requirements.txt`
- Check PyInstaller version: `pip install --upgrade pyinstaller`
