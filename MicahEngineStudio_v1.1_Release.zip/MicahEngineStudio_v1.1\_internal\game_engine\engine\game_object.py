"""
GameObject Module - Base class for all objects in the scene
"""

from typing import Optional, Dict, Any, TYPE_CHECKING
from .transform import Transform
from .mesh import Mesh

if TYPE_CHECKING:
    from .scene import Scene


class GameObject:
    """A game object with transform, mesh, and scripting support"""

    _id_counter = 0

    def __init__(self, name: str = "GameObject"):
        GameObject._id_counter += 1
        self.id = GameObject._id_counter
        self.name = name
        self.transform = Transform()
        self.mesh: Optional[Mesh] = None
        self.color = (1.0, 1.0, 1.0)
        self.visible = True
        self.active = True
        self.scene: Optional["Scene"] = None
        self.tags: set = set()
        self.properties: Dict[str, Any] = {}

        # Script support
        self.scripts: list = []
        self._lua_bindings: Dict[str, Any] = {}

    def set_mesh(self, mesh: Mesh):
        """Set the mesh for this object"""
        self.mesh = mesh

    def set_color(self, r: float, g: float, b: float):
        """Set the object color"""
        self.color = (r, g, b)

    def set_position(self, x: float, y: float, z: float):
        """Set position"""
        self.transform.set_position(x, y, z)

    def set_rotation(self, pitch: float, yaw: float, roll: float):
        """Set rotation in degrees"""
        self.transform.set_rotation(pitch, yaw, roll)

    def set_scale(self, x: float, y: float, z: float):
        """Set scale"""
        self.transform.set_scale(x, y, z)

    def move(self, dx: float, dy: float, dz: float):
        """Move by offset"""
        self.transform.translate(dx, dy, dz)

    def rotate(self, dpitch: float, dyaw: float, droll: float):
        """Rotate by offset"""
        self.transform.rotate(dpitch, dyaw, droll)

    def scale_by(self, sx: float, sy: float, sz: float):
        """Scale by factor"""
        self.transform.scale_by(sx, sy, sz)

    def get_position(self):
        """Get position as tuple"""
        pos = self.transform.position
        return (pos[0], pos[1], pos[2])

    def get_rotation(self):
        """Get rotation as tuple"""
        rot = self.transform.rotation
        return (rot[0], rot[1], rot[2])

    def get_scale(self):
        """Get scale as tuple"""
        scale = self.transform.scale
        return (scale[0], scale[1], scale[2])

    def add_tag(self, tag: str):
        """Add a tag to this object"""
        self.tags.add(tag)

    def has_tag(self, tag: str) -> bool:
        """Check if object has a tag"""
        return tag in self.tags

    def set_property(self, key: str, value: Any):
        """Set a custom property"""
        self.properties[key] = value

    def get_property(self, key: str, default: Any = None) -> Any:
        """Get a custom property"""
        return self.properties.get(key, default)

    def add_script(self, script):
        """Add a Lua script to this object"""
        self.scripts.append(script)

    def update(self, dt: float):
        """Update the game object (called every frame)"""
        pass

    def render(self, shader):
        """Render the game object"""
        if not self.visible or not self.mesh:
            return

        # Set model matrix
        model_matrix = self.transform.get_model_matrix()
        shader.set_mat4("model", model_matrix)
        shader.set_vec3("object_color", *self.color)

        # Render mesh
        self.mesh.render()

    def on_start(self):
        """Called when object is added to scene"""
        pass

    def on_destroy(self):
        """Called when object is removed from scene"""
        pass

    def destroy(self):
        """Remove this object from its scene"""
        if self.scene:
            self.scene.remove_object(self)

    def __repr__(self):
        return f"GameObject('{self.name}', id={self.id})"
