"""
Camera Module - 3D Camera for scene viewing
"""

import numpy as np
from pyrr import Matrix44, Vector3
import math
from .transform import Transform


class Camera:
    """3D Camera with projection and view matrices"""

    def __init__(
        self,
        fov: float = 60.0,
        aspect: float = 16 / 9,
        near: float = 0.1,
        far: float = 1000.0,
    ):
        self.transform = Transform()
        self.fov = fov
        self.aspect = aspect
        self.near = near
        self.far = far

        self._projection_matrix = None
        self._view_matrix = None
        self._projection_dirty = True
        self._view_dirty = True

    def set_position(self, x: float, y: float, z: float):
        """Set camera position"""
        self.transform.set_position(x, y, z)
        self._view_dirty = True

    def set_rotation(self, pitch: float, yaw: float, roll: float = 0):
        """Set camera rotation in degrees"""
        self.transform.set_rotation(pitch, yaw, roll)
        self._view_dirty = True

    def move(self, dx: float, dy: float, dz: float):
        """Move camera by offset"""
        self.transform.translate(dx, dy, dz)
        self._view_dirty = True

    def rotate(self, dpitch: float, dyaw: float, droll: float = 0):
        """Rotate camera by offset"""
        self.transform.rotate(dpitch, dyaw, droll)
        self._view_dirty = True

    def look_at(self, target_x: float, target_y: float, target_z: float):
        """Make camera look at a point"""
        self.transform.look_at(target_x, target_y, target_z)
        self._view_dirty = True

    def set_fov(self, fov: float):
        """Set field of view in degrees"""
        self.fov = fov
        self._projection_dirty = True

    def set_aspect(self, aspect: float):
        """Set aspect ratio"""
        self.aspect = aspect
        self._projection_dirty = True

    def get_projection_matrix(self) -> np.ndarray:
        """Get the projection matrix"""
        if self._projection_dirty:
            self._rebuild_projection()
        return self._projection_matrix

    def get_view_matrix(self) -> np.ndarray:
        """Get the view matrix"""
        if self._view_dirty:
            self._rebuild_view()
        return self._view_matrix

    def _rebuild_projection(self):
        """Rebuild projection matrix"""
        self._projection_matrix = np.array(
            Matrix44.perspective_projection(self.fov, self.aspect, self.near, self.far),
            dtype=np.float32,
        ).T  # Transpose for OpenGL column-major
        self._projection_dirty = False

    def _rebuild_view(self):
        """Rebuild view matrix"""
        pos = self.transform.position
        forward = self.transform.get_forward()
        up = np.array([0.0, 1.0, 0.0], dtype=np.float32)

        target = pos + forward

        self._view_matrix = np.array(
            Matrix44.look_at(eye=pos.tolist(), target=target.tolist(), up=up.tolist()),
            dtype=np.float32,
        ).T  # Transpose for OpenGL column-major
        self._view_dirty = False

    def get_position(self):
        """Get camera position as tuple"""
        pos = self.transform.position
        return (pos[0], pos[1], pos[2])

    def get_forward(self):
        """Get forward direction as tuple"""
        fwd = self.transform.get_forward()
        return (fwd[0], fwd[1], fwd[2])

    def get_right(self):
        """Get right direction as tuple"""
        right = self.transform.get_right()
        return (right[0], right[1], right[2])


class OrbitCamera(Camera):
    """Camera that orbits around a target point"""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.target = np.array([0.0, 0.0, 0.0], dtype=np.float32)
        self.distance = 5.0
        self.yaw = 0.0  # Horizontal angle
        self.pitch = 30.0  # Vertical angle (degrees)
        self._update_position()

    def set_target(self, x: float, y: float, z: float):
        """Set the point to orbit around"""
        self.target = np.array([x, y, z], dtype=np.float32)
        self._update_position()

    def set_distance(self, distance: float):
        """Set orbit distance"""
        self.distance = max(0.1, distance)
        self._update_position()

    def orbit(self, dyaw: float, dpitch: float):
        """Orbit around target"""
        self.yaw += dyaw
        self.pitch = max(-89.0, min(89.0, self.pitch + dpitch))
        self._update_position()

    def zoom(self, delta: float):
        """Zoom in/out"""
        self.distance = max(0.1, self.distance + delta)
        self._update_position()

    def _update_position(self):
        """Update camera position based on orbit parameters"""
        pitch_rad = math.radians(self.pitch)
        yaw_rad = math.radians(self.yaw)

        x = self.target[0] + self.distance * math.cos(pitch_rad) * math.sin(yaw_rad)
        y = self.target[1] + self.distance * math.sin(pitch_rad)
        z = self.target[2] + self.distance * math.cos(pitch_rad) * math.cos(yaw_rad)

        self.transform.set_position(x, y, z)
        self.look_at(self.target[0], self.target[1], self.target[2])
