"""
Scene Module - Container for game objects and rendering management
"""

from typing import Dict, List, Optional, TYPE_CHECKING
import numpy as np
from .game_object import GameObject
from .camera import Camera, OrbitCamera
from .shader import ShaderProgram, ShaderLibrary
from .mesh import Mesh, MeshFactory, GridHelper, AxisGizmo

if TYPE_CHECKING:
    from .core import Engine


class Scene:
    """A scene containing game objects, camera, and lighting"""

    def __init__(self, name: str = "Scene"):
        self.name = name
        self.engine: Optional["Engine"] = None
        self.objects: Dict[int, GameObject] = {}
        self.objects_by_name: Dict[str, GameObject] = {}

        # Camera
        self.camera: Optional[Camera] = None

        # Lighting
        self.light_position = np.array([5.0, 10.0, 5.0], dtype=np.float32)
        self.light_color = np.array([1.0, 1.0, 1.0], dtype=np.float32)
        self.ambient_strength = 0.4
        self.specular_strength = 0.5

        # Rendering
        self.shader: Optional[ShaderProgram] = None
        self.grid_shader: Optional[ShaderProgram] = None
        self.background_color = (0.15, 0.15, 0.2)

        # Visual helpers
        self.grid: Optional[GridHelper] = None
        self.gizmo: Optional[AxisGizmo] = None
        self.show_grid = True
        self.show_gizmo = True

        # Lua scripting
        self.lua_engine = None

    def on_load(self):
        """Called when scene becomes active"""
        if not self.engine:
            return

        ctx = self.engine.ctx

        # Create default shader if not set
        if not self.shader:
            self.shader = ShaderLibrary.create_default_shader(ctx)

        # Create grid shader
        if not self.grid_shader:
            self.grid_shader = ShaderLibrary.create_grid_shader(ctx)

        # Create grid and gizmo
        self.grid = GridHelper(ctx, size=10.0, divisions=10)
        self.grid.create_vao(self.grid_shader.program)

        self.gizmo = AxisGizmo(ctx, size=1.5)
        self.gizmo.create_vao(self.grid_shader.program)

        # Create default camera if not set
        if not self.camera:
            self.camera = OrbitCamera(aspect=self.engine.width / self.engine.height)
            self.camera.set_target(0, 0, 0)
            self.camera.set_distance(5.0)

        # Initialize VAOs for all meshes
        for obj in self.objects.values():
            if obj.mesh and self.shader:
                obj.mesh.create_vao(self.shader.program)

        print(f"[Scene] Loaded: {self.name}")

    def add_object(self, obj: GameObject) -> GameObject:
        """Add a game object to the scene"""
        self.objects[obj.id] = obj
        self.objects_by_name[obj.name] = obj
        obj.scene = self

        # Create VAO if scene is loaded
        if self.shader and obj.mesh:
            obj.mesh.create_vao(self.shader.program)

        obj.on_start()
        return obj

    def remove_object(self, obj: GameObject):
        """Remove a game object from the scene"""
        if obj.id in self.objects:
            obj.on_destroy()
            del self.objects[obj.id]
            if obj.name in self.objects_by_name:
                del self.objects_by_name[obj.name]
            obj.scene = None

    def get_object(self, name: str) -> Optional[GameObject]:
        """Get an object by name"""
        return self.objects_by_name.get(name)

    def get_objects_with_tag(self, tag: str) -> List[GameObject]:
        """Get all objects with a specific tag"""
        return [obj for obj in self.objects.values() if obj.has_tag(tag)]

    def create_cube(
        self, name: str = "Cube", size: float = 1.0, color: tuple = (1.0, 1.0, 1.0)
    ) -> GameObject:
        """Create and add a cube to the scene"""
        obj = GameObject(name)
        obj.mesh = MeshFactory.create_cube(self.engine.ctx, size, color)
        obj.color = color
        return self.add_object(obj)

    def create_sphere(
        self, name: str = "Sphere", radius: float = 0.5, color: tuple = (1.0, 1.0, 1.0)
    ) -> GameObject:
        """Create and add a sphere to the scene"""
        obj = GameObject(name)
        obj.mesh = MeshFactory.create_sphere(self.engine.ctx, radius, color=color)
        obj.color = color
        return self.add_object(obj)

    def create_plane(
        self,
        name: str = "Plane",
        width: float = 10.0,
        height: float = 10.0,
        color: tuple = (0.5, 0.5, 0.5),
    ) -> GameObject:
        """Create and add a plane to the scene"""
        obj = GameObject(name)
        obj.mesh = MeshFactory.create_plane(self.engine.ctx, width, height, color)
        obj.color = color
        return self.add_object(obj)

    def create_cylinder(
        self,
        name: str = "Cylinder",
        radius: float = 0.5,
        height: float = 1.0,
        color: tuple = (1.0, 1.0, 1.0),
    ) -> GameObject:
        """Create and add a cylinder to the scene"""
        obj = GameObject(name)
        obj.mesh = MeshFactory.create_cylinder(
            self.engine.ctx, radius, height, color=color
        )
        obj.color = color
        return self.add_object(obj)

    def create_pyramid(
        self,
        name: str = "Pyramid",
        base_size: float = 1.0,
        height: float = 1.0,
        color: tuple = (1.0, 1.0, 1.0),
    ) -> GameObject:
        """Create and add a pyramid to the scene"""
        obj = GameObject(name)
        obj.mesh = MeshFactory.create_pyramid(self.engine.ctx, base_size, height, color)
        obj.color = color
        return self.add_object(obj)

    def create_torus(
        self,
        name: str = "Torus",
        major_radius: float = 0.5,
        minor_radius: float = 0.2,
        color: tuple = (1.0, 1.0, 1.0),
    ) -> GameObject:
        """Create and add a torus to the scene"""
        obj = GameObject(name)
        obj.mesh = MeshFactory.create_torus(
            self.engine.ctx, major_radius, minor_radius, color=color
        )
        obj.color = color
        return self.add_object(obj)

    def set_light_position(self, x: float, y: float, z: float):
        """Set the light position"""
        self.light_position = np.array([x, y, z], dtype=np.float32)

    def set_light_color(self, r: float, g: float, b: float):
        """Set the light color"""
        self.light_color = np.array([r, g, b], dtype=np.float32)

    def update(self, dt: float):
        """Update all objects in the scene"""
        # Update Lua scripts
        if self.lua_engine:
            self.lua_engine.update(dt)

        # Update all objects
        for obj in list(self.objects.values()):
            if obj.active:
                obj.update(dt)

    def render(self):
        """Render all objects in the scene"""
        if not self.shader or not self.camera:
            print(f"[Scene] Cannot render: shader={self.shader}, camera={self.camera}")
            return

        view_matrix = self.camera.get_view_matrix()
        proj_matrix = self.camera.get_projection_matrix()

        # Render grid and gizmo first (with grid shader)
        if self.grid_shader and (self.show_grid or self.show_gizmo):
            self.grid_shader.program["view"].write(
                view_matrix.astype(np.float32).tobytes()
            )
            self.grid_shader.program["projection"].write(
                proj_matrix.astype(np.float32).tobytes()
            )

            if self.show_grid and self.grid:
                self.grid.render()
            if self.show_gizmo and self.gizmo:
                self.gizmo.render()

        # Set camera matrices for main shader
        self.shader.set_mat4("view", view_matrix)
        self.shader.set_mat4("projection", proj_matrix)

        # Set lighting
        self.shader.set_vec3("light_position", *self.light_position)
        self.shader.set_vec3("light_color", *self.light_color)
        self.shader.set_vec3("view_position", *self.camera.get_position())
        self.shader.set_float("ambient_strength", self.ambient_strength)
        self.shader.set_float("specular_strength", self.specular_strength)

        # Render all visible objects
        for obj in self.objects.values():
            if obj.visible and obj.active:
                obj.render(self.shader)
